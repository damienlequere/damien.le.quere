#include"generateur.h"
#include <math.h>

float Generateur::mon_random(float binf,float bsup){
    float r = ( ((rand()/(float)(RAND_MAX)) * (bsup-binf)) + binf );
    return r;
    };

bool Generateur::mon_random_bool(){
        if ((rand()/(float)(RAND_MAX)) < 0.5)
            return true;
        else
            return false;
    }

float Generateur::arrondir(float value, int precision){
    int partie_entiere = floor(value);
    int partie_decimale = floor( (value-partie_entiere) * precision );
    return partie_entiere + ( ((float)(partie_decimale)) / precision );
    };

int Generateur::pgcd(int a, int b){
    while(1){
        a = a%b;
        if (a == 0)
            return b;
        b = b%a;
        if(b == 0)
            return a;
        }
    };


void Generateur::calcul_rapport(int &c, int &p, float rapport,float num_max){
    int c_temp,
        p_temp;

    //on genere un c aleatoire
    c_temp = (int)(mon_random(1,num_max));

    //calcul de Ps sous forme fractionnaire
    int p_temp_num = c_temp * PRECISION;
    int p_temp_den = rapport * PRECISION;
    int pgcd_p_temp = pgcd(p_temp_num,p_temp_den);
    p_temp_num /= pgcd_p_temp;
    p_temp_den /= pgcd_p_temp;

    /* trouver des valeurs de Cs Ps en multipliant
    *  par l'inverse de la fraction de Ps */
    c_temp *= p_temp_den;
    p_temp = p_temp_num;

    //on essaye de simplifier en divisant par le pgcd
    int pgcd_c_p_temp = pgcd(c_temp,p_temp);
    c_temp /= pgcd_c_p_temp;
    p_temp /= pgcd_c_p_temp;

    c = c_temp;
    p = p_temp;
    };

ListeTaches *Generateur::genTaches(string n,int nbtp,float up,int nbta,float us){

    ListeTaches * ensembleTaches = new ListeTaches(n);

    /*=======================================*/
    /*== GENERATION DES TACHES PERIODIQUES ==*/
    /*=======================================*/

    float sommeRatios = 0,  //
          ratios[nbtp];     //ratios ci/pi calcules des taches periodiques
    int ci[nbtp],           //ci calcules des taches periodiques
        pi[nbtp];           //pi calcules des taches periodiques

    //calcul du ratio ci/pi pour chaque tache
    for(int cpt=1; cpt<=nbtp-1; cpt++){
        float ratio_temp = mon_random(RATIO_MIN,up-sommeRatios - (RATIO_MIN * (nbtp-cpt)));
        ratios[cpt] = arrondir(ratio_temp,PRECISION);
        sommeRatios += ratios[cpt];
        }
    //pour le dernier ratio, on "complete" pour atteindre Up
    ratios[nbtp] = up - sommeRatios;
    sommeRatios += ratios[nbtp];

    //construction de la liste de taches en ajoutant les taches aperiodiques
    for(int cpt=1; cpt<=nbtp; cpt++){
        calcul_rapport(ci[cpt],pi[cpt],ratios[cpt],CI_MAX);

        Tache tache_temp(0,ci[cpt],0,pi[cpt]);
        ensembleTaches->ajouter(tache_temp);
        }

    /*========================================*/
    /*== GENERATION DES TACHES APERIODIQUES ==*/
    /*========================================*/

    int ci_ap,   //ci des taches aperiodiques
        di_ap,   //di des taches aperiodiques
        ri_ap;   //ri des taches aperiodiques
    int cs,      //
        ps;      //

    //on cherche un raport Cs/Ps egal a Us
    calcul_rapport(cs,ps,us,CI_MAX);

    //pour chaque tache aperiodique ...
    for(int cpt=1; cpt<=nbta; cpt++){
        //on trouve une valeur de ci aleatoirement
        ci_ap = (int)(mon_random(1,CI_MAX));

        //on choisi aleatoirement si la tache est critique ou non
        bool estCritique = mon_random_bool();

        //si la tache est critique on lui attribue un delai critique > 0
        if(estCritique)
            di_ap = (int)(mon_random(1,DI_MAX));
        else
            di_ap = 0;

        //on choisi aleatoirement une date de reveil
        ri_ap = (int)(mon_random(0,RI_MAX));

        //on construit la tache
        Tache tache_temp(ri_ap,ci_ap,di_ap,0);
        //on ajoute la tache a la liste de taches
        ensembleTaches->ajouter(tache_temp);
        }


    return ensembleTaches;
    };
