package test.junit.decouverte.parcours;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import plugin.Programme;

import decouverte.parcours.GestionPutProgrammeSansXml;
import decouverte.parcours.GestionnaireDeFichiers;

/**
 * @author stephane
 *
 */
public class GestionPutProgrammeSansXmlTest {
	/**
	 * Le gestionnaire de fichiers a tester.
	 */
	private GestionnaireDeFichiers gestionnaire;
	
	/**
	 * Initialisation des tests.
	 * @throws MalformedURLException Si l'URL est mal formulee.
	 */
	@BeforeMethod
	@Before
	public void setUp() throws MalformedURLException {
		File fichier = new File(System.getProperty("user.dir")+"/plugins/calcul.jar");
		
		URL u = fichier.toURI().toURL();
		URLClassLoader loader = new URLClassLoader(new URL[] {u});
		this.gestionnaire = new GestionPutProgrammeSansXml(fichier, loader);
	}

	/**
	 * Test de la methode getResultats.
	 * @throws IOException Si le fichier n'est pas trouve.
	 * @throws ClassNotFoundException Si la classe n'est pas trouvee dans le classe loader.
	 */
	@SuppressWarnings("unchecked")
	@org.testng.annotations.Test(groups="decouverte.parcours")
	@Test
	public void testGetResultats() throws ClassNotFoundException, IOException {
		Map<String, Programme> map = (Map<String, Programme>) this.gestionnaire.getResultats();
		assertNotNull("La map de resultat est null", map);
		
		Programme programme = map.get("calcul");
		assertNotNull("Il n'y a pas de programme calcul", programme);
		
		assertFalse("Le programme n'a pas de classes de controleur", programme.getControleurClasse().equals(""));
		assertFalse("Le programme n'a pas de jars de controleur", programme.getControleurJar().equals(""));
		
		assertFalse("Le programme n'a pas de classes de modele", programme.getModeleClasse().equals(""));
		assertFalse("Le programme n'a pas de jars de modele", programme.getModeleJar().equals(""));
		
		assertFalse("Le programme n'a pas de classes de vue", programme.getVueClasses().isEmpty());
		assertFalse("Le programme n'a pas de jars de vue", programme.getVueJar().isEmpty());
		
		assertEquals("Le programme n'a pas le bon controleur", programme.getControleurClasse(), "plugin.essai.controleur.PluginDeControleur");
		assertEquals("Le programme n'a pas le bon modele", programme.getModeleClasse(), "plugin.essai.modele.PluginDeModele");
		assertTrue("Le programme n'a pas la bonne vue", programme.getVueClasses().contains("plugin.essai.vue.PluginDeVue"));
		assertTrue("Le programme n'a pas la bonne vue annexe", programme.getVueClasses().contains("plugin.essai.vue.PluginDeVueAnnexe"));
	}

}
