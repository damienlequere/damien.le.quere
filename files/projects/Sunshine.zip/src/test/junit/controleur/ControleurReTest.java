package test.junit.controleur;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.logging.Logger;

import modele.Modele;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import principal.Sunshine;

import controleur.Controleur;

/**
 * Classe de retest du controleur.
 * @author stephane
 */
public class ControleurReTest {
	/**
	 * Le logger de Controle.
	 */
	private static final Logger LOGGER = Logger.getLogger("test.junit.ControleReTest");
	
	/**
	 * Le controleur a tester.
	 */
	private Controleur controleur;
	
	/**
	 * Constructeur.
	 */
	public ControleurReTest() {
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "ControleurReTest", e);
		}
	}

	/**
	 * Initialisation du test.
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		this.controleur = new Controleur();
	}

	/**
	 * Test de la methode controle.
	 */
	@org.testng.annotations.Test(groups="controleur")
	@Test
	public void testControle() {
		String operateur = "preparer_les_programmes";
		ArrayList<String> args = null;
		Object argument = (ArrayList<String>) args;
		
		Modele modele = new Modele();
		controleur.setModele(modele);
		controleur.controle(operateur, argument);
		
		Class<?> c = Modele.class;
		Field[] f = c.getDeclaredFields();
		for(Field fi : f)
		{
			fi.setAccessible(true);
		}
		
		try
		{
			Field field = Modele.class.getDeclaredField("operateur");
			String ope = (String) field.get(modele);
			assertEquals("L'operateur n'est pas correctement initialise", operateur, ope);
			
			field = Modele.class.getDeclaredField("argument");
			Object obj = field.get(modele);
			assertEquals("Les arguments sont mal initialises", obj, argument);
		}
		catch (Exception e)
		{
			LOGGER.throwing("ControleurReTest", "testControle", e);
		}
	}
}
