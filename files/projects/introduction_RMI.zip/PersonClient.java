import java.rmi.*;
import java.util.ArrayList;

public class PersonClient {
	
	public static void main(String[] args) {
		try{
			PersonServerInterface s = (PersonServerInterface) Naming.lookup("rmi://127.0.0.1:1099/Service");
			ArrayList<PersonInterface> resultat= s.find("Prenom3");
			for(Integer i=0; i< resultat.size(); i++)
				System.out.println(resultat.get(i).getFirstName()+" "+resultat.get(i).getLastName());
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}	
	}
}
