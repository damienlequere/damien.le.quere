/* ADDITIONAL CODE *********************************************************/
%{
#include <stdio.h>
#include <string.h>

void yyerror(const char *str){ fprintf(stderr,"erreur: %s\n",str); }

int yywrap(){ return 1; }

/* Variables et fonctions utilisees *****************/

int compteur_rowspan = 0,  // 
    cpt_ligne        = 0,  // compteur de ligne permettant de connaitre la ligne courante
    cpt_colonne       = 0;  // compteur de colonne permettant de connaitre la colonne courante
float sommes_colonnes[32],  // tableau contenant les sommes des colonnes
      sommes_lignes[32];   // tableau contenant les sommes des lignes

// retourne le nombre de valeurs non nulles d'un tableau de float
int nb_val(float table_val[32]){
   int i,
       nb_val = 0;
   for(i=0;i<=32;i++)
      if(table_val[i]!=0)
         nb_val++;
   return nb_val;
}

// Affichage de la ligne contenant les sommes des colonnes
void affiche_sum_col(){
   if((nb_val(sommes_colonnes))>0){
      printf("<tr>\n");
      int j;
      for(j=0;j<cpt_colonne;j++){
         if(sommes_colonnes[j]==0)
            printf("\t<td class=\"sum\">&nbsp;</td>\n");
         else
            printf("\t<td class=\"sum\">%.2f</td>\n",sommes_colonnes[j]);
      }
      printf("</tr>\n"); // fermeture de la derniere ligne
   }
   return;
}

void affiche_sum_ligne(){
   if((sommes_lignes[cpt_ligne])>0)
      printf("\t<td class=\"sum\">%.2f</td>\n",sommes_lignes[cpt_ligne]);
   return;
}

/****************************************************/

// variables de Yacc
extern int yylex();
extern int yyparse();
extern FILE *yyin;

int main(int nb, char * argv[]) {
   // on initialise nos tableaux en mettant toutes ces cases a 0
   int cpt;
   for(cpt=0;cpt<=32;cpt++){sommes_colonnes[cpt]=0;}
   for(cpt=0;cpt<=32;cpt++){sommes_lignes[cpt]=0;}
   
	FILE *myfile = fopen(argv[1], "r");
	if (!myfile){
		printf("can not open the file\n");
		return -1;
   }
	yyin = myfile;
	do {
		yyparse();
	} while (!feof(yyin));
}

%}

/* DEFINITIONS *************************************************************/

%token OBRACE EBRACE BACKSLASH DOCUMENTCLASS OPENDOCUMENT OPENCENTER OPENTABULAR OPENTABLE CLOSEDOCUMENT CLOSECENTER CLOSETABULAR CLOSETABLE VSPACE CAPTION LABEL PIPE HLINE PERCENT AMPERSAND MULTICOLUMN DOLLAR FORMCOL BOLD UPPERCASE

%union {
	float fval;
	char  *sval;
	int   ival;
}
%token <fval> FLOAT
%token <sval> WORD WORDS INSTRUCTION_LATEX
%token <ival> INTEGER LISTCOL

%start fichier_latex

%% 

/*** RULES *****************************************************************/

fichier_latex : /* Structure d'un fichier LATEX */
   {
      printf("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
      printf("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n\n");
   }
   DOCUMENTCLASS {
      printf("<html>\n\n<head>\n");
      printf("<style>\n");
      printf("table{border-collapse:collapse;}\n");
      printf("table td{text-align:center;}\n");
      printf("table td:hover{cursor:default;}\n");
      printf(".sum{font-weight:bold;text-align:center;color:#00F;}\n");
      printf("</style>\n");
   } 
   instructions_latex 
   OPENDOCUMENT {printf("</head>\n\n<body>\n\n");}
   content 
   CLOSEDOCUMENT {printf("\n\n</body>\n\n</html>\n");}
;

instructions_latex : /* Les instructions LATEX avant le debut du document */
   /* epsilon */ |
   instructions_latex INSTRUCTION_LATEX {printf("<!-- %s -->\n",$2);}
;

content : /* Contenu du fichier LATEX */
   OPENTABLE 
   open_center
   tabular 
   close_center 
   VSPACE 
   caption 
   LABEL 
   CLOSETABLE
;

open_center :
   /* epsilon */ |
   OPENCENTER {printf("<center>\n");}
;

close_center :
   /* epsilon */ |
   CLOSECENTER {printf("\n</center>\n\n");}
;

tabular : /* Tableau */
   OPENTABULAR LISTCOL {printf("<table border=\"%d\">\n<tbody>\n",$2);} 
   lignes_tab 
   hline_pev
   CLOSETABULAR {affiche_sum_col();printf("</tbody>\n</table>");} // fermeture du tableau
   // Avant de fermer le tableau on affiche la ligne contenant les sommes des colonnes
;

lignes_tab : /* Plusieurs lignes de tableau */
   ligne_tab | 
   lignes_tab ligne_tab
;

ligne_tab : /* Une ligne de tableau */
   hline_pev {printf("<tr>\n");cpt_colonne=0;cpt_ligne++;}
   elems_ligne {printf("</tr>\n");}
   BACKSLASH BACKSLASH
;

hline_pev : /* La chaine \hline, pouvant etre vide */
   /* epsilon */ |
   HLINE
;

elems_ligne : /* Plusieurs elements d'une ligne de tableau */
   elem_ligne {affiche_sum_ligne();} | // A la fin de chaque ligne de tableau on affiche la somme de cette ligne
   elem_ligne AMPERSAND elems_ligne
;

elem_ligne : /* Un element d'une ligne de tableau */
   /* epsilon */ {if(compteur_rowspan==0){printf("\t<td rowspan=\"2\">&nbsp;</td>\n");compteur_rowspan++;}cpt_colonne++;} |
   {printf("\t<td>");} format_data {printf("</td>\n");cpt_colonne++;} |
   MULTICOLUMN 
   OBRACE INTEGER EBRACE 
   FORMCOL 
   OBRACE WORDS {printf("\t<td style=\"text-align:center;\" colspan=\"%d\">%s</td>\n",$3,$7);cpt_colonne++;} EBRACE
;

format_data : /* Plusieurs elements formates */
   format_datum |
   format_data format_datum
;

format_datum : /* Un mot ou plusieurs mots ou un element de formatage ou une valeur numerique */
   WORDS {printf("%s",$1);} |
   WORD {printf("%s",$1);} |
   BOLD {printf("<span style=\"font-weight:bold;\">");} |
   UPPERCASE {printf("<span style=\"text-transform:uppercase;\">");} |
   EBRACE {printf("</span>");} |
   DOLLAR val DOLLAR
;

val : /* Une valeur numerique ou un caractère special */
   INTEGER BACKSLASH PERCENT {printf("%d\%\%",$1);} | 
   FLOAT {printf("%.2f",$1);sommes_colonnes[cpt_colonne]+=$1;sommes_lignes[cpt_ligne]+=$1;} | 
   INTEGER {printf("%d",$1);} |
   BACKSLASH WORD {printf("%s",$2);}
;

caption : /* CAPTION */
   CAPTION {printf("<p>");}
   OBRACE 
   format_data 
   EBRACE {printf("</p>");}
;

%%
