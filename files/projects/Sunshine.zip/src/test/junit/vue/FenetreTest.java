package test.junit.vue;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.ExpectedExceptions;

import plugin.Programme;

import vue.Fenetre;

/**
 * Classe de test de la fenetre.
 * @author stephane
 */
@SuppressWarnings("deprecation")
public class FenetreTest {
	/**
	 * La fenetre a tester.
	 */
	private Fenetre fenetre;
	
	/**
	 * Nom du programme.
	 */
	private String str;
	
	/**
	 * Initialisation des tests.
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		str = "calcul";
		fenetre = new Fenetre();
	}

	/**
	 * Test de la methode est programme.
	 */
	@org.testng.annotations.Test(groups="vue")
	@Test
	public void testGetProgramme() {
		assertNull("Le programme calcul existe", fenetre.getProgramme(str));
		
		HashMap<String, Programme> map = new HashMap<String, Programme>();
		map.put(str, new Programme("Calcul", "1.0"));
		fenetre.update(map);
		
		assertNotNull("Le programme calcul n'existe pas", fenetre.getProgramme(str));
	}

	/**
	 * Test de la methode update.
	 */
	@org.testng.annotations.Test(groups="vue")
	@ExpectedExceptions(ClassCastException.class)
	@Test(expected=ClassCastException.class)
	public void testUpdateObject() {
		String erreur = "erreur";
		fenetre.update(erreur);
	}

}
