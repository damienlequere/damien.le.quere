package common;

import java.rmi.*;
import java.sql.SQLException;
import java.util.Vector;

public interface ResultServerInterface extends Remote{
    public Vector<Integer> classement() throws RemoteException, SQLException;
    public Integer getNbTourPremier() throws RemoteException, SQLException;
    
    public Float getMeilleurTempsTour(Integer tour)throws RemoteException, SQLException;
    
    public String getNom(Integer numP) throws RemoteException, SQLException;
	public Float getDernierTemps(Integer numP) throws RemoteException, SQLException;
	public Integer getDernierTour(Integer numP) throws RemoteException, SQLException;
	public Float getMeilleurTemps(Integer numP) throws RemoteException, SQLException;
	public Integer getToutCourant(Integer numP) throws RemoteException, SQLException;
	public Vector<Float> getTemps(Integer numP) throws RemoteException, SQLException;
	public Float getMoyenne(Integer numP) throws RemoteException, SQLException;

	public Float getTempsTour(Integer numP, Integer tour) throws RemoteException, SQLException;
	public Float getTempsTotalTour(Integer numP, Integer tour) throws RemoteException, SQLException;
	public Integer getPositionTour(Integer numP, Integer tour) throws RemoteException, SQLException;
}