#ifndef TACHE_H_INCLUDED
#define TACHE_H_INCLUDED

#include<iostream>
#include<string>
#include <sstream>

using namespace std;

class Tache{

    public:

    //constructeurs
    Tache();
    Tache(int,int,int,int);
    Tache(string,int,int,int,int);
    Tache(const Tache&);

    //destructeur
    ~Tache();

    //setters et getters
    void setRi(int);
    int getRi()const;
    void setCi(int);
    int getCi()const;
    void setDi(int);
    int getDi()const;
    void setPi(int);
    int getPi()const;
    string getId()const;

    //affichage d'une tache
    void afficher(ostream&)const;
    //surcharge de l'operateur d'egalite
    bool operator==(const Tache&);

    private:

    string _idTache;         //identifiant d'une tache
    int _ri;                 //date de reveil
    int _Ci;                 //duree d'execution maximale
    int _Di;                 //delai critique
    int _Pi;                 //periode d'activation


    static int _nbTaches;   //compteur d'instances
    };

//surcharge de l'operateur de flux
ostream& operator<<(ostream&, const Tache&);

#endif // TACHE_H_INCLUDED
