package test.junit.decouverte;

import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import controleur.ChercheurDeJars;

import decouverte.DecouverteAvecFichierXml;

/**
 * @author stephane
 *
 */
public class DecouverteAvecFichierXmlTest {
	/**
	 * La decouverte a tester.
	 */
	private DecouverteAvecFichierXml decouverte;
	
	/**
	 * Le chercheur participant au test.
	 */
	private ChercheurDeJars chercheur;

	/**
	 * Initialisation du test.
	 * @see junit.framework.TestCase#setUp()
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		this.decouverte= new DecouverteAvecFichierXml();
		this.chercheur = new ChercheurDeJars();
	}

	/**
	 * Test de la methode estJarValide.
	 */
	@org.testng.annotations.Test(groups="decouverte")
	@Test
	public void testEstJarValide() {
		String str = this.chercheur.getListeJars().get(0);
		File fichier = new File(str);
		
		if(decouverte.estJarValide(str))
		{
			assertTrue("Le fichier n'existe pas", fichier.exists());
			assertTrue("Le fichier est un repertoire", fichier.isFile());
		}
	}
	
	/**
	 * Test de la methode getRepertoireDeRecherche.
	 */
	@org.testng.annotations.Test(groups="decouverte")
	@Test
	public void testGetRepertoiresDeRecherche() {
		File fichier;
		for(String str : decouverte.getRepertoiresDeRecherche())
		{
			fichier = new File(str);
			assertTrue("Le repertoire n'existe pas", fichier.exists());
			assertTrue("Le repertoire est un fichier", fichier.isDirectory());
		}
	}

}
