<?

//
function affiche_requete($requete_sql){
   echo "<div class=\"requete\">\n";
   echo "<p>Requête SQL correspondante</p>\n";
   echo $requete_sql."\n";
   echo "</div>\n";
}

//
function trouve_stem($terme){
   $sql = "SELECT stem FROM stems WHERE terme='".$terme."'";
   $result = mysql_query($sql);
   $res_stem = mysql_fetch_array($result);
   $stem = $res_stem['stem'];
   return $stem;
}

// 
function est_stopword($terme){
   $sql = "SELECT stopword FROM stopwords WHERE stopword='".$terme."'";
   echo "*".$sql."*\n";
   $result = mysql_query($sql);
   $res_stopword = mysql_fetch_array($result);
   $stopword = $res_stopword['stopword'];
   return ($stopword ==="");
}

//
function recherche_booleenne_all($mots_cles){
   global $tableau_stems;
   $mots_cles = traite_ponctuation_casse($mots_cles);

   // construction de la requete sql
   $tab_mots = explode(" ",$mots_cles);
   $requete_sql = "SELECT docno FROM documents WHERE ";
   $cpt_stem = 1;
   for($cpt=0;$cpt<count($tab_mots)-1;$cpt++){
      $stem = trouve_stem($tab_mots[$cpt]);
      if($stem !=""){
         $requete_sql .= "stem='".$stem."' OR ";
         $cpt_stem++;
      }
   }
   //$stem = $tableau_stems[$tab_mots[$cpt]];
   $stem = trouve_stem($tab_mots[$cpt]);
   $requete_sql .= "stem='".$stem."'";
   
   $requete_sql .= " GROUP BY docno";
   $requete_sql .= " HAVING count(stem)=".$cpt_stem."";
   
   affiche_requete($requete_sql);
   
   $result = mysql_query($requete_sql);
   
   echo "<h2>".mysql_num_rows($result)." documents trouvés</h2>";
   echo "<table border=\"1\" style=\"width:100%;\">";
   echo "<tr><th>DocN°</th></tr>";
   while($res_recherche = mysql_fetch_array($result)){
      echo "<tr><td>".$res_recherche['docno']."</td></tr>\r";
   }
   echo "</table>";
}

function recherche_booleenne_plus($mots_cles){
   global $tableau_stems;
   $mots_cles = traite_ponctuation_casse($mots_cles);

   // construction de la requete sql
   $tab_mots = explode(" ",$mots_cles);
   $requete_sql = "SELECT docno,count(stem) FROM documents WHERE ";
   $cpt_stem = 1;
   for($cpt=0;$cpt<count($tab_mots)-1;$cpt++){
      $stem = trouve_stem($tab_mots[$cpt]);
      if($stem !=""){
         $requete_sql .= "stem='".$stem."' OR ";
         $cpt_stem++;
      }
   }
   //$stem = $tableau_stems[$tab_mots[$cpt]];
   $stem = trouve_stem($tab_mots[$cpt]);
   $requete_sql .= "stem='".$stem."'";
   
   $requete_sql .= " GROUP BY docno";
   affiche_requete($requete_sql);
   
   $result = mysql_query($requete_sql);
   
   echo "<h2>".mysql_num_rows($result)." documents trouvés</h2>";
   echo "<table border=\"1\" style=\"width:100%;\">";
   echo "<tr><th>DocN°</th><th>Nombre de stem trouvés</th></tr>";
   while($res_recherche = mysql_fetch_array($result)){
      echo "<tr><td>".$res_recherche['docno']."</td><td>".$res_recherche['count(stem)']."</td></tr>\r";
   }
   echo "</table>";
}

function recherche_vectorielle_docs($mots_cles){
   global $tableau_stems;

   $mots_cles = traite_ponctuation_casse($mots_cles);

   // construction de la requete sql
   $tab_mots = explode(" ",$mots_cles);
   $requete_sql = "SELECT docno,count(stem),sum(nbocc) FROM documents WHERE ";
   for($cpt=0;$cpt<count($tab_mots)-1;$cpt++){
      $stem = trouve_stem($tab_mots[$cpt]);
      if($stem !="")
         $requete_sql .= "stem='".$stem."' OR ";
   }
   $stem = trouve_stem($tab_mots[$cpt]);
   $requete_sql .= "stem='".$stem."'";
   
   $requete_sql .= " GROUP BY docno";
   $requete_sql .= " ORDER BY count(stem) DESC, sum(nbocc) DESC";
   
   affiche_requete($requete_sql);
   
   $result = mysql_query($requete_sql);

   echo "<h2>".mysql_num_rows($result)." documents trouvés</h2>";
   echo "<table border=\"1\" style=\"width:100%;\">";
   echo "<tr><th>DocN°</th><th>Nombre de stem trouvés</th><th>Somme des occurences des stems</th></tr>";
   while($res_recherche = mysql_fetch_array($result)){
      echo "<tr><td>".$res_recherche['docno']."</td><td>".$res_recherche['count(stem)']."</td><td>".$res_recherche['sum(nbocc)']."</td></tr>\r";
   }
   echo "</table>";
}

?>

