#include "afer.h"
#include "afdet.h"
#include "emondage.h"
#include "completion.h"
#include "minimisation.h"
#include "mt.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*********************************************************/
/***************** Programme principal *******************/
/*********************************************************/

int main(int nb, char * argv[])
{

   // Structures de donnees utilisees pour stocker les informations d'une matrice de transition. Nous avons choisi d'utiliser des listes
   struct Liste_chaine * liste_etats_initiaux = NULL;
   struct Liste_chaine * liste_etats_finaux = NULL;
   struct Liste_chaine * liste_etats = NULL;
   struct Liste_chaine * liste_symboles = NULL;
   struct Liste_regle * liste_des_regles = NULL;

   printf("%s","**************************************************\n");
   printf("%s%s%s","Test des algorithmes sur le fichier \"",argv[1],"\"\n");
   printf("%s","**************************************************\n\n");

   /*** LECTURE DU FICHIER TEXTE ***/
   lecture_matrice(argv[1],&liste_etats_initiaux,&liste_etats_finaux,&liste_etats,&liste_symboles,&liste_des_regles);
   printf("%s","Affichage de la matrice apres lecture du fichier :\n");
   affiche_matrice(liste_etats_initiaux,liste_etats_finaux,liste_etats,liste_symboles,liste_des_regles);

   /*** EMONDAGE ET COMPLETION ***/
   emondage(&liste_des_regles,&liste_etats_initiaux,&liste_etats_finaux,&liste_etats);
   completion(&liste_etats_initiaux,&liste_etats_finaux,&liste_etats,&liste_symboles,&liste_des_regles);
   printf("%s","Affichage apres emondage et completion :\n");
   affiche_matrice(liste_etats_initiaux,liste_etats_finaux,liste_etats,liste_symboles,liste_des_regles);

   /*** DETERMINISATION ***/
   determinisation(&liste_etats_initiaux,&liste_etats_finaux,&liste_etats,&liste_symboles,&liste_des_regles);
   printf("%s","Affichage apres determinisation :\n");
   affiche_matrice(liste_etats_initiaux,liste_etats_finaux,liste_etats,liste_symboles,liste_des_regles);

   /*** MINIMISATION ***/
   minimisation(&liste_des_regles,&liste_etats_initiaux,&liste_etats_finaux,&liste_etats,liste_symboles);
   printf("%s","Affichage apres minimisation :\n");
   affiche_matrice(liste_etats_initiaux,liste_etats_finaux,liste_etats,liste_symboles,liste_des_regles);
  
   /*** AFER ***/
   char * expreg = afer(&liste_etats_initiaux,&liste_etats_finaux,&liste_etats,&liste_symboles,&liste_des_regles);
   
   printf("%s%s%s","> Expression reguliere correspondant au fichier \"",argv[1],"\" : ");
   printf("%s%s",expreg,"\n\n");
   printf("%s","Affichage apres afer :\n");
   affiche_matrice(liste_etats_initiaux,liste_etats_finaux,liste_etats,liste_symboles,liste_des_regles);
   
   
   /* Utilisation de LEX */
   
   // D abord on ecrit le fichier lex en cherchant l expression reguliere donnee par AFER
   FILE * f_lexyacc;
   f_lexyacc = fopen("parseur.l","w");
   
   fprintf(f_lexyacc,"\%\%{\n#include \"mt.h\"\nstruct Liste_chaine * mots_reconnus=NULL;\nchar * mot;\n%}\n");
   fprintf(f_lexyacc,"\%\%\%\%\n%s {mot=(char*)calloc(2500,sizeof(char)); ajout_liste_en_queue(strncpy(mot,yytext,yyleng),&mots_reconnus);}ECHO;\n\%\%\%\%\n",expreg);
   fprintf(f_lexyacc,"int yywrap(void){\nreturn 1;\n}\n");
   fprintf(f_lexyacc,"int main(void){\nyylex();\nprintf(\"\\n> Liste des mots reconnus par l'ER dans le fichier 'fic_entree.txt' : \");\naffiche_liste_chaine(mots_reconnus);\n}\n");
   fclose(f_lexyacc);
   
   // Appel systeme permettant de creer le fichier executable de l analyseur nomme "analyse_syntaxe" 
   // et de le lancer sur le fichier d entree "fic_entree.txt"
   system("lex parseur.l;gcc -c lex.yy.c; gcc -o analyse_syntaxe -lm mt.o lex.yy.o -lfl;./analyse_syntaxe <fic_entree.txt");
   
   // Ici on fait un appel systeme afin de supprimer les fichiers de l'analyseur une fois qu'ils ont été utilisés
   // Afin de pouvoir relancer prog_test sans souscis de compilations
   system("rm parseur.l lex.yy.o lex.yy.c analyse_syntaxe");
   
   return 0;
}

