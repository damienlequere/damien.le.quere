package controleur;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import principal.Sunshine;

import modele.Modele;

/**
 * Le controleur a pour but de trouver les jars valides.
 * Une fois ceux ci trouve, il les transmettra au modele.
 * @author stephane
 */
public class Controleur {
	/**
	 * Le logger de Controleur.
	 */
	private static final Logger LOGGER = Logger.getLogger("controleur.Controleur");
	
	/**
	 * Le modele contient les donnees.
	 */
	private Modele modele;
	
	/**
	 * Le chercheur de jars nous renseigne sur tous les fichiers jars disponibles.
	 */
	private final ChercheurDeJars chercheurDeJars;
	
	/**
	 * Constructeur par defaut.
	 */
	public Controleur() {
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "Controleur", e);
		}
		
		this.chercheurDeJars = new ChercheurDeJars();
	}
	
	/**
	 * Permet de controler l'operation avant de la deleguer au modele.
	 * @param operateur L'operateur de l'operation.
	 * @param argument Le(s) argument(s) de l'operation.
	 */
	public void controle(String operateur, Object argument) {
		LOGGER.entering(this.getClass().getName(), "controle", new Object[] {operateur, argument});
		
		if(operateur.equalsIgnoreCase("preparer_les_programmes"))
		{
			LOGGER.log(Level.INFO, "Preparer les programmes");
			this.modele.setOperateur(operateur);
			List<Object> liste = new ArrayList<Object>();
			liste.add(this.chercheurDeJars.getListeJars());
			liste.add(this.chercheurDeJars.getDecouverte());
			this.modele.setArgument(liste);
			this.modele.effectueOperation();
		}
		if(operateur.equalsIgnoreCase("charger_un_programme"))
		{
			LOGGER.log(Level.INFO, "Charger un programme");
			this.modele.setOperateur(operateur);
			this.modele.setArgument(argument);
			this.modele.effectueOperation();
		}
		if(operateur.equalsIgnoreCase("stopper_un_programme"))
		{
			LOGGER.log(Level.INFO, "Stopper un programme");
			this.modele.setOperateur(operateur);
			this.modele.setArgument(argument);
			this.modele.effectueOperation();
		}
		
		LOGGER.exiting(this.getClass().getName(), "controle");
	}
	
	/**
	 * Permet de changer de modele de donnees.
	 * Utilise uniquement a l'initialisation normalement.
	 * @param modele Le modele de donnees.
	 */
	public void setModele(Modele modele) {
		LOGGER.entering(this.getClass().getName(), "setModele", modele);
		LOGGER.exiting(this.getClass().getName(), "setModele");
		this.modele = modele;
	}
	
	/**
	 * Permet de recuperer le modele de donnees.
	 * @return Le modele de donnees.
	 */
	public Modele getModele() {
		LOGGER.entering(this.getClass().getName(), "getModele");
		LOGGER.exiting(this.getClass().getName(), "getModele", this.modele);
		return this.modele;
	}
}
