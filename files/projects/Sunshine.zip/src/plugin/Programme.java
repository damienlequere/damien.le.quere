package plugin;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import principal.Sunshine;

/**
 * La classe programme permet de definir un conteneur permettant de 
 * conserver toutes les donnees sur les differentes classes et les 
 * differents jars contenant les classes d'un plugin.
 * @author stephane
 */
public class Programme implements Runnable {
	/**
	 * Le logger de ChercheurDeJars.
	 */
	private static final Logger LOGGER = Logger.getLogger("plugin.Programme");
	
	/**
	 * Le jar contenant le controleur.
	 */
	private String controleurJar = "";
	
	/**
	 * Le jar contenant le modele.
	 */
	private String modeleJar = "";
	
	/**
	 * Les jars contenant les vues.
	 */
	private final List<String> vueJar = new ArrayList<String>();
	
	/**
	 * La classe de controleur.
	 */
	private String controleurClasse = "";
	
	/**
	 * La classe de modele.
	 */
	private String modeleClasse = "";
	
	/**
	 * Les classes de vue.
	 */
	private final List<String> vueClasses = new ArrayList<String>();
	
	/**
	 * Le nom du programme.
	 */
	private final String nom;
	
	/**
	 * La version du programme.
	 */
	private final String version;
	
	/**
	 * Constructeur.
	 * @param nom Le nom du programme.
	 * @param version La version du programme.
	 */
	public Programme(String nom, String version) {
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "Programme", e);
		}
		
		this.nom = nom;
		this.version = version;
	}
	
	/**
	 * Indique si le programme est bien initialise.
	 * @return Si le programme est bien initialise.
	 */
	public boolean estPret() {
		boolean jarsInitialises = false;
		boolean classesInitialisees = false;
		
		if((!controleurJar.equalsIgnoreCase("")) && (!modeleJar.equalsIgnoreCase("")) && (!vueJar.isEmpty()))
		{
			jarsInitialises = true;
		}
		if((!controleurClasse.equalsIgnoreCase("")) && (!modeleClasse.equalsIgnoreCase("")) && (!vueClasses.isEmpty()))
		{
			classesInitialisees = true;
		}
		
		return ((jarsInitialises) && (classesInitialisees));
	}

	/**
	 * Renvoie un string representant le programme.
	 * @return Un string representant le programme. 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return this.nom + " v" + this.version;
	}
	
	/**
	 * Permet d'ajouter une classe de modele au programme.
	 * @param nomJar Le jar ou se trouve la classe.
	 * @param nomClasse Le nom de la classe.
	 */
	public void addModele(String nomJar, String nomClasse) {
		this.modeleJar = nomJar;
		this.modeleClasse = nomClasse;
	}
	
	/**
	 * Permet d'ajouter une classe de controleur au programme.
	 * @param nomJar Le jar ou se trouve la classe.
	 * @param nomClasse Le nom du la classe.
	 */
	public void addControleur(String nomJar, String nomClasse) {
		this.controleurJar = nomJar;
		this.controleurClasse = nomClasse;
	}
	
	/**
	 * Permet d'ajouter des classes de vue au programme.
	 * @param nomJar Le jar ou se toruve la classe.
	 * @param nomClasse Le nom de la classe.
	 */
	public void addVue(String nomJar, String nomClasse) {
		this.vueJar.add(nomJar);
		this.vueClasses.add(nomClasse);
	}
	
	/**
	 * Renvoie le nom du jar qui contient la classe de controleur.
	 * @return Le nom du jar qui contient la classe de controleur.
	 */
	public String getControleurJar() {
		return controleurJar;
	}

	/**
	 * Renvoie le nom du jar qui contient la classe de modele.
	 * @return Le nom du jar qui contient la classe de modele.
	 */
	public String getModeleJar() {
		return modeleJar;
	}

	/**
	 * Renvoie les noms des jars qui contiennent une classe de vue.
	 * @return Les noms des jars qui contiennent une classe de vue.
	 */
	public List<String> getVueJar() {
		return vueJar;
	}

	/**
	 * Renvoie le nom de la classe du controleur.
	 * @return Le nom de la classe du controleur.
	 */
	public String getControleurClasse() {
		return controleurClasse;
	}

	/**
	 * Renvoie le nom de la classe du modele.
	 * @return Le nom de la classe du modele.
	 */
	public String getModeleClasse() {
		return modeleClasse;
	}

	/**
	 * Renvoie les noms des classes de vue.
	 * @return Les noms des classes de vue.
	 */
	public List<String> getVueClasses() {
		return vueClasses;
	}

	/**
	 * Renvoie le nom du programme.
	 * @return Le nom du programme.
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * Renvoie la version du programme.
	 * @return La version du programe.
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Lance le programme.
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		LOGGER.entering(this.getClass().getName(), "run");
		ControleurAbstrait controleur = null;
		ModeleAbstrait modele = null;
		List<VueAbstraite> vueList = null;
		LOGGER.log(Level.INFO, "Lancement du programme");
		try
		{
			URLClassLoader loaderControleur = new URLClassLoader(new URL[] {new File(this.controleurJar).toURI().toURL()});
			URLClassLoader loaderModele = new URLClassLoader(new URL[] {new File(this.modeleJar).toURI().toURL()});
			List<URLClassLoader> loaderVue = new ArrayList<URLClassLoader>();
			
			for(int cpt = 0; cpt < this.vueJar.size(); cpt++)
			{
				URL u = new File(this.vueJar.get(0)).toURI().toURL();
				loaderVue.add(new URLClassLoader(new URL[] {u}));
				
			}
			LOGGER.log(Level.INFO, "Les classes loader sont initialises");
			Class<?> classeControleur = Class.forName(this.controleurClasse, true, loaderControleur);
			Class<?> classeModele = Class.forName(this.modeleClasse, true, loaderModele);
			
			List<Class<?>> classeVue = new ArrayList<Class<?>>();
			for(int cpt = 0; cpt < this.vueClasses.size(); cpt++)
			{
				Class<?> classeVueTmp = Class.forName(this.vueClasses.get(cpt), true, loaderVue.get(cpt));
				classeVue.add(classeVueTmp);
			}
			LOGGER.log(Level.INFO, "Les classes sont initialises");
			controleur = (ControleurAbstrait) classeControleur.newInstance();
			modele = (ModeleAbstrait) classeModele.newInstance();
			
			vueList = new ArrayList<VueAbstraite>();
			for(int cpt = 0; cpt < this.vueClasses.size(); cpt++)
			{
				vueList.add((VueAbstraite) classeVue.get(cpt).newInstance());
			}
			LOGGER.log(Level.INFO, "Les objets sont initialises");
			controleur.setModele(modele);
			for(VueAbstraite v : vueList)
			{
				v.setControleur(controleur);
				modele.addObserveur(v);
			}
			LOGGER.log(Level.INFO, "Pret pour l'initialisation");
			for(VueAbstraite vue : vueList)
			{
				vue.initialiser();
			}
			
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "run", e);
		}
		LOGGER.exiting(this.getClass().getName(), "run");
	}
}
