package test.junit.modele;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import decouverte.DecouverteSansFichierXml;

import plugin.Programme;
import modele.Modele;
import vue.Fenetre;

/**
 * Classe de test du modele.
 * @author stephane
 */
public class ModeleReTest {
	/**
	 * Le modele a tester.
	 */
	private Modele modele;
	
	/**
	 * Le mock de la fenetre.
	 */
	private Fenetre fenetre;
	
	/**
	 * Initialisation des tests.
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		this.modele = new Modele();
		this.fenetre = new Fenetre();
	}
	
	/**
	 * Test de la methode notifyObserveur.
	 */
	@org.testng.annotations.Test(groups="modele")
	@Test
	public void testNotifyObserveur() {
		assertNull("Il y a un programme du nom de calcul", fenetre.getProgramme("calcul"));
		
		modele.addObserveur(fenetre);
		modele.setOperateur("preparer_les_programmes");
		
		ArrayList<Object> argument = new ArrayList<Object>();
		ArrayList<String> liste = new ArrayList<String>();
		liste.add(System.getProperty("user.dir")+"/plugins/calcul.jar");
		argument.add(liste);
		argument.add(new DecouverteSansFichierXml());
		modele.setArgument(argument);
		modele.effectueOperation();
		
		Programme p = fenetre.getProgramme("calcul");
		assertNotNull("Il n'y a pas de programme du nom de calcul", p);
		assertEquals("Le nom du programme est incorrect", "Calcul", p.getNom());
	}
}
