<?

$rep = "./docs/";
$dir = opendir($rep);

while ($f = readdir($dir)){
      if(is_file($rep.$f)){
         $fp = fopen($rep.$f,"r");
         $fp2 = fopen("./docs2/".$f,"w");
         fputs($fp2,"<DOCS>\r");
         while (!feof($fp)){
            fputs($fp2,fgets($fp, 4096));
         }
         fputs($fp2,"</DOCS>\r");
         fclose($fp2);
         fclose($fp);
      }
   }
   closedir($dir);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Génération des documents valides</title>

<link rel="stylesheet" type="text/css" media="screen" href="ecran.css" />

</head>

<body>

<h1>Génération des documents valides</h1>

<p><a href="index.php" title="">Retour à l'accueil</a></p>

</body>

</html>
