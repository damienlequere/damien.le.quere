package serveur;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

public class InsertionDonnees {

	public static Connection con;
	public static Statement stmt;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// CONNEXION A LA BASE DE DONNEES
		String	nomBase	= args[0],
		proprietaire = args[1],
		passwd = args[2];
		try {
            con = DriverManager.getConnection("jdbc:postgresql:" + nomBase, proprietaire, passwd);
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
        } catch (SQLException e) { e.printStackTrace(); }
		
        System.out.println("Suppression des donnees des tables 'pilotes' et 'course'");
        // SUPPRESSION DES TABLES EXISTANTES
        try {
        	stmt.executeUpdate("DROP TABLE course;");
        	stmt.executeUpdate("DROP TABLE pilotes;");
        	stmt.executeUpdate("CREATE TABLE course (num_pilote integer, tour integer, temps float);");
        	stmt.executeUpdate("CREATE TABLE pilotes (num_pilote integer, nom_pilote varchar(30));");
		} catch (SQLException e) {
			System.out.println("Erreur lors de l'insertion des valeurs dans pilotes\n"+e.getMessage());
			e.printStackTrace();
		}
        
        // INSERTION DANS LA TABLE COURSE
		String fichierCourse = "ressources/2009-17_Abu-Dhabi_Chronos.csv";
		System.out.println("Insertion des donnees de '"+fichierCourse+"'...");
		try{
			InputStream ips=new FileInputStream(fichierCourse); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String ligne;
			
			// On passe la première ligne
			ligne=br.readLine();
			
			while ((ligne=br.readLine())!=null){
				traiteLigneCourse(ligne);
			}
			br.close(); 
		}		
		catch (Exception e){ System.out.println(e.getMessage()); }
		
		System.out.println("Insertion dans "+nomBase+":course terminee");
		
		// INSERTION DANS LA TABLE PILOTES
		String fichierPilotes = "ressources/2009-17_Abu-Dhabi_Pilotes.csv";
		System.out.println("Insertion des donnees de '"+fichierPilotes+"'...");
		try{
			InputStream ips=new FileInputStream(fichierPilotes); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String ligne;
			
			while ((ligne=br.readLine())!=null){
				traiteLignePilote(ligne);
			}
			br.close(); 
		}		
		catch (Exception e){ System.out.println(e.getMessage()); }
		
		System.out.println("Insertion dans "+nomBase+":pilotes terminee");
	}


	private static void traiteLigneCourse(String ligne) {
		StringTokenizer st = new StringTokenizer(ligne, ";");
		
		String pilote = st.nextToken();
		String tour = st.nextToken();
		String temps = st.nextToken();
		
		temps = temps.replaceAll(",", ".");
		
		String requete = "INSERT INTO course VALUES ("+pilote+","+tour+","+temps+")";
		
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			System.out.println("Erreur lors de l'insertion des valeurs dans course\n"+e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	private static void traiteLignePilote(String ligne) {
		StringTokenizer st = new StringTokenizer(ligne, ";");
		
		Integer numPilote = Integer.parseInt(st.nextToken());
		String nomPilote = st.nextToken();
		
		String requete = "INSERT INTO pilotes VALUES ("+numPilote+",'"+nomPilote+"'"+");";
		
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			System.out.println("Erreur lors de l'insertion des valeurs dans pilotes\n"+e.getMessage());
			e.printStackTrace();
		}
	}

}
