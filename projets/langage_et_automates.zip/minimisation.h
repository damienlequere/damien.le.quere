/***************************************************************
* NOTE SUR CE FICHIER :
* Ce fichier contient le module MINIMISATION et les fonctions necessaires
* a son fonctionnement.
* On a aussi un module permettant d enlever l etat puits et
* toutes ses regles.
***************************************************************/

#include "mt.h"
#include "afdet.h"

#ifndef MINIMISATION_H
#define MINIMISATION_H

//                
int sont_etats_de_classes_differentes(char * etatA,
                                      char * etatB,
                                      struct Liste_de_listes * Ens_Des_Classes);
                                      
                                      
//                                    
int sont_distingables(char * etatA,
                      char * etatB,
                      struct Liste_regle * liste_des_regles,
                      struct Liste_de_listes * Ens_Des_Classes,
                      struct Liste_chaine * liste_symboles);
                            

/* MINIMISATION : 
* Module de minimisation prenant une matrice de transitionen entree / sortie
*
* IMPORTANT : la matrice doit avoir ete emondee, completee et determinisee
*  avant d'utiliser ce module
***********************************************************************/
void minimisation(struct Liste_regle ** liste_des_regles, 
                  struct Liste_chaine ** liste_etats_initiaux,
                  struct Liste_chaine ** liste_etats_finaux,
                  struct Liste_chaine ** liste_etats_utiles,
                  struct Liste_chaine * liste_symboles);
                  
                  
                  
#endif
