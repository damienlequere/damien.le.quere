#ifndef GESTIONNNAIRE_STATS_H_INCLUDED
#define GESTIONNNAIRE_STATS_H_INCLUDED

#include<list>
#include<iostream>

using namespace std;

class Gestionnaire_stats{

    public:

    Gestionnaire_stats(int duree);
    void ajout_preemption();
    void ajout_temps_creux();
    void ajout_temps_reponse_TAPNC(int temps);
    float temps_reponse_moyen_TAPNC();
    int temps_CPU();
    int nb_preemptions();
    float taux_preemption();

    private:

    int _duree_simulation;
    int _nb_temps_creux;
    int _nb_preemptions;
    list<int> *_temps_reponse_TAPNC;

};
#endif // GESTIONNNAIRE_STATS_H_INCLUDED
