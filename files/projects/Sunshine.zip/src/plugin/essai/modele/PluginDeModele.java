package plugin.essai.modele;

import java.util.ArrayList;
import java.util.List;

import plugin.ModeleAbstrait;
import plugin.PluginObserveur;

/**
 * Exemple d'implementation de l'interface de ModeleAbstrait.
 * @author stephane
 */
public class PluginDeModele implements ModeleAbstrait {
	/**
	 * La liste des observeurs du modele.
	 */
	private final List<PluginObserveur> observeurs;
	
	/**
	 * L'operateur du calcul.
	 */
	private String operateur;
	
	/**
	 * Le(s) argument(s) du calcul.
	 */
	private String argument;
	
	/**
	 * Le resultat du calcul.
	 */
	private int resultat;
	
	/**
	 * Constructeur par defaut.
	 */
	public PluginDeModele() {
		this.resultat = 0;
		this.observeurs = new ArrayList<PluginObserveur>();
	}
	
	/**
	 * Lance l'operation.
	 * @see plugin.ModeleAbstrait#effectueOperation()
	 */
	public void effectueOperation() {
		if("+".equals(operateur))
		{
			resultat += Integer.parseInt(argument);
		}
		if("-".equals(operateur))
		{
			resultat -= Integer.parseInt(argument);
		}
		if("*".equals(operateur))
		{
			resultat *= Integer.parseInt(argument);
		}
		this.notifyObserveur(resultat);
	}

	/**
	 * Permet de changer le(s) argument(s) de l'operation.
	 * @param argument Le(s) argument(s) de l'operation.
	 * @see plugin.ModeleAbstrait#setArguments(java.lang.Object)
	 */
	public void setArguments(Object argument) {
		this.argument = String.valueOf((Integer) argument);
	}

	/**
	 * Permet de changer l'operateur du calcul.
	 * @param operateur L'operateur du calcul.
	 * @see plugin.ModeleAbstrait#setOperateur(java.lang.String)
	 */
	public void setOperateur(String operateur) {
		this.operateur = operateur;
	}

	/**
	 * Ajouter un observeur sur le modele.
	 * @param o L'observeur a ajouter.
	 * @see plugin.PluginObservable#addObserveur(plugin.PluginObserveur)
	 */
	public void addObserveur(PluginObserveur o) {
		this.observeurs.add(o);
	}

	/**
	 * Notifier les observeurs.
	 * @param o Les donnees a transmettre aux observeurs.
	 * @see plugin.PluginObservable#notifyObserveur(java.lang.Object)
	 */
	public void notifyObserveur(Object o) {
		for(PluginObserveur pO : this.observeurs) {
			pO.update(o);
		}
	}

	/**
	 * Supprime un observeur.
	 * @param o L'observeur a supprimer.
	 * @see plugin.PluginObservable#removeObserveur(plugin.PluginObserveur)
	 */
	public void removeObserveur(PluginObserveur o) {
		this.observeurs.remove(o);
	}

	/**
	 * Renvoie le nom du plugin.
	 * @return Le nom du plugin.
	 * @see plugin.Plugin#getNom()
	 */
	public String getNom() {
		return "Plugin de modele";
	}

}
