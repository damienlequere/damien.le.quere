#include <iostream>
#include <string>
#include <list>
#include"generateur.h"
#include"simulateur.h"

using namespace std;

//affichage du menu principal
int afficher_menu(){
    int choix;
    cout << endl;
    cout << "Que voulez-vous faire?" << endl << endl
         << "1- Générer une liste de taches aléatoirement" << endl
         << "2- Créer une liste de tâches manuellement" << endl
         << "3- Ajouter une tâche à une liste" << endl
         << "4- Retirer une tâche d'une liste" << endl
         << "5- Visualiser une liste" << endl
         << "6- Réinitialiser une liste" << endl
         << "7- Lancer une simulation" << endl
         << "8- Quitter" << endl;
    cout << endl << "Choix : ";
    cin >> choix;
    cout << endl;
    return choix;
    };

//affichage du sous menu pour le choix du type d'ordonnancement
int affiche_menu_ord(){
    int choix;
    cout << "Quel type d'ordonnancement voulez-vous simuler? " << endl << endl;
    cout << "   1- RM (tâches apériodiques non prises en compte)" << endl;
    cout << "   2- EDF (tâches apériodiques non prises en compte)" << endl;
    cout << "   --------------------------" << endl;
    cout << "   3- Background Scheduling (Avec RM ou EDF)" << endl;
    cout << "   4- Polling Server (PS avec RM)" << endl;
    cout << "   5- Earliest Deadline as Late as possible (EDL avec EDF)" << endl;
    cout << endl << "Choix : ";
    cin >> choix;
    cout << endl;
    if (choix == 3){
        cout << "Quel type d'ordonnancement souhaitez-vous pour gérer les tâches périodiques?" << endl << endl;
        cout << "   1- Rate Monotonic (RM)" << endl;
        cout << "   2- Earliest Deadline First (EDF)" << endl;
        cout << endl << "Choix : ";
        cin >> choix;
        choix+=5;
    }
    return choix;
    };

//retourne la liste de taches d'un ensemble donné avec un nom donné
ListeTaches *rechercheListeTaches(string nom, const list<ListeTaches*> ensemblesTaches){
    ListeTaches * resultat = NULL;
    list<ListeTaches*>::const_iterator it;

    for( it = ensemblesTaches.begin(); it != ensemblesTaches.end(); it ++ ){
        if ((*it)->getName() == nom)
            resultat =  (*it);
        }
    return resultat;
    };


/*===========================================*/
/*== POINT D'ENTRÉE DU PROGRAMME PRINCIPAL ==*/
/*===========================================*/

int main(){

    //initialisation de la graine avec l'horloge du processeur
    //utile à la fonction rand() retournant un nombre aléatoire
    //la fonction rand() est utilisee dans le générateur de tâches
    srand(time(NULL));
    int choix = 0;
    list<ListeTaches*> ensemblesTaches;   //l'ensemble de listes de taches de l'utilisateur

    while(choix != 8){

        choix = afficher_menu();

        switch(choix){
            case 1:
            {
                string nom;
                int nbtp,nbta;
                float up, us;

                cout << "*** GÉNÉRATION D'UNE LISTE DE TÂCHES ***" << endl << endl;
                cout << "Nom de votre liste de tâches : "; cin >> nom;
                if (rechercheListeTaches(nom,ensemblesTaches) == NULL){

                    //
                    cout << "Nombre de tâches périodiques : "; cin >> nbtp;
                    cout << "Up : "; cin >> up;
                    while( (up>= 0.693) || (up <= 0) ){
                        cout << "! Up doit être compris entre 0 et 0.693 !" << endl << "(afin de garantir l'ordonnancabilité avec n'importe quel type d'ordonnancement)" << endl;
                        cout << "Up : "; cin >> up;
                        }

                    //
                    cout << "Nombre de tâches apériodiques : "; cin >> nbta;
                    cout << "Us : "; cin >> us;
                    while( (us <=0) || (us+up >1) ){
                        cout << "! Us doit être compris supérieur à 0 et la somme Up+Us ne doit pas dépasser 1 !" << endl;
                        cout << "Us : "; cin >> us;
                        }

                    //
                    ensemblesTaches.push_back(Generateur::genTaches(nom,nbtp,up,nbta,us));
                    cout << endl << ">>la liste de tâches a bien été générée" << endl;
                }else
                    cout << "! Une liste de tâches portant le même nom existe déjà !" << endl;
            }
            break;
            case 2:
            {
                string nom;
                int Ri,Ci,Di,Pi;

                cout << "*** CRÉATION MANUELLE D'UNE LISTE DE TÂCHES ***" << endl << endl;
                cout << "Donnez le nom de la liste de tâche : "; cin >> nom; cout << endl;

                if (rechercheListeTaches(nom,ensemblesTaches) == NULL){
                    ListeTaches * nouvelle_liste = new ListeTaches(nom);
                    ensemblesTaches.push_back(nouvelle_liste);
                    string continuer = "oui";
                    while(continuer == "oui"){
                    cout << "** création d'une tâche **" << endl;
                    cout << "Donnez Ri : "; cin >> Ri;
                    cout << "Donnez Ci : "; cin >> Ci;
                    cout << "Donnez Pi : "; cin >> Pi;
                    cout << "Donnez Di : "; cin >> Di;
                    rechercheListeTaches(nom,ensemblesTaches)->ajouter(Tache(Ri,Ci,Di,Pi));
                    cout << ">>la tâche a bien été ajoutée" << endl << endl;
                    cout << "Souhaitez-vous ajouter une autre tâche? (oui/non) : ";
                    cin >> continuer;
                    }
                }
                else
                    cout << "! Une liste de tâches portant le même nom existe déjà !" << endl;
            }
            break;
            case 3:
            {
                string nom;
                int Ri,Ci,Di,Pi;

                cout << "*** AJOUT D'UNE TACHE À UNE LISTE ***" << endl << endl;
                cout << "Donnez le nom de la liste de tâche : "; cin >> nom; cout << endl;

                if (rechercheListeTaches(nom,ensemblesTaches) != NULL){
                    string continuer = "oui";
                    while(continuer == "oui"){
                    cout << "** création d'une tâche **" << endl;
                    cout << "Donnez Ri : "; cin >> Ri;
                    cout << "Donnez Ci : "; cin >> Ci;
                    cout << "Donnez Di : "; cin >> Di;
                    cout << "Donnez Pi : "; cin >> Pi;
                    rechercheListeTaches(nom,ensemblesTaches)->ajouter(Tache(Ri,Ci,Di,Pi));
                    cout << ">>la tâche a bien été ajoutée" << endl << endl;
                    cout << "Souhaitez-vous ajouter une autre tâche? (oui/non) : ";
                    cin >> continuer;
                    }
                }
                else
                    cout << "! liste de tâches non trouvée !" << endl;
            }
            break;
            case 4:
            {
                string nom,
                       idTache;

                cout << "*** RETRAIT D'UNE TACHE D'UNE LISTE ***" << endl << endl;
                cout << "Donnez le nom de la liste de tâche : "; cin >> nom; cout << endl;

                if (rechercheListeTaches(nom,ensemblesTaches) != NULL){
                    cout << "Donnez L'identifiant de la tâche à supprimer : "; cin >> idTache; cout << endl;
                    if(rechercheListeTaches(nom,ensemblesTaches)->supprimer(idTache))
                        cout << ">>la tâche a bien été retirée" << endl;
                    else
                        cout << "! la tâche n'a pas été trouvée !" << endl;
                }
                else
                    cout << "! liste de tâches non trouvée !" << endl;
            }
            break;
            case 5:
            {
                string nom;

                cout << "*** VISUALISER UNE LISTE ***" << endl << endl;
                cout << "Quelle liste voulez-vous visualiser? : "; cin >> nom; cout << endl;
                if (rechercheListeTaches(nom,ensemblesTaches) != NULL)
                    rechercheListeTaches(nom,ensemblesTaches)->afficher(cout);
                else
                    cout << "! liste de tâches non trouvée !" << endl;
            }
            break;
            case 6:
            {
                string nom;

                cout << "*** RÉINITIALISER UNE LISTE ***" << endl << endl;
                cout << "Quelle liste voulez-vous réinitialiser? : "; cin >> nom; cout << endl;

                if (rechercheListeTaches(nom,ensemblesTaches) != NULL){
                    rechercheListeTaches(nom,ensemblesTaches)->reinitialiser();
                    cout << ">>la liste a bien été réinitialisée" << endl;
                }
                else
                    cout << "! liste de tâches non trouvée !" << endl;
            }
            break;
            case 7:
            {
                string nom;
                int dureeSim;
                int choixOrd = 0;
                ListeTaches * listTaches;

                cout << "*** SIMULATEUR D'ORDONNANCEMENT ***" << endl << endl;
                cout << "Sur quelle liste de tâches souhaitez-vous lancer la simulation? : "; cin >> nom; cout << endl;
                listTaches = rechercheListeTaches(nom,ensemblesTaches);
                if (listTaches != NULL){
                    choixOrd = affiche_menu_ord();
                    cout << "Fixez une durée de simulation (entier positif) : ";
                    cin >> dureeSim;
                    Simulateur sim(dureeSim);
                    sim.simuler_ordonnancement(listTaches,choixOrd,dureeSim);
                    sim.afficher_resultats_simulation(cout);
                    }else
                    cout << "! liste de tâches non trouvée !" << endl;
            }
            break;
            case 8:
            {
                cout << "Ciao" << endl << endl;
            }
            break;
            default:
            {
                cout << "Votre choix ne fait pas partie du menu" << endl;
            }
            break;
            }
        }

    return EXIT_SUCCESS;
}
