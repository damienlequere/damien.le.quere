package test.junit.plugin;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import plugin.Programme;

/**
 * @author stephane
 *
 */
public class ProgrammeTest {
	/**
	 * Le programme a tester.
	 */
	private Programme programme;
	
	/**
	 * Le groupe de test de testNG.
	 */
	private static final String GROUPE = "plugin";

	/**
	 * Initialisation du test.
	 * @see junit.framework.TestCase#setUp()
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		String pName = "ProgrammeDeTest";
		String vNumber = "1.0";
		this.programme = new Programme(pName, vNumber);
	}

	/**
	 * Test de la methode estPret.
	 */
	@org.testng.annotations.Test(groups=GROUPE)
	@Test
	public void testEstPret() {
		assertFalse("Le programme vide est pret", programme.estPret());
		
		String controleurJar = "controleurJar";
		String controleurClasse = "controleurClasse";
		String modeleJar = "modeleJar";
		String modeleClasse = "modeleClasse";
		String vueJar = "vueJar";
		String vueClasses = "vueClasse";
		
		programme.addControleur(controleurJar, controleurClasse);
		programme.addModele(modeleJar, modeleClasse);
		programme.addVue(vueJar, vueClasses);
		
		assertTrue("Le programme n'est pas pret", programme.estPret());
	}

	/**
	 * Test de la methode addModele.
	 */
	@org.testng.annotations.Test(groups=GROUPE)
	@Test
	public void testAddModele() {
		String nomJar = "nomJar";
		String nomClasse = "nomClasse";
		programme.addModele(nomJar, nomClasse);
		assertEquals("Le jar du modele n'est pas bon", nomJar, programme.getModeleJar());
		assertEquals("La classe du modele n'est pas bonne", nomClasse , programme.getModeleClasse());
	}

	/**
	 * Test de la methode addControleur.
	 */
	@org.testng.annotations.Test(groups=GROUPE)
	@Test
	public void testAddControleur() {
		String nomJar = "nomJar";
		String nomClasse = "nomClasse";
		programme.addControleur(nomJar, nomClasse);
		assertEquals("Le jar du controleur n'est pas bon", nomJar, programme.getControleurJar());
		assertEquals("La classe du controleur n'est pas bonne", nomClasse , programme.getControleurClasse());
	}

	/**
	 * Test de la methode addVue.
	 */
	@org.testng.annotations.Test(groups=GROUPE)
	@Test
	public void testAddVue() {
		String nomJar = "nomJar";
		String nomClasse = "nomClasse";
		programme.addVue(nomJar, nomClasse);
		assertTrue("Le jar de la vue n'est pas dans le programme", programme.getVueJar().contains(nomJar));
		assertTrue("La classe de la vue n'est pas dans le programme", programme.getVueClasses().contains(nomClasse));
	}
}
