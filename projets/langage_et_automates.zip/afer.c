#include "afer.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/**********************************************************************
* NOTE : Ce fichier contient le module AFER ainsi que des fonctions et
* procedures utiles a sont fonctionnement. 
* La fonction AFER est situee a la fin du fichier.
* IMPORTANT : L'algorithme AFER modifie les structures de donnees par
* effets de bords. Si l utilisateur souhaite récupérer les donnees de la
* matrice de transition il faut qu'il reutilise la fonction de lecture
* de matrice du fichier "mt.c" sur le fichier texte.
***********************************************************************/


/* AJOUT_ETAT_INITIAL : Pour tout etat Ei appartenant à l'ensemble des 
* etats initiaux on ajoute la transition i(^)->Ei où "^" est le symbole 
* correspondant à epsilon 
***********************************************************************/
void ajout_etat_initial(struct Liste_chaine ** liste_etats_initiaux, 
                        struct Liste_chaine ** liste_etats_finaux, 
                        struct Liste_chaine ** liste_etats,
                        struct Liste_chaine ** liste_symboles,
                        struct Liste_regle ** liste_des_regles)
{
   struct Liste_chaine * liste_etats_initiaux_bis = *liste_etats_initiaux;
   while (liste_etats_initiaux_bis!=NULL){

      // Definition de la nouvelle regle
      struct Regle r;
      r.etat_arrive = liste_etats_initiaux_bis->chaine;
      r.etat_depart = "i";
      r.symbole = "";

      // Ajout de la nouvelle regle dans la liste des regles
      ajout_regle_dans_liste(r,liste_des_regles);

      liste_etats_initiaux_bis = liste_etats_initiaux_bis->chaine_suivante;
   }
   (*liste_etats_initiaux)->chaine = "i";
   (*liste_etats_initiaux)->chaine_suivante = NULL;
}


/* AJOUT_ETAT_FINAL : Pour tout etat Ef appartenant à l'ensemble des etats 
* finaux on a la transition Ef(^)->f où "^" est le symbole correspondant à 
* epsilon
***********************************************************************/
void ajout_etat_final(struct Liste_chaine ** liste_etats_initiaux, 
                      struct Liste_chaine ** liste_etats_finaux, 
                      struct Liste_chaine ** liste_etats, 
                      struct Liste_chaine ** liste_symboles, 
                      struct Liste_regle ** liste_des_regles)
{
   struct Liste_chaine * liste_etats_finaux_bis = *liste_etats_finaux;

   while (liste_etats_finaux_bis!=NULL){
      // Definition de la nouvelle regle
      struct Regle r;
      r.etat_arrive = "f";
      r.etat_depart = liste_etats_finaux_bis->chaine;
      r.symbole = "";
      // Ajout de la nouvelle regle dans la liste des regles
      ajout_regle_dans_liste(r,liste_des_regles);

      liste_etats_finaux_bis = liste_etats_finaux_bis->chaine_suivante;
   }   
   (*liste_etats_finaux)->chaine = "f";
   (*liste_etats_finaux)->chaine_suivante = NULL;
}

/* AFFICHE_EXPRESSION_RATIONNELLE : 
* 
***********************************************************************/
void affiche_expression_rationnelle(char * expr)
{
   printf("%s%s%c", "e = ",expr,'\n');
}


/* ETAT_LE_MOINS_CONNECTE : 
* 
***********************************************************************/
char * etat_le_moins_connecte(struct Liste_chaine * liste_etats,
                              struct Liste_chaine ** liste_etats_traites,
                              struct Liste_regle * liste_de_regles)
{
   struct Liste_regle * liste_aux;
   struct Regle r;
   int nb_connexions;
   int comp1;
   int comp2;
   struct Liste_nb_occurence_de_mots * liste_nb_occur=NULL;
   int min = 0;
   char * etat;
   
   while(liste_etats!=NULL){
      nb_connexions = 0;
      liste_aux = liste_de_regles;
      if(!est_mot_de_la_liste(*liste_etats_traites,liste_etats->chaine)){
         while(liste_aux!=NULL){
            r = liste_aux->la_regle;
            comp1 = strcmp(liste_etats->chaine,r.etat_arrive);
            comp2 = strcmp(liste_etats->chaine,r.etat_depart);
            if((comp1==0 && comp2!=0) || (comp1!=0 && comp2==0)){
               nb_connexions++;
            }
            liste_aux=liste_aux->regle_suivante;
         }
         if(nb_connexions<min || min==0){
            min = nb_connexions;
            etat=liste_etats->chaine;
         }
      }
      liste_etats = liste_etats->chaine_suivante;
   }
   ajout_liste_en_tete(etat,liste_etats_traites);
   return etat;
}


/* RASSEMBLE_REGLES_DUN_ETAT : 
* 
***********************************************************************/
void rassemble_regles_entre_deux_etats(char * etat_depart,
                                       char * etat_arrive, 
                                       struct Liste_regle ** liste_de_regles)
{
   char * expression;
   expression = (char *)calloc(2500,sizeof(char));
   char * expression_aux;
   expression_aux = (char *)calloc(2500,sizeof(char));
   struct Regle r;
   struct Regle nouvelle_regle;
   char * car_parenthese_ouvrante;
   car_parenthese_ouvrante = (char *)calloc(1,sizeof(char));
   car_parenthese_ouvrante = "(";
   char * car_parenthese_fermante;
   car_parenthese_fermante = (char *)calloc(1,sizeof(char));
   car_parenthese_fermante = ")";
   nouvelle_regle.etat_arrive = etat_arrive;
   nouvelle_regle.etat_depart = etat_depart;
   int nb_concatenations = 0, nb_regles_supprimees = 0, comp1, comp2;

   struct Liste_regle * liste = *liste_de_regles;
   struct Liste_regle * liste_aux = liste->regle_suivante;
   while(liste_aux!=NULL){
      r = liste_aux->la_regle;
      comp1 = strcmp(r.etat_arrive,etat_arrive);
      comp2 = strcmp(r.etat_depart,etat_depart);
      if(comp1==0 && comp2==0){
         nb_regles_supprimees++;
         if (nb_concatenations > 0){
            if(strlen(r.symbole)!=0){
               nb_concatenations++;
               strcat(expression,"|");
               strcat(expression,r.symbole);
            }
         } else {
            if(strlen(r.symbole)!=0){
               nb_concatenations++;
               strcat(expression,r.symbole);
            }
         }
         struct Liste_regle * a_virer=liste_aux;
         liste->regle_suivante = liste_aux->regle_suivante;
         free(a_virer);
      } else {
         liste = liste_aux;
      }
      liste_aux = liste->regle_suivante;
   }
   r = (*liste_de_regles)->la_regle;
   comp1 = strcmp(r.etat_arrive,etat_arrive);
   comp2 = strcmp(r.etat_depart,etat_depart);
   if(comp1==0 && comp2==0){
      nb_regles_supprimees++;
      if (nb_concatenations > 0){
         if(strlen(r.symbole)!=0){
            nb_concatenations++;
            strcat(expression,"|");
            strcat(expression,r.symbole);
         }
      } else {
         if(strlen(r.symbole)!=0){
            nb_concatenations++;
            strcat(expression,r.symbole);
         }
      }
      struct Liste_regle * a_virer=*liste_de_regles;
      *liste_de_regles = (*liste_de_regles)->regle_suivante;
      free(a_virer);
   }

   if(nb_concatenations>1){
      strcat(expression_aux,car_parenthese_ouvrante);
      strcat(expression_aux,expression);
      strcat(expression_aux,car_parenthese_fermante);
      strcpy(expression,expression_aux);
   }
   if(nb_concatenations== 0 && nb_regles_supprimees>0){
      expression="";
   }
   if (nb_regles_supprimees>0){
      nouvelle_regle.symbole = expression;
      ajout_regle_dans_liste(nouvelle_regle,liste_de_regles);
   }
}


int expression_parenthese(char * expr){
	char * car_parenthese_ouvrante;
	car_parenthese_ouvrante = (char *)calloc(1,sizeof(char));
	car_parenthese_ouvrante = "(";
	char * car_parenthese_fermante;
	car_parenthese_fermante = (char *)calloc(1,sizeof(char));
	car_parenthese_fermante = ")";
	char * car;
	car = (char *)calloc(1,sizeof(char));
	int nb_contextes = 0;
	int comp1;
	int comp2;
	int i=0;
	strncpy(car,&expr[i],1);
	comp1 = strcmp(car_parenthese_ouvrante,car);
	if(comp1 == 0){nb_contextes = 1;}
	while(nb_contextes!=0){
		i++;
		strncpy(car,&expr[i],1);
		comp1 = strcmp(car_parenthese_ouvrante,car);
		comp2 = strcmp(car_parenthese_fermante,car);
		if(comp1 == 0){nb_contextes++;}
		if(comp2 == 0){nb_contextes--;}
	}
	//printf("%d%s%d%c",i,"    ",strlen(expr),'\n');
	if(i==strlen(expr)-1){
		return 1;
	} else {
		return 0;
	}
}

/* SUPPRESSION_DUN_ETAT : 
* 
***********************************************************************/
void suppression_dun_etat(char * etat, struct Liste_regle ** liste_de_regles, struct Liste_regle ** liste_de_nouvelles_regles){
	char * expression; 
	char * expression_boucle; // cette chaine permet de stocker l'expression rationnelle qui sert de transition à l'état pour retourner sur lui même
	expression_boucle = (char *)calloc(2500,sizeof(char));
	char * expression_aux;
	expression_aux = (char *)calloc(2500,sizeof(char));
	char * car_parenthese_ouvrante;
	car_parenthese_ouvrante = (char *)calloc(1,sizeof(char));
	car_parenthese_ouvrante = "(";
	char * car_parenthese_fermante;
	car_parenthese_fermante = (char *)calloc(1,sizeof(char));
	car_parenthese_fermante = ")";
	struct Regle r1;
	struct Regle r2;
	struct Regle nouvelle_regle;
	nouvelle_regle.etat_depart = etat;
	nouvelle_regle.etat_arrive = etat;
	int au_moins_une_expression = 0;
	int comp1;
	int comp2;
	int nb_concatenations= 0;

	struct Liste_regle * liste = *liste_de_regles;
	struct Liste_regle * liste_aux = liste->regle_suivante;
	while(liste_aux!=NULL){
		r1 = liste_aux->la_regle;
		comp1 = strcmp(r1.etat_arrive,etat);
		comp2 = strcmp(r1.etat_arrive,r1.etat_depart);
		if(comp1 == 0 && comp2 == 0){
			expression_boucle = r1.symbole;
			nb_concatenations++;
			struct Liste_regle * a_virer=liste_aux;
			liste->regle_suivante = liste_aux->regle_suivante;
			free(a_virer);
		} else {
			liste = liste_aux;
		}
		liste_aux = liste->regle_suivante;
	}
	r1 = (*liste_de_regles)->la_regle;
	comp1 = strcmp(r1.etat_arrive,etat);
	comp2 = strcmp(r1.etat_arrive,r1.etat_depart);
	if(comp1 == 0 && comp2 == 0){
		expression_boucle = r1.symbole;
		nb_concatenations++;
		struct Liste_regle * a_virer=*liste_de_regles;
		*liste_de_regles = (*liste_de_regles)->regle_suivante;
		free(a_virer);
	}
	if(nb_concatenations>1  || (strlen(expression_boucle)>1 && expression_parenthese(expression_boucle)==0)){
		strcat(expression_aux,car_parenthese_ouvrante);
		strcat(expression_aux,expression_boucle);
		strcat(expression_aux,car_parenthese_fermante);
		strcpy(expression_boucle,expression_aux);
	}
	if(nb_concatenations>0){
		strcat(expression_boucle, "*");
	}

	liste = *liste_de_regles;
	while(liste!=NULL){
		r1 = liste->la_regle;
		comp1 = strcmp(r1.etat_arrive,etat);
		liste_aux = *liste_de_regles;
		if(comp1==0){
			while(liste_aux!=NULL){
				r2 = liste_aux->la_regle;
				comp2 = strcmp(r2.etat_depart,etat);
				if(comp2==0){
					expression = (char *)calloc(2500,sizeof(char));
					strcat(expression,r1.symbole);
					strcat(expression,expression_boucle);
					strcat(expression,r2.symbole);
					nouvelle_regle.etat_depart = r1.etat_depart;
					nouvelle_regle.etat_arrive = r2.etat_arrive;
					nouvelle_regle.symbole = expression;
					// ajout de la nouvelle règle:
      			ajout_regle_dans_liste(nouvelle_regle,liste_de_nouvelles_regles);
				}
				liste_aux = liste_aux->regle_suivante;
			}
		}
		liste = liste->regle_suivante;
	}
	// on supprime maintenant les règles qui viennent d'être utilisées:
	liste = *liste_de_regles;
	liste_aux = liste->regle_suivante;
	while(liste_aux!=NULL){
		r1 = liste_aux->la_regle;
		comp1 = strcmp(r1.etat_arrive,etat);
		comp2 = strcmp(r1.etat_depart,etat);
		if(comp1==0 || comp2 ==0){
			struct Liste_regle * a_virer=liste_aux;
			liste->regle_suivante = liste_aux->regle_suivante;
			free(a_virer);
		} else {
			liste=liste_aux;
		}
		liste_aux = liste->regle_suivante;
	}
	r1 = (*liste_de_regles)->la_regle;
	comp1 = strcmp(r1.etat_arrive,etat);
	comp2 = strcmp(r1.etat_depart,etat);
	if(comp1 == 0 || comp2 == 0){
		struct Liste_regle * a_virer=*liste_de_regles;
		*liste_de_regles = (*liste_de_regles)->regle_suivante;
		free(a_virer);
	}
}


/* CONCATENATION : 
* 
***********************************************************************/
void concatenation(struct Liste_regle ** liste_de_regles,
                   struct Liste_regle ** liste_de_nouvelles_regles)
{
   struct Liste_regle * liste=*liste_de_regles;
   if(liste == NULL){
      *liste_de_regles = *liste_de_nouvelles_regles;
   } else {
      while(liste->regle_suivante != NULL){
         liste=liste->regle_suivante;
      }
      liste->regle_suivante = *liste_de_nouvelles_regles;
   }
   *liste_de_nouvelles_regles = NULL;
}


/* AFER : 
* Algorithme correspondant a la question 1 ...
***********************************************************************/
char * afer(struct Liste_chaine ** liste_etats_initiaux, 
            struct Liste_chaine ** liste_etats_finaux, 
            struct Liste_chaine ** liste_etats, 
            struct Liste_chaine ** liste_symboles, 
            struct Liste_regle ** liste_des_regles)
{
   // On ajoute un etat initial qui sera relie aux anciens etats initiaux par une transition epsilon
   ajout_etat_initial(liste_etats_initiaux,liste_etats_finaux,liste_etats,liste_symboles,liste_des_regles);

   // On ajoute un etat final qui sera relie aux anciens etats finaux par une transition epsilon
   ajout_etat_final(liste_etats_initiaux,liste_etats_finaux,liste_etats,liste_symboles,liste_des_regles);

   struct Liste_chaine * liste_de_parcours = *liste_etats;
   struct Liste_chaine * liste_etats_aux;
   struct Liste_regle * liste_des_nouvelles_regles = NULL;
   struct Liste_chaine * liste_etats_traites = NULL;
   char * etat;

   while(liste_de_parcours!=NULL){
      liste_etats_aux = *liste_etats;
      etat = etat_le_moins_connecte(*liste_etats,&liste_etats_traites,*liste_des_regles);
      while(liste_etats_aux!=NULL){
         rassemble_regles_entre_deux_etats(etat,liste_etats_aux->chaine, liste_des_regles);
         rassemble_regles_entre_deux_etats(liste_etats_aux->chaine,etat, liste_des_regles);
         liste_etats_aux = liste_etats_aux->chaine_suivante;
      }
      suppression_dun_etat(etat, liste_des_regles, &liste_des_nouvelles_regles);
      liste_de_parcours = liste_de_parcours->chaine_suivante;
      concatenation(liste_des_regles,&liste_des_nouvelles_regles); // Concatenation des deux listes de regles:
   }
   
   // On rassemble toutes les regles de transition allant de i vers f:
   rassemble_regles_entre_deux_etats("i","f", liste_des_regles);
   
   // Les seuls etats restants sont i et f, on doit modifier la liste d etats
   struct Liste_chaine * nouvelle_liste_etats = NULL;
   ajout_liste_en_queue("i",&nouvelle_liste_etats);
   ajout_liste_en_queue("f",&nouvelle_liste_etats);
   *liste_etats = nouvelle_liste_etats;

   // On extrait l'unique transition restant dans la liste des regles, il s'agit de la transition de i vers f:
   return ((*liste_des_regles)->la_regle).symbole;
}


