/**********************************************************************
* NOTE SUR CE FICHIER :
* Ce fichier contient le module AFER (a la fin du fichier) ainsi que les 
* fonctions et procedures utiles a sont fonctionnement.
*
* IMPORTANT : L'algorithme AFER modifie les structures de donnees par
* effets de bords (lors de la suppression des etats).
***********************************************************************/

#include "mt.h"

#ifndef AFER_H
#define AFER_H

/* AJOUT_ETAT_INITIAL :
* Pour tout etat Ei appartenant à l'ensemble des 
* etats initiaux on ajoute la transition i(^)->Ei où "^" est le symbole 
* correspondant à epsilon 
***********************************************************************/
void ajout_etat_initial(struct Liste_chaine ** liste_etats_initiaux, 
                        struct Liste_chaine ** liste_etats_finaux, 
                        struct Liste_chaine ** liste_etats,
                        struct Liste_chaine ** liste_symboles,
                        struct Liste_regle ** liste_des_regles);


/* AJOUT_ETAT_FINAL :
* Pour tout etat Ef appartenant à l'ensemble des etats 
* finaux on a la transition Ef(^)->f où "^" est le symbole correspondant à 
* epsilon
***********************************************************************/
void ajout_etat_final(struct Liste_chaine ** liste_etats_initiaux, 
                      struct Liste_chaine ** liste_etats_finaux, 
                      struct Liste_chaine ** liste_etats, 
                      struct Liste_chaine ** liste_symboles, 
                      struct Liste_regle ** liste_des_regles);


/* AFFICHE_EXPRESSION_RATIONNELLE : 
* 
***********************************************************************/
void affiche_expression_rationnelle(char * expr);


/* ETAT_LE_MOINS_CONNECTE : 
* 
***********************************************************************/
char * etat_le_moins_connecte(struct Liste_chaine * liste_etats,
                              struct Liste_chaine ** liste_etats_traites,
                              struct Liste_regle * liste_de_regles);


/* RASSEMBLE_REGLES_DUN_ETAT : 
* 
***********************************************************************/
void rassemble_regles_entre_deux_etats(char * etat_depart,
                                       char * etat_arrive, 
                                       struct Liste_regle ** liste_de_regles);


/* SUPPRESSION_DUN_ETAT : 
* 
***********************************************************************/
void suppression_dun_etat(char * etat,
                          struct Liste_regle ** liste_de_regles,
                          struct Liste_regle ** liste_de_nouvelles_regles);


/* CONCATENATION : 
* 
***********************************************************************/
void concatenation(struct Liste_regle ** liste_de_regles,
                   struct Liste_regle ** liste_de_nouvelles_regles);


/* AFER : 
* Algorithme correspondant a la question 1 ...
***********************************************************************/
char * afer(struct Liste_chaine ** liste_etats_initiaux, 
            struct Liste_chaine ** liste_etats_finaux, 
            struct Liste_chaine ** liste_etats, 
            struct Liste_chaine ** liste_symboles, 
            struct Liste_regle ** liste_des_regles);

#endif
