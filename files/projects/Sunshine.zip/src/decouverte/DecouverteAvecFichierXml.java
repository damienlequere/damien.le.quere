package decouverte;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import decouverte.parcours.GestionnaireTypeEnum;
import decouverte.parcours.ParcoureurDeJar;

import plugin.Programme;
import principal.Sunshine;

/**
 * La DecouverteAvecFichierXml est une implementation de la classe
 * Decouverte avec une verification de la validite des jars base
 * sur l'analyse d'un fichier plugin.xml a l'interieur de ces meme jar.
 * @author stephane
 */
public class DecouverteAvecFichierXml extends Decouverte {
	/**
	 * Le logger de DecouverteAvecFichierXml.
	 */
	private static final Logger LOGGER = Logger.getLogger("decouverte.DecouverteAvecFichierXml");
	
	/**
	 * Parcoureur de jar.
	 */
	private ParcoureurDeJar parcoureur;
	
	/**
	 * Constructeur par defaut.
	 */
	public DecouverteAvecFichierXml() {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "DecouverteAvecFichierXml", e);
		}
		this.repertoiresDeRecherche = new ArrayList<String>();
		this.repertoiresDeRecherche.add(System.getProperty("user.dir")+"/plugins");
	}
	
	/**
	 * Constructeur avec parametres.
	 * @param repertoires La liste des repertoires de recherche des plugins.
	 */
	public DecouverteAvecFichierXml(List<String> repertoires) {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "DecouverteAvecFichierXml", e);
		}
		
		this.repertoiresDeRecherche = repertoires;
	}
	
	/**
	 * Indique si un jar est valide ou non.
	 * @param jar L'adresse absolue du fichier jar.
	 * @return True si le jar est valide, false sinon.
	 * @see decouverte.Decouverte#estJarValide(java.lang.String)
	 */
	public boolean estJarValide(String jar) {
		LOGGER.entering(this.getClass().getName(), "estJarValide", jar);
		
		this.parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionJarValideAvecXml);
		boolean resultat = false;
		
		try
		{
			resultat = (Boolean) parcoureur.traiter().getResultats();
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "estJarValide", e);
		}
		
		LOGGER.exiting(this.getClass().getName(), "estJarValide", resultat);
		return resultat;
	}
	
	/**
	 * Si le jar contient un morceau de programme, celui ci est ajoute a la map des programmes.
	 * @param jar Le fichier jar en contenant un eventuel programme.
	 * @param map La map des programmes.
	 * @return La map des programmes.
	 * @see decouverte.Decouverte#putProgramme(java.lang.String jar, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Programme> putProgramme(String jar, Map<String, Programme> map) {
		LOGGER.entering(this.getClass().getName(), "putProgramme", new Object[] {jar, map});
		
		this.parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionPutProgrammeAvecXml);
		Map<String, Programme> resultat = null;
		
		try
		{
			resultat = (Map<String, Programme>) parcoureur.traiter().getResultats();
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "putProgramme", e);
		}
		
		LOGGER.exiting(this.getClass().getName(), "putProgramme", map);
		
		return resultat;
	}
}
