COMPILER :
	javac *.java
	
PUIS DANS UN TERMINAL
rmic PersonImpl;
rmic PersonServerImpl;
rmegistry

PUIS DANS UN AUTRE TERMINAL LANCER LE SERVEUR :
	java PersonServer
	
ENCORE DANS UN AUTRE TERMINAL :
	java PersonClient
