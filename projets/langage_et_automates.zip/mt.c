#include "mt.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>



/* Modules utilises pour les listes de chaines ou les listes de regles **************/
/************************************************************************************/

// Ajout en tete d'une chaine de caracteres
void ajout_liste_en_tete(char * mot, struct Liste_chaine ** liste)
{
   struct Liste_chaine * precedent;
   precedent = (struct Liste_chaine*)malloc(sizeof(struct Liste_chaine));
   precedent->chaine = mot;
   precedent->chaine_suivante = *liste;
   *liste = precedent;
}


// Ajout en queue d'une chaine de caracteres
void ajout_liste_en_queue(char * mot, struct Liste_chaine ** liste)
{
   struct Liste_chaine * suivant;
   suivant = (struct Liste_chaine*)malloc(sizeof(struct Liste_chaine));
   suivant->chaine = mot;
   suivant->chaine_suivante = NULL;

   struct Liste_chaine * liste_aux = (*liste);

   if (liste_aux == NULL){
   *liste = suivant;
   }else{
      while ((liste_aux)->chaine_suivante != NULL)
      {
         liste_aux = liste_aux->chaine_suivante;
      }
      liste_aux->chaine_suivante = suivant;
   }
}


// Ajout d'une regle
void ajout_regle_dans_liste(struct Regle r,struct Liste_regle ** liste_des_regles)
{
   struct Liste_regle * precedent;
   precedent = (struct Liste_regle *)malloc(sizeof(struct Liste_regle));
   precedent->la_regle = r;
   precedent->regle_suivante = *liste_des_regles;
   *liste_des_regles = precedent;
}


// Affichage d'une liste de chaines :
void affiche_liste_chaine(struct Liste_chaine * liste)
{
   printf("%c", '{');
   if(liste != NULL){
      printf("%s",liste->chaine);
      liste = liste->chaine_suivante;
      while (liste!=NULL){
         printf("%c%s", ',',liste->chaine);
         liste = liste->chaine_suivante;
      }
   } else {
      printf("%s","vide");
   }
   printf("%s", "}\n");
}

// Affichage d'une liste de regles
void affiche_regles(struct Liste_regle * liste)
{
   printf("%s","{\n");
   if(liste != NULL){
      struct Regle r = liste->la_regle;
      printf("%s%c%s%s%s%c",r.etat_depart,'(',r.symbole,")->",r.etat_arrive,'\n');
      liste = liste->regle_suivante;
      while (liste!=NULL){
      r = liste->la_regle;
      printf("%s%c%s%s%s%c",r.etat_depart,'(',r.symbole,")->",r.etat_arrive,'\n');
      liste = liste->regle_suivante;
      }
   } else {
      printf("%s","liste_vide");
   }
   printf("%s", "}\n");
}


// Affichage des structures de donnees correspondants a la matrice de transition de l automate
void affiche_matrice(struct Liste_chaine * liste_etats_initiaux,
                     struct Liste_chaine * liste_etats_finaux,
                     struct Liste_chaine * liste_etats,
                     struct Liste_chaine * liste_symboles,
                     struct Liste_regle * liste_des_regles)
{
   printf("%s","Etats = ");affiche_liste_chaine(liste_etats);
   printf("%s","I = ");affiche_liste_chaine(liste_etats_initiaux);
   printf("%s","F = ");affiche_liste_chaine(liste_etats_finaux);
   printf("%s","Alphabet = ");affiche_liste_chaine(liste_symboles);
   printf("%s","Regles = ");affiche_regles(liste_des_regles);
   printf("%c",'\n');
}


/* Modules utilises dans la procedure lecture matrice **********/
/***************************************************************/

// Predicat determinant si le caractere est un retour chariot
int retour_a_la_ligne(char car)
{return car=='\n'? 1 : 0;};


/* Pour parser on utilise une machine à etats (ensembles de variables booleennes)
* Cette procedure parseur modifie ces variables selon le caractere courant, modifiant ainsi l'etat courant
* (exemple d'etats : "on est en train de lire des etats initiaux", "on est en train de lire des regles") */
void parseur(char car, int * lecture_transition, int * entre_accolades, int * lecture_etats_initiaux, int * lecture_etats_finaux, int * lecture_regle)
{
   if (car=='{'){*entre_accolades = 1;}
   if (*lecture_transition == 0){
      if (car=='}'){*entre_accolades = 0;*lecture_etats_initiaux = 0;*lecture_etats_finaux = 0;*lecture_regle = 0;}
   }
   if (car=='('){*lecture_transition = 1;}
   if (*entre_accolades==0 && car=='I'){*lecture_etats_initiaux=1;}
   if (*entre_accolades==0 && car=='F'){*lecture_etats_finaux=1;}
   if (*entre_accolades==0 && car=='R'){*lecture_regle=1;}
}


// Predicat determinant si la liste "liste" contient le mot "mot"
int est_mot_de_la_liste(struct Liste_chaine * liste, char * mot)
{
   int trouve = 0, comp;
   while (trouve!=1 && liste!=NULL){
      comp=strcmp(mot,liste->chaine);
      if(comp==0){
         trouve = 1;
      }
      liste = liste->chaine_suivante;
   }
   return trouve;
}


/* Modules utilises dans l'algorithme AFDET **********/
/*****************************************************/

// Taille d une liste chainee de chaines de caracteres
int taille_liste_chaine(struct Liste_chaine * liste)
{if (liste == NULL){return 0;}else {return (1 + taille_liste_chaine(liste->chaine_suivante));}}

// Vrai si les listes de chaines sont identiques (sans notion d'ordre car les listes sont utilisees comme des ensembles), faux sinon
int compare_listes_chaines(struct Liste_chaine * liste1, struct Liste_chaine * liste2)
{
   if (taille_liste_chaine(liste1) != taille_liste_chaine(liste2))
   {
      return 0;
   }else{
      int egales = 1;
      while ((liste1 != NULL) && (egales == 1)){
         if(!est_mot_de_la_liste(liste2,liste1->chaine)) {egales = 0;}
         liste1 = liste1->chaine_suivante;
      }
      return egales;
   }
}


/*****************************************************************************
* Lecture Matrice :
* Permet de stocker des structures de donnees la matrice de transitions
* d'un AF donnee dans un fichier texte dont le nom est passe en parametre
* et place dans le repertoire courant
******************************************************************************/
void lecture_matrice(char * nom_fic,
                     struct Liste_chaine ** liste_etats_initiaux, 
                     struct Liste_chaine ** liste_etats_finaux,
                     struct Liste_chaine ** liste_etats,
                     struct Liste_chaine ** liste_symboles,
                     struct Liste_regle ** liste_des_regles)
{

   FILE * fic_matrice;  //
   char * car;          //
   char * mot;          //
   char ligne[50];      //
   int i,taille,comp;   //
   char * epsilon;
   epsilon =(char *)calloc(1,sizeof(char));
   epsilon="^";

   // Variables booleennes utiles pour parser (Machine a états)
   int entre_accolades = 0;         // On est entre deux accolades
   int lecture_etats_finaux = 0;    // On parcour un ensemble d'etats finaux
   int lecture_etats_initiaux = 0;  // On parcour un ensemble d'etats initiaux
   int lecture_regle = 0;           // On parcour un ensemble de regles
   int lecture_transition = 0;      // Determine si le symbole d'une transition a ete lu, utile si le symbol est ")" ou "}"
   int etat_lu = 0;                 //Determine si l'etat de depart d'une transition a ete lu

   struct Regle r;

   fic_matrice = fopen(nom_fic ,"r");

   // Lecture ligne par ligne du fichier
   while (fscanf(fic_matrice,"%s",&ligne)>0){
      taille = strlen(ligne);
      mot = (char *)calloc(0,sizeof(char));

      // Lecture caractere par caractere de la ligne courante
      for (i=0;i<taille;i++){
         car = (char *)calloc(1,sizeof(char));
         *car = ligne[i];

         // Lecture des etats initiaux
         if (lecture_etats_initiaux == 1 && entre_accolades == 1){
            if (*car==',' || *car=='}'){
               if (est_mot_de_la_liste(*liste_etats_initiaux,mot) == 0){
                  ajout_liste_en_tete(mot,liste_etats_initiaux);
               }
               mot = (char *)calloc(0,sizeof(char));
               strncpy(mot,mot,0);
            } else { strcat(mot, car); }
         }

         // Lecture des etats finaux
         if (lecture_etats_finaux == 1 && entre_accolades == 1){
            if (*car == ',' || *car == '}'){
               if (est_mot_de_la_liste(*liste_etats_finaux,mot) == 0){
                  ajout_liste_en_tete(mot,liste_etats_finaux);
               }
               mot = (char *)calloc(0,sizeof(char));
               strncpy(mot,mot,0);
            } else { strcat(mot, car); }
         }

         // Lecture des regles
         if (lecture_regle == 1 && entre_accolades == 1){
            if (*car != '}' && *car != ';'){
               // Cas ou la transition est en cours de lecture
               if (lecture_transition == 1){
                  if(etat_lu == 0){
                     if (*car == ','){
                        // Cas ou une virgule est lue: l'etat de depart de la transition a donc ete lu
                        etat_lu = 1;
                        if (est_mot_de_la_liste(*liste_etats,mot) == 0){
                           ajout_liste_en_queue(mot,liste_etats);
                        }
                        r.etat_depart = mot;
                        mot = (char *)calloc(0,sizeof(char));
                        strncpy(mot,mot,0);
                     } else {
                        // Cas ou la virgule n'a pas encore ete lue: l etat de depart de la transition est toujours en cours de lecture
                        strcat(mot, car);
                     }
                  } else {
                     // Cas où le symbole est lu
                      comp = strcmp(car,epsilon);
                     if (!est_mot_de_la_liste(*liste_symboles,car) && comp != 0){
                        ajout_liste_en_queue(car,liste_symboles);
                     }
                     etat_lu = 0;
                     lecture_transition = 0;
                     if(comp == 0){
                        r.symbole = "";
                     } else {
                        r.symbole = car;
                     }
                  }
               } else {
                  if (*car != '=' && *car!=')' && *car !='('){
                     // Cas où l'etat d'arrive est en cours de lecture
                     strcat(mot, car);
                  }
               }
            } else {
               //cas ou la regle a fini d'être lue
               //dans une premier temps on recupere l'etat d'arrive de la transition qui vient d'être lu
               if (est_mot_de_la_liste(*liste_etats,mot) == 0){
                  ajout_liste_en_queue(mot,liste_etats);
               }
               r.etat_arrive = mot;
               mot = (char *)calloc(0,sizeof(char));
               strncpy(mot,mot,0);
               //On stock la regle dans une liste
               ajout_regle_dans_liste(r,liste_des_regles);
            }
         }
         parseur(*car,&lecture_transition,&entre_accolades, &lecture_etats_initiaux, &lecture_etats_finaux, &lecture_regle);
      }
   }
   fclose(fic_matrice);
}
