package xml;

import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import principal.Sunshine;

/**
 * Cette classe est chargee de verifier qu'un fichier xml est bien valide 
 * par rapport au xml schema definit dans resources.plugin.xsd.
 * @author stephane
 */
public class ControleParSchema extends Controle {
	/**
	 * Le logger de Sunshine.
	 */
	private static final Logger LOGGER = Logger.getLogger("xml.ControleParSchema");
	
	/**
	 * L'adresse du schema xsd.
	 */
	private String adresse;
	
	/**
	 * Constructeur qui prend en parametre l'adresse du fichier de schema.
	 * @param adresse L'adresse du schema xsd.
	 */
	public ControleParSchema(String adresse) {
		super();
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "ControleParSchema", e);
		}
		
		this.adresse = adresse;
	}
	
	/**
	 * Renvoie un boolean indiquant si un fichier xml est valide.
	 * @param fichierXml Le fichier xml.
	 * @param loader Le classe loader du jar ou aller chercher le xml.
	 * @return Un boolean indiquant si le fichier xml est valide.
	 * @see xml.Controle#estValide(java.lang.String, java.net.URLClassLoader)
	 */
	@Override
	public boolean estValide(String fichierXml, URLClassLoader loader) {
		String nomMethode = "estValide";
		LOGGER.entering(this.getClass().getName(), nomMethode, new Object[] {fichierXml, loader});
		
		Document document = null;
		
		boolean reussi=true;
		if(loader == null)
		{
			reussi =  false;
		}
		else
		{
			try
			{
				LOGGER.log(Level.INFO, "On commence la validation avec : "+fichierXml);
				SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
				Schema schema = factory.newSchema(new File(adresse));
				Validator validator = schema.newValidator();
				
				DocumentBuilderFactory fabrique = DocumentBuilderFactory.newInstance();
				DocumentBuilder constructeur = fabrique.newDocumentBuilder();
				document = constructeur.parse(loader.findResource(fichierXml).toString());
				
				validator.validate(new DOMSource(document));
				
			}
			catch (IOException e)
			{
				LOGGER.throwing(this.getClass().getName(), nomMethode, e);
				reussi = false;
			}
			catch (SAXException e)
			{
				LOGGER.throwing(this.getClass().getName(), nomMethode, e);
				// Les erreurs SAX ne sont pas prises en compte car il y a un probleme avec
				// l'encodage UTF-8 et le parseur SAX qui leve une exception systematiquement.
			}
			catch (ParserConfigurationException e)
			{
				LOGGER.throwing(this.getClass().getName(), nomMethode, e);
				reussi = false;
			}
		}
		LOGGER.exiting(this.getClass().getName(), nomMethode, reussi);
		return reussi;
	}

	/**
	 * Renvoie l'adresse du fichier xsd.
	 * @return L'adresse du fichier xsd.
	 */
	public String getAdresse() {
		LOGGER.entering(this.getClass().getName(), "getAdresse");
		LOGGER.exiting(this.getClass().getName(), "getAdresse", adresse);
		return adresse;
	}

	/**
	 * Permet de changer l'adresse du fichier xsd.
	 * @param adresse La nouvelle adresse du fichier xsd.
	 */
	public void setAdresse(String adresse) {
		LOGGER.entering(this.getClass().getName(), "setadresse", adresse);
		LOGGER.exiting(this.getClass().getName(), "setAdresse");
		
		this.adresse = adresse;
	}
}
