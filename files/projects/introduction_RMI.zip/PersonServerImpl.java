import java.rmi.*;
import java.rmi.server.*;
import java.util.ArrayList;

public class PersonServerImpl extends UnicastRemoteObject implements PersonServerInterface{
	
	private ArrayList<PersonInterface> tab_person;
	public PersonServerImpl () throws RemoteException{
		super();
		tab_person = new ArrayList<PersonInterface>();
		tab_person.add(new PersonImpl("Prenom1", "Nom1"));
		tab_person.add(new PersonImpl("Prenom2", "Nom2"));
		tab_person.add(new PersonImpl("Prenom3", "Nom3"));
		tab_person.add(new PersonImpl("Prenom4", "Nom4"));
	}
	public ArrayList<PersonInterface> find(String fn) throws RemoteException{
		ArrayList<PersonInterface> tab_resultat = new ArrayList<PersonInterface>();
		for(PersonInterface p : tab_person)
			if(p.getFirstName().equals(fn))
				tab_resultat.add(p);
		return tab_resultat;
	}
}
