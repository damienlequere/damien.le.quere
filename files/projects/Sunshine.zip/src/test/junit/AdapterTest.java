package test.junit;

import junit.framework.JUnit4TestAdapter;
import junit.framework.Test;

/**
 * Classe pour adapter les tests JUnit4 en tests JUnit3.
 * @author stephane
 */
public final class AdapterTest {
	/**
	 * Constructeur.
	 */
	private AdapterTest() {
		
	}
	/**
	 * Retourne la suite de tests en version JUnit3.
	 * @return La suite de tests.
	 */
	public static Test suite() {
		return new JUnit4TestAdapter(TestSequentiel.class);
	}
}
