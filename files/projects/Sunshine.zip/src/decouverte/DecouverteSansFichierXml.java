package decouverte;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import decouverte.parcours.GestionnaireTypeEnum;
import decouverte.parcours.ParcoureurDeJar;

import plugin.Programme;
import principal.Sunshine;

/**
 * La DecouverteSansFichierXml est une implementation de la classe
 * Decouverte dans laquelle la verification de la validite d'un jar
 * est basee sur les interfaces implementees par les classes de ce jar.
 * @author stephane
 */
public class DecouverteSansFichierXml extends Decouverte {
	/**
	 * Le logger de DecouverteSansfichierXml.
	 */
	private static final Logger LOGGER = Logger.getLogger("decouverte.DecouverteSansFichierXml");
	
	/**
	 * Parcoureur de jar.
	 */
	private ParcoureurDeJar parcoureur;
	
	/**
	 * Constructeur par defaut.
	 */
	public DecouverteSansFichierXml() {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "DecouverteSansFichierXml", e);
		}
		
		this.repertoiresDeRecherche = new ArrayList<String>();
		this.repertoiresDeRecherche.add(System.getProperty("user.dir")+"/plugins");
		
		LOGGER.log(Level.INFO, this.repertoiresDeRecherche.toString());
	}
	
	/**
	 * Constructeur avec une liste de repertoires dans lesquels chercher les jars.
	 * @param repertoires Liste des repertoires ou chercher les jars.
	 */
	public DecouverteSansFichierXml(List<String> repertoires) {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "DecouverteSansFichierXml", e);
		}
		this.repertoiresDeRecherche = repertoires;
		LOGGER.log(Level.INFO, this.repertoiresDeRecherche.toString());
	}
	
	/**
	 * Indique si un jar est valide ou non.
	 * @param jar L'adresse absolue du fichier jar.
	 * @return True si le jar est valide, false sinon.
	 * @see decouverte.Decouverte#estJarValide(java.lang.String)
	 */
	public boolean estJarValide(String jar) {
		LOGGER.entering(this.getClass().getName(), "estJarValide", jar);
		this.parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionJarValideSansXml);
		boolean resultat = false;
		
		try
		{
			resultat = (Boolean) parcoureur.traiter().getResultats();
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "estJarValide", e);
		}
		
		LOGGER.exiting(this.getClass().getName(), "estJarValide", resultat);
		return resultat;
	}
	
	/**
	 * Si le jar contient un morceau de programme, celui ci est ajoute a la map des programmes.
	 * @param jar Le fichier jar en contenant un eventuel programme.
	 * @param map La map des programmes.
	 * @return La map des programmes.
	 * @see decouverte.Decouverte#putProgramme(java.lang.String, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Programme> putProgramme(String jar, Map<String, Programme> map) {
		LOGGER.entering(this.getClass().getName(), "putProgramme", new Object[] {jar, map});
		
		this.parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionPutProgrammeSansXml);
		Map<String, Programme> resultat = null;
		
		try
		{
			resultat = (Map<String, Programme>) parcoureur.traiter().getResultats();
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "putProgramme", e);
		}
		
		LOGGER.entering(this.getClass().getName(), "putProgramme", resultat);
		return resultat;
	}

}
