package test.stub.modele;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import observeur.Observeur;

import plugin.Programme;
import principal.Sunshine;

import modele.Modele;

/**
 * @author stephane
 *
 */
public class ModeleStub extends Modele {
	/**
	 * Le logger du stub de Modele.
	 */
	private static final Logger LOGGER = Logger.getLogger("test.stub.modele.ModeleStub");
	
	/**
	 * L'operateur du calcul.
	 */
	private String operateur;
	
	/**
	 * Les arguments du calcul.
	 */
	private Object argument;
	
	/**
	 * La liste des observeurs.
	 */
	private final List<Observeur> listeObserveurs;
	
	/**
	 * La map des programmes.
	 */
	private static Map<String, Programme> mapProgramme = new HashMap<String, Programme>();
	
	/**
	 * Constructeur par defaut.
	 */
	public ModeleStub() {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "ModeleStub", e);
		}
		this.listeObserveurs = new ArrayList<Observeur>();
	}
	
	/**
	 * Permet de changer l'operateur du calcul en cour.
	 * @param operateur Operateur du calcul.
	 */
	@Override
	public void setOperateur(String operateur) {
		this.operateur = operateur;
	}
	
	/**
	 * Permet de changer le(s) argument(s) du calcul.
	 * @param argument Le(s) argument(s) du calcul.
	 */
	@Override
	public void setArgument(Object argument) {
		this.argument = argument;
	}
	
	/**
	 * Stub de la methode effectueOperation.
	 */
	@Override
	public void effectueOperation() {
		LOGGER.log(Level.INFO, "On effectue l'operation : "+this.operateur+" avec les arguments : "+this.argument.toString());
	}
	
	/**
	 * Permet d'ajouter un observeur sur le modele.
	 * @param o L'observeur a ajouter.
	 * @see observeur.Observable#addObserveur(observeur.Observeur)
	 */
	@Override
	public void addObserveur(Observeur o) {
		LOGGER.log(Level.INFO, "Ajout de l'observeur : "+o.toString());
		this.listeObserveurs.add(o);
	}

	/**
	 * Permet de prevenir les observeurs d'un evenement.
	 * @param o Les donnees transmises par le modele aux observeurs.
	 * @see observeur.Observable#notifyObserveur(java.lang.Object)
	 */
	@Override
	public void notifyObserveur(Object o) {
		LOGGER.log(Level.INFO, "On notifie les observeurs.");
		for(Observeur obs : this.listeObserveurs)
		{
			obs.update(o);
		}
	}
	
	/**
	 * Permet de supprimer un observeur.
	 * @param o L'observeur a supprimer.
	 * @see observeur.Observable#removeObserveur(observeur.Observeur)
	 */
	@Override
	public void removeObserveur(Observeur o) {
		LOGGER.log(Level.INFO, "On supprime l'observeur : "+o.toString());
		this.listeObserveurs.remove(o);
	}

	/**
	 * Retourne la map des programmes.
	 * @return La map des programmes.
	 */
	public static Map<String, Programme> getMapProgramme() {
		LOGGER.log(Level.INFO, "On retourne la map des programmes : ");
		return mapProgramme;
	}
	
	/**
	 * Renvoie l'operateur.
	 * @return L'operateur.
	 */
	public String getOperateur() {
		return this.operateur;
	}
	
	/**
	 * Renvoie l'argument.
	 * @return L'argument.
	 */
	public Object getArgument() {
		return this.argument;
	}
}
