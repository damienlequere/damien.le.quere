COMPILATION DU TRADUCTEUR LATEX2HTML :

lex latex2html.l;
yacc -d latex2html.y;
cc lex.yy.c y.tab.c -o latex2html;
rm y.tab.h y.tab.c lex.yy.c;

EXECUTION

./latex2html [fichier_source_latex] >[fichier_cible_html]

