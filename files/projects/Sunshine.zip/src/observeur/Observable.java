package observeur;

/**
 * L'interface observable, du design pattern observeur permet
 * de prevenir la vue (ici vue.Fenetre) des qu'une modification
 * du modele (ici modele.Modele) a eu lieu. Dans le cadre d'une
 * evolution de ce programme, d'autre observeur du modele peuvent
 * venir s'enregistrer par le biais de cette interface.
 * @author stephane
 */
public interface Observable {
	/**
	 * Permet d'ajouter un observeur sur le modele.
	 * @param o L'observeur a ajouter.
	 */
	void addObserveur(Observeur o);
	
	/**
	 * Permet de prevenir les observeurs d'un evenement.
	 * @param o Les donnees transmises par le modele aux observeurs.
	 */
	void removeObserveur(Observeur o);
	
	/**
	 * Permet de supprimer un observeur.
	 * @param o L'observeur a supprimer.
	 */
	void notifyObserveur(Object o);
}
