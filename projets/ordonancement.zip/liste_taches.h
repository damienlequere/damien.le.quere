#ifndef LISTE_TACHES_H_INCLUDED
#define LISTE_TACHES_H_INCLUDED

#include"tache.h"
#include<string>
#include<list>

class ListeTaches{

    public:

    //constructeur
    ListeTaches(string);
    ListeTaches();

    //destructeur
    ~ListeTaches();

    //accesseur
    string getName();

    //ajout d'une tache
    void ajouter(const Tache&);
    //suppression d'une tache
    bool supprimer(string);
    //reinitialisation de la liste
    void reinitialiser();
    //affichage de la liste de taches
    void afficher(ostream&);

    list<Tache> *getTaches()const;

    float somme_ci_sur_pi()const;

    int nb_taches_periodiques()const;

    bool di_egal_pi()const;

    private:

    string _name;
    list<Tache> *_taches;

    };

#endif // LISTE_TACHES_H_INCLUDED
