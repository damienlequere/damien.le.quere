import java.rmi.*;
import java.util.ArrayList;

public interface PersonServerInterface extends Remote{
	public ArrayList<PersonInterface> find(String fn) throws RemoteException;
}
