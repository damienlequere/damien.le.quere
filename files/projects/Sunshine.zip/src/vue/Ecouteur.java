package vue;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Logger;

import plugin.Programme;
import principal.Sunshine;

/**
 * Cette classe ecoute le bouton "lancer" de l'interface graphique
 * afin de lancer le programme correspondant.
 * @author stephane
 */
public class Ecouteur implements ActionListener {
	/**
	 * Le logger de ChercheurDeJars.
	 */
	private static final Logger LOGGER = Logger.getLogger("vue.Ecouteur");
	
	/**
	 * La fenetre.
	 */
	private final Fenetre fenetre;
	
	/**
	 * Constructeur.
	 * @param fenetre La fenetre ecoutee.
	 */
	public Ecouteur(Fenetre fenetre) {
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "Ecouteur", e);
		}
		
		this.fenetre = fenetre;
	}
	
	/**
	 * Lance le programme quand on clique sur le bouton.
	 * @param e L'action du cliquage sur le bouton.
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		LOGGER.entering(this.getClass().getName(), "actionPerformed", e);
		String str = fenetre.getValue();
		
		Programme programme = fenetre.getProgramme(str);
		Thread thread = new Thread(programme);
		thread.start();
		
		LOGGER.exiting(this.getClass().getName(), "actionPerformed");
	}
}
