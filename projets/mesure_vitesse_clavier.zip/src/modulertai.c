// inclusion des librairies necessaires
#include <linux/module.h>
#include <asm/io.h>
#include <rtai.h>
#include <rtai_sched.h>
#include <rtai_sem.h>
#include <rtai_fifos.h>

// taille de la pile et non-utilisation de flottants
#define RT_STACK_SIZE 2000
#define NO_FPU 0
#define FPU 1

// definitions valeurs de la FIFO temps reel
#define FIFO_N0 0
#define FIFO_SIZE sizeof(char)

// autres definitions
#define SIZE_MAX_TEXT 2000
#define FIN_FICHIER '~'

// definitions concernant les interruptions
#define NB_INTERRUPT_PAR_FRAPPE 2
#define IRQ_CLAVIER 1 


/**********************************************/
/**************** Declarations ****************/
/**********************************************/

// declaration des taches
static RT_TASK tidAffichage;
static RT_TASK tidMesureVitesse;

// declaration des semaphores
static SEM semaphore_affichage;
static SEM semaphore_mesure_vitesse;

// stockage du texte recu caractere par caractere
static char texte_recu[SIZE_MAX_TEXT];
static int parcours_tab1 	  = 0;

// variables utilisees pour la mesure de la vitesse de frappe
static int nb_interruptions_total = 0;
static int nb_frappes_clavier 	  = 0;
static RTIME begin_time;
static unsigned char temps_entre_2_cars[SIZE_MAX_TEXT];
static int parcours_tab2 = 0;


/*******************************************************/
/**************** FONCTIONS UTILITAIRES ****************/
/*******************************************************/

// reception d'un caractere dans un tableau
void receptionCaractere(char c)
{
   texte_recu[parcours_tab1] = c;
   parcours_tab1++;
}

// retourne le temps en secondes equivalent au RTIME
unsigned char convertion(RTIME r){
   /* 
   * on divise un RTIME par une puissance de 2 proche de 1 milliard
   * afin d'obtenir une valeur en seconde tres proche de la verite
   */
   unsigned char test = (unsigned char)((count2nano(r))/1073741824);
   return test;
}




// affichage du bilan des mesures sur les frappes au clavier
void affiche_bilan(void){
   // on recupere le temps courant pour calculer le temps total de frappe
   unsigned char temps_total_de_frappe = convertion(rt_get_time() - begin_time);
   unsigned char nb_frappes_par_minute = nb_frappes_clavier * (60 / temps_total_de_frappe);

   // Affichage du bilan
   rt_printk("************** BILAN SUR VOTRE VITESSE DE FRAPPE **************\n");
   rt_printk("Nombre d'interruptions total : %i\n",nb_interruptions_total);
   rt_printk("Nombre de frappes au clavier : %i\n",nb_frappes_clavier);
   rt_printk("Temps total de frappe: %u secondes\n",temps_total_de_frappe);
   rt_printk("Nombre de frappes / minute : %u\n", nb_frappes_par_minute);
   rt_printk("Temps de frappe entre les caracteres :\n");

   // Affichage du temps de frappe entre chaque caractere en secondes
   int parcours;
   for(parcours = 0; parcours < parcours_tab2; parcours++){
      rt_printk("%u|",temps_entre_2_cars[parcours]);
   }

   // Affichage du temps de frappe moyen entre les caracteres en secondes
   unsigned int somme_ecart = 0;
   for(parcours = 0; parcours < parcours_tab2; parcours++){
      somme_ecart += temps_entre_2_cars[parcours];
   }
   rt_printk("\nTemps de frappe moyen entre les caracteres : %u seconde(s)\n", 
	     somme_ecart / parcours_tab2);
   rt_printk("***************************************************************\n");
}

/***************************************************/
/**************** CODE DES HANDLERS ****************/
/***************************************************/

// code appeler lors d'un evenement dans la FIFO n�0
static int fifo_handler0(unsigned int fifo)
{
   char c_courant;
   // on recupere le texte recu via une FIFO temps reel, caractere par caractere
   rtf_get(FIFO_N0, &c_courant, FIFO_SIZE);

   /* on fixe arbitrairement un caractere special marquant la fin du fichier
    * si on trouve ce caractere dans la fifo on envoi un message sur le semaphore d'affichage
    * sinon on continue a lire la FIFO et a receptionner le texte */
   if(c_courant == FIN_FICHIER)
      rt_sem_signal(&semaphore_affichage);
   else
      receptionCaractere(c_courant);
   return 0;
}

// code appeler lors d'une interruption sur l'IRQ du clavier
static void interrupt_handler(void){
   // desactivation de l'interruption clavier
   rt_disable_irq(IRQ_CLAVIER);
   
   // envoie d'un semaphore de signalisation vers la tache 'tidMesureVitesse'
   rt_sem_signal(&semaphore_mesure_vitesse);
   
   // redirection de l'interruption vers LINUX
   rt_pend_linux_irq(IRQ_CLAVIER);

   // reactivation de l'interruption clavier
   rt_enable_irq(IRQ_CLAVIER);
}









/*************************************************/
/**************** CODE DES TACHES ****************/
/*************************************************/

// traitement effectue a chaque interruption sur l'IRQ clavier
void codeMesureVitesse(long t)
{
   // attente de signal du semaphore : "semaphore_mesure_vitesse"
   while(1){
      rt_sem_wait(&semaphore_mesure_vitesse);

      nb_interruptions_total++;
      // on demarre note base de temps lors de la premiere frappe
      if(nb_interruptions_total == NB_INTERRUPT_PAR_FRAPPE){
	 begin_time = rt_get_time();
      }
      // toutes les N interruptions on considere une frappe au clavier
      if((nb_interruptions_total % NB_INTERRUPT_PAR_FRAPPE) == 0){
         // +1 au compteur de frappes
         nb_frappes_clavier++;
	 // ajout de l'ecart de temps avec la derniere frappe dans un tableau
         temps_entre_2_cars[parcours_tab2] = convertion(rt_get_time() -
					     temps_entre_2_cars[parcours_tab2-1]);
         parcours_tab2++;
      }
   }
}

// Affichage du texte accumule dans le tableau
void codeAffichage(long t)
{
   // compteur pour affichage
   int cpt_affich;

   // attente de signal du semaphore : "semaphore_affichage"
   rt_sem_wait(&semaphore_affichage);

   // affichage du texte du tableau : "texte_recu"
   rt_printk("******************************************************\n");
   rt_printk("VEUILLEZ RECOPIER LE TEXTE SUIVANT [%i caracteres] :\n",parcours_tab1);
   rt_printk("******************************************************\n\n");

   for(cpt_affich=0;cpt_affich!=parcours_tab1-1;cpt_affich++)
      rt_printk("%c",texte_recu[cpt_affich]);
   rt_printk("\nA vous de jouer :\n\n");
   // activation de l'interruption clavier
   rt_request_global_irq(IRQ_CLAVIER,interrupt_handler);
}

/*********************************************/
/**************** INIT MODULE ****************/
/*********************************************/

int init_module(void)
{
   // demarrage du timer
   start_rt_timer(0);

   // on autorise l'interruption clavier
   rt_enable_irq(IRQ_CLAVIER);

   // initialisation des taches
   rt_task_init(&tidAffichage, codeAffichage, 0, RT_STACK_SIZE, 0, NO_FPU, 0);
   rt_task_init(&tidMesureVitesse, codeMesureVitesse, 0, RT_STACK_SIZE, 0, NO_FPU, 0);

   // creation et nettoyage des FIFOS
   rtf_create(FIFO_N0,FIFO_SIZE);
   rtf_reset(FIFO_N0);

   // creation des fifo handler
   rtf_create_handler(FIFO_N0,fifo_handler0);

   // initialisation des semaphores
   rt_sem_init(&semaphore_affichage,0);
   rt_sem_init(&semaphore_mesure_vitesse,0);

   // lancement des taches
   rt_task_resume(&tidAffichage);
   rt_task_resume(&tidMesureVitesse);

   return 0;
}

/************************************************/
/**************** CLEANUP MODULE ****************/
/************************************************/

void cleanup_module(void)
{
   // affichage du bilan au moment de quitter le module RTAI
   affiche_bilan();
   rt_task_delete(&tidAffichage);
   rt_task_delete(&tidMesureVitesse);
   rt_sem_delete(&semaphore_affichage);
   rt_sem_delete(&semaphore_mesure_vitesse);
   rtf_destroy(FIFO_N0);
   rt_free_global_irq(IRQ_CLAVIER);
}
