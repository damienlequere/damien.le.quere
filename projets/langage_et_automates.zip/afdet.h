/***************************************************************
* NOTE SUR CE FICHIER : 
* Ce fichier contient l'algorithme "determinisation" (a la fin du fichier)
* qui donne la matrice de transition de l'automate déterministe
* correspondant a la matrice donnee.
*
* Attention ce fichier ne contient pas le module de minimisation
* ce dernier est dans le fichier "minimisation.h"
*
* Il y a pour cet algorithme une nouvelle structure de donnee :
* les listes de liste de chaines de caracteres.
*
* Il y a egalement dans ce fichier les differents modules
* utilises par afdet.
***************************************************************/

#include "mt.h"

#ifndef AFDET_H
#define AFDET_H

/***************************************************************/
/****************** Structures de donnees **********************/
/***************************************************************/

// Liste de listes de chaines de caracteres utilisee pour la determinisation
struct Liste_de_listes{
   struct Liste_chaine * pt_liste_etats;
   struct Liste_de_listes * pt_liste_suivante;
};


/***************************************************************/
/******************* Procedures et fonctions *******************/
/***************************************************************/


/* Modules utilises pour les listes de listes **************/
/***********************************************************/

// Ajout en tete d une liste de listes
void ajout_liste_de_listes(struct Liste_chaine * liste_a_ajouter,
                           struct Liste_de_listes ** liste);


// Ajout en queue d une liste de listes
void ajout_liste_de_listes_en_queue(struct Liste_chaine * liste_a_ajouter,
                                    struct Liste_de_listes ** liste);


// Affichage d une liste de listes de chaines
void affiche_liste_de_listes(struct Liste_de_listes * liste);


// Predicat determinant si la liste de chaines liste apartient (d un point de vue ensembliste) a ll
int est_liste_de_liste(struct Liste_chaine * liste,
                       struct Liste_de_listes * ll);


// Fonction retournant la liste equivalente recherchee dans la liste de liste
// (Equivalence d un point de vue ensembliste)
struct Liste_chaine * recherche_liste(struct Liste_chaine * liste,
                                      struct Liste_de_listes * ll);
                    

// Predicat determinant si deux listes_de_listes sont identiques
int sont_listes_de_listes_identiques(struct Liste_de_listes * listeA,
                                     struct Liste_de_listes * listeB);

/* EPSILON FERMETURE : 
* Fonction retournant les etats formant l epsilon fermeture d une liste
* d etats. C est a dire les etats eux-memes, ainsi que tous les etats
* accessibles avec une ou plusieurs epsilon-transitions.
***********************************************************************/
struct Liste_chaine * epsilon_fermeture(struct Liste_chaine * etats,
                                        struct Liste_regle * regles);


/* TRANSITION : 
* Fonction retournant les etats accessibles depuis d'autres etats avec 
* un symbole donne. C est a dire l epsilon-fermeture des etats auquels 
* on peut acceder depuis les etats donnes avec le symbole donne.
***********************************************************************/
struct Liste_chaine * Transition(struct Liste_chaine * etats,
                                 char * symbole,
                                 struct Liste_regle * regles);


/* DETERMINISATION : 
* Procedure ayant en entree/sortie toutes le informations de la matrice
* Determinise l automate
***********************************************************************/
void determinisation(struct Liste_chaine ** liste_etats_initiaux, 
                     struct Liste_chaine ** liste_etats_finaux, 
                     struct Liste_chaine ** liste_etats,
                     struct Liste_chaine ** alphabet,
                     struct Liste_regle ** liste_des_regles);

#endif
