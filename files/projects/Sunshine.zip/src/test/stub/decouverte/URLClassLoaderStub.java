package test.stub.decouverte;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * @author stephane
 *
 */
public class URLClassLoaderStub extends URLClassLoader {

	/**
	 * Constructeur.
	 * @param urls Les URLs dans lesquels chercher.
	 */
	public URLClassLoaderStub(URL[] urls) {
		super(urls);
	}

}
