<?
//
function affiche_temps_indexation($min_envoi,$sec_envoi,$min_act,$sec_act){
   $sec_total = (($min_act - $min_envoi)*60) + ($sec_act - $sec_envoi);
   echo $sec_total;
}

//
function affiche_tab_assoc($tab){
   foreach($tab as $cle=>$valeur)
      echo $cle." : ".$valeur."<br/>";
   echo "<p>taille du tableau : ".count($tab)."</p>";
}

//
function traite_ponctuation_casse($text){
   $text = ereg_replace("[^a-zA-Z0-9]"," ",$text); 
   $text = ereg_replace("[\ ]+"," ",$text);
   $text = strtolower($text);
   return $text;
}

//
function recherche_dicotomique($element,$tableau){
   $min = 1;
   $max = count($tableau);
   $mil = (int)(($max+$min) / 2);
   $trouve = FALSE;
   while(($mil != $min) && !$trouve){
      $comp = strcmp($element,$tableau[$mil]);
      if($comp < 0)
         $max = $mil;
      else{
         if($comp > 0)
            $min = $mil;
         else{
            if($comp == 0)
               $trouve = TRUE;
         }
      }
      $mil = (int)(($max+$min) / 2);
   }
   if(strcmp($element,$tableau[$mil]) == 0)
      $trouve = TRUE;
      
   return $trouve;
}

//
function remplir_tab_stopwords($f){
   $fic_stopwords = fopen($f,"r");
   $cpt = 1;
   while ((!feof($fic_stopwords))){
      $temp = fgets($fic_stopwords, 100);
      $temp = trim($temp);
      if ($temp != ""){
         $tab_stopwords[$cpt] = $temp;
         $cpt++;
      }
   }
   fclose($fic_stopwords);
   return $tab_stopwords;
}

//
function remplir_tab_stems($f,$f2){
   $tab_stems = array();
   $tab_stopwords = array();
   $fics_stems = fopen($f,"r");
   $fic_stopwords = fopen($f2,"r");
   
   $cpt = 1;
   while ((!feof($fic_stopwords))){
      $temp = fgets($fic_stopwords, 200);
      $temp = trim($temp);
      if ($temp != ""){
         $tab_stopwords[$cpt] = $temp;
         $cpt++;
      }
   }
   
   while ((!feof($fics_stems))) {
      $ligne = fgets($fics_stems, 200);
      $tab = explode(" |  ",$ligne);  
      $termes = explode(" ",$tab[1]);
      foreach($termes as $terme){
         $terme = trim($terme);
         $trouve = recherche_dicotomique($terme,$tab_stopwords);
         //if($trouve)
           // echo "[".$terme."] est un stopword !<br/>\n";
         if(!$trouve)
            $tab_stems[$terme] = $tab[0];
      }
   }
   fclose($fics_stems);
   fclose($fic_stopwords);
   
   return $tab_stems;
}

//
function indexation_terme($terme, $docno, $id_cx){
   global $tableau_stems;
   $stem = $tableau_stems[$terme];
   
   if($stem == ""){
      return 1;
   }else{
      $result = mysql_query("SELECT stem, nbocc FROM documents WHERE stem='".$stem."' AND docno='".$docno."'");
      $res_nbocc = mysql_fetch_array($result);
      if(mysql_num_rows($result) == 0){ // n'a pas trouve le couple(stem,docno)
         mysql_query("INSERT INTO documents (stem,docno,nbocc) VALUES ('".$stem."','".$docno."',1)");
      }else{
         $tmp = $res_nbocc['nbocc'] + 1;
         $requete = "UPDATE documents SET nbocc = ".$tmp."  WHERE stem = '".$stem."' AND docno = '".$docno."'";
         mysql_query($requete);
      }
      return 0;   
   }
}

//
function indexation_document($doc,$id_cx){
   $compteur = 0;
   $compteur_stems_trouves = 0;
      
   // Récupération des informations du document courant
   $liste_text_node = $doc->getElementsByTagName('TEXT');
   foreach($liste_text_node as $text_node)
      $text .= $text_node->firstChild->nodeValue;
   $liste_head_node = $doc->getElementsByTagName('HEAD');
   foreach($liste_head_node as $head_node)
      $head .= $head_node->firstChild->nodeValue;
   $docno = $doc->getElementsByTagName('DOCNO')->item(0)->firstChild->nodeValue;
   $docno = trim($docno);
   
   // Traitement de la ponctuation et de la casse du texte
   $text = traite_ponctuation_casse($text);
   $head = traite_ponctuation_casse($head);
   
   // Récupération des termes de HEAD et TEXT dans un tableau
   $tab_termes = explode(" ",$text);
   $tab_termes_head = explode(" ",$head);
   foreach($tab_termes_head as $terme_head)
      $tab_termes[] = $terme_head;
   
   // Indexation de chaque terme
   foreach($tab_termes as $terme){//echo "<strong>".$terme."</strong> | ";
      if(($terme != "") && ($terme != " ")){
         $compteur_stems_trouves += indexation_terme($terme, $docno, $id_cx);
         $compteur++;
         }
      }
   return $compteur;
}

//
function indexation_fichier($f){
   $compteur_stems = 0;
   echo "<h2>Indexation de <em>".$f."</em></h2>\n";
   $dom = new DomDocument;   
   $dom->load($f);

   $docs = $dom->documentElement;
   $liste_docs = $docs->getElementsByTagName('DOC');

   $compteur_doc = 1;
   foreach($liste_docs as $doc){
      $compteur_stems += indexation_document($doc,$id_cx);
      $compteur_doc++;
   }
   return $compteur_stems;
}

//
function indexation_fichiers($rep,$id_cx){ 
   $dir = opendir($rep);
   $compteur_fic = 1;
   $fics_indexes = array();
   $compteur_stems = 0;
   
   while ($fic = readdir($dir)){
      if(is_file($rep.$fic)){
         $compteur_stems += indexation_fichier($rep.$fic);
         $compteur_fic++;
      }
   }
   return $compteur_stems;
}
?>
