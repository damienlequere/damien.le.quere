#include"gestionnaire_stats.h"


Gestionnaire_stats::Gestionnaire_stats(int duree){
        _duree_simulation = duree;
        _nb_temps_creux = 0;
        _nb_preemptions = 0;
        _temps_reponse_TAPNC = new list<int>;
        };

Gestionnaire_stats::~Gestionnaire_stats(){};

void Gestionnaire_stats::ajout_preemption(){
    _nb_preemptions++;
    };

void Gestionnaire_stats::ajout_temps_creux(){
    _nb_temps_creux++;
    };

void Gestionnaire_stats::ajout_temps_reponse_TAPNC(int temps){
    _temps_reponse_TAPNC->push_back(temps);
    };

float Gestionnaire_stats::temps_reponse_moyen_TAPNC(){
    int nb_tapnc = 0,
        somme = 0;
    list<int>::const_iterator it_const;
    for(it_const = _temps_reponse_TAPNC->begin(); it_const != _temps_reponse_TAPNC->end(); it_const++){
        somme++;
        nb_tapnc += *it_const;
        }
    if (somme == 0)
        return 0;
    else
        return (float)(nb_tapnc) / (float)(somme);
    };

int Gestionnaire_stats::temps_CPU(){
    return _duree_simulation - _nb_temps_creux;
    };

int Gestionnaire_stats::nb_preemptions(){
    return _nb_preemptions;
    };

float Gestionnaire_stats::taux_preemption(){
    return ((float)(_nb_preemptions) / (float)(temps_CPU())) * 100.0;
    };
