#include"liste_taches.h"

using namespace std;

void ListeTaches::ajouter(const Tache &t){
    _taches->push_back(t);
    };

bool ListeTaches::supprimer(string id){
    list<Tache>::iterator it;
    bool trouve = false;
    for( it = _taches->begin(); it != _taches->end(); it ++ ){
        if(it->getId() == id){
            it = _taches->erase(it);
            trouve = true;
            }
        }
    return trouve;
    };

void ListeTaches::reinitialiser(){
    _taches->clear();
    };

void ListeTaches::afficher(ostream &os){
    list<Tache>::iterator it;
    if(!_taches->empty()){
        for( it = _taches->begin(); it != _taches->end(); it ++ ){
            it->afficher(os);
            os << "----------" << endl;
            }
        }
    else
        cout << "! la liste de tâches est vide !" << endl;
    };


list<Tache> *ListeTaches::getTaches()const{return _taches;};

float ListeTaches::somme_ci_sur_pi()const{
    float somme_ci = 0,
        somme_pi = 0;
    list<Tache>::const_iterator it_const;
    if(!_taches->empty())
        for( it_const = _taches->begin(); it_const != _taches->end(); it_const++ )
            if(it_const->getPi() != 0){
                somme_ci += it_const->getCi();
                somme_pi += it_const->getPi();
                }
    return somme_ci/somme_pi;
    };

int ListeTaches::nb_taches_periodiques()const{
    int nb = 0;
    list<Tache>::const_iterator it_const;
    if(!_taches->empty())
        for( it_const = _taches->begin(); it_const != _taches->end(); it_const++ )
            if(it_const->getPi() != 0){
                nb++;
                }
    return nb;
    };

bool ListeTaches::di_egal_pi()const{
    bool resultat = true;
    list<Tache>::const_iterator it_const;
    for( it_const = _taches->begin(); it_const != _taches->end(); it_const++ ){
        if (it_const->getPi() != it_const->getDi())
            resultat = false;
        }
    return resultat;
    };


ListeTaches::ListeTaches(string n){
    _name = n;
    _taches = new list<Tache>;
    };

ListeTaches::ListeTaches(){
    _name = "";
    _taches = new list<Tache>;
    };

string ListeTaches::getName(){
    return _name;
    };

ListeTaches::~ListeTaches(){};
