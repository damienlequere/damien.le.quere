package plugin;

/**
 * Cette "super interface" permet de relier toutes les classes de plugins.
 * @author stephane
 */
public interface Plugin {
	/**
	 * Renvoie le nom du plugin.
	 * @return Nom du plugin.
	 */
	String getNom();
}
