<? include('./ressources/param_bd.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
    
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Mise au point d'un moteur de recherche</title>

<link rel="stylesheet" type="text/css" media="screen" href="./ressources/ecran.css" />

</head>

<body>

<div class="titre">

<a href="index.php" title=""><h1 style="text-align:center;">Mise au point d'un moteur de recherche</h1></a>

<p style="text-align:center;"><em>Pierre-Jean Garreau</em> &amp; <em>Damien Le Quéré</em></p>

</div>


<h3>Caractéristiques de l'indexation inversée</h3>

<p>&Eacute;tapes de la construction de l'index inversé (d'après "<em><a href="http://nlp.stanford.edu/IR-book/information-retrieval-book.html" title="">Introduction to Information Retrieval</a></em>") :</p>

<ol>
<li><strong>Récupération des documents</strong> &nbsp; Indexation possible pour un ou plusieurs fichiers, puis utilisation d'un parseur <acronym title="Extended Markup Language">XML</acronym>. Récupération des données non-structurées des balises <em style="font-size:small;">&lt;HEAD&gt;</em> et <em style="font-size:small;">&lt;TEXT&gt;</em> de chaque document</li>
<li><strong>Tokenisation du texte</strong> &nbsp; Traitements préliminaires du texte : élimination des caractères de ponctuation et de la casse (tout en minuscule). Puis tokenisation sur le séprateur " ".</li>
<li><strong>Normalisation</strong> &nbsp;  
<ul>
<li>Utilisation d'un tableau associatif <em>terme -> stem</em> chargé au début de l'indexation d'après les fichiers '<em>stem.txt</em>' et '<em>stopwords.txt</em>'. <em class="important">Important : nous ne faisons pas de stémisation, ainsi un terme associé à aucun stem sera ignoré lors de l'indexation</em></li>
<li>Dans ce tableau associatif les <em>stopwords</em> ne sont pas stockés : chargement des stopwords dans une table et recherche dicotomique pour chaque <em>stemword</em> à indexer</li>
</ul>
</li>
<li><strong>Indexation des documents dans lequel apparait chaque terme</strong> &nbsp; L'index est stocké avec une <em>base de données relationnelle</em>. Nous n'obtenons pas directement de <em>posting-list</em>, nous stockons comme un enregistrement chaque apparition d'un stem dans un document (nous stockons aussi le nombre d'occurences du stem dans ce document). <br/>Avec cette technique il est facile d'obtenir une <em>posting-list</em> avec une requête SQL et ce avec une très bonne complexité temporelle. <br/>Exemple : <em class="requete">SELECT docno FROM documents WHERE stem='stem_cherché';</em></li> 
</ol>

<p>Informations complémentaires :</p>

<ul>
<li>Vitesse d'indexation avec une machine personnelle actuelle : <em>6.5 Mio / minute</em> (moins de 40 minutes pour la base de documents fournie)</li>
</ul>

<h3>Caractéristiques de la recherche documentaire</h3>

<ol>
<li>Traitement préliminaire : récupération des mots-clés en supprimant la ponctuation et la casse.</li>
<li>Puis, pour tous les types de recherche, récupération du stem associé à chaque mot-clé via une table de la base de données (pour ne pas avoir à parcourir le fichier '<em>stem.txt</em>' à chaque requête ce qui prend environ 5 secondes). <em class="important">Important : étant donnée une base de stem insuffisante ('<em>stem.txt</em>') beaucoup de mot-clés sont ignorés</em>.</li>
<li>Construction de la requête SQL selon le type de recherche
<ul>
<li>Recherche booléenne de tous les mots : utilisation de l'opérateur <em>ET</em></li>
<li>Recherche booléenne d'au moins un mot : utilisation de l'opérateur <em>OU</em></li>
<li>Prémisses d'une recherche vectorielle : résultats ordonnées selon le nombre de stems trouvés puis selon la somme des occurences des stems</li>
</ul>
</li>
</ol>


<h3>Caractéristiques techniques de l'implémentation</h3>

<ul>
<li>Language de programmation : <acronym title="PHP : Hypertext Processor"><em>PHP</em></acronym></li>
<li>Système de Gestion de Base de Données : <em>MySQL</em></li>
<li>Serveur <acronym title="HyperText Transfer Protocol,">HTTP</acronym> : <em>Apache</em></li>
</ul>

<h3>Avantages et inconvénients de cette implémentation</h3>

<p>Le stockage de l'index dans une base de données relationnelle :</p>

<ul>
<li>Inconvénient : Interaction avec un SGBD <em>ralentissant le processus d'indexation</em></li>
<li>Avantage : Recoupement d'informations très rapide car le SGBD est optimisé dans cet optique; donc <em>temps de recherche très cours</em></li>
</ul>

<p>Utilisation de PHP :</p>

<ul>
<li>Inconvénient : Moins adapté au traitement des chaînes de caractères qu'un langage comme <em>PERL</em></li>
<li>Avantages : Interaction très facile avec le SGBD. Utilisation du navigateur web pour l'affichage (pas d'interface graphique à programmer, facile à modifier / étendre)</li>
</ul>


<h3>Jeux de test</h3>

<p><a href="./ressources/queries.txt" title="">./ressources/queries.txt</a></p>

<ul>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=allegations%2C+or+measures+being+taken+against%2C+corrupt+public+officials+of+any+governmental+jurisdiction+worldwide.+" title="">Résultat de la requête n°1</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=a+type+of+weather+event+which+has+directly+caused+at+least+one+fatality+in+some+location." title="">Résultat de la requête n°2</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=prediction+about+the+prime+lending+rate%2C+or+will+an+actual+prime+rate+move.+" title="">Résultat de la requête n°3</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=incursions+by+land%2C+air%2C+or+water+into+the+border+area+of+one+country+by+military+forces+of+a+second+country+or+a+guerrilla+group+based+in+a+second+country." title="">Résultat de la requête n°4</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=an+event+or+result+of+politically+motivated+hostage-taking." title="">Résultat de la requête n°5</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=military+coup+d%27etat%2C+either+attempted+or+successful%2C+in+any+country." title="">Résultat de la requête n°6</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=or+identify+supporters+of+the+National+Rifle+Association+%28NRA%29%2C+or+its+assets." title="">Résultat de la requête n°7</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=development+in+the+Iran-Contra+Affair." title="">Résultat de la requête n°8</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=anticipate+a+rail+strike+or+an+ongoing+rail++strike." title="">Résultat de la requête n°9</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=poaching+method+used+against+a+certain+type+of+wildlife." title="">Résultat de la requête n°10</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=cite+the+signing+of+a+contract+or+preliminary+agreement%2C+or+the+making+of+a+tentative+reservation%2C+to+launch+a+commercial+satellite" title="">Résultat de la requête n°11</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=current+criminal+actions+against+officers+of+a+failed+U.S.+financial+institution" title="">Résultat de la requête n°12</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=crime+perpetrated+with+the+aid+of+a+computer" title="">Résultat de la requête n°13</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=efforts+by+the+non-communist%2C+industrialized+states+to+regulate+the+transfer+of+high-tech+goods+or+%22dual-use%22+technologies+to+undesirable+nations" title="">Résultat de la requête n°14</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=an+existing+or+pending+investment+by+an+OPEC+member+state+in+any+%22downstream%22+operation" title="">Résultat de la requête n°15</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=the+role+of+Israel+in+the+Iran-Contra+Affair" title="">Résultat de la requête n°16</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=computer+application+to+crime+solving" title="">Résultat de la requête n°17</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=actual+studies%2C+or+even+unsubstantiated+concerns+about+the+safety+to+manufacturing+employees+and+installation+workers+of+fine-diameter+fibers+used+in+insulation+and+other+products" title="">Résultat de la requête n°18</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=how+MCI+has+been+doing+since+the+Bell+System+breakup" title="">Résultat de la requête n°19</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=instances+of+fiber+optics+technology+actually+in+use" title="">Résultat de la requête n°20</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=+individuals+or+organizations+which+produce+fiber+optics+equipment" title="">Résultat de la requête n°21</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=one+or+both+sides+of+the+controversy+over+the+use+of+standards+of+performance+to+determine+salary+levels+and+incentive+pay+as+contrasted+with+determining+pay+solely+on+the+basis+of+seniority+or+longevity+on+the+job" title="">Résultat de la requête n°22</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=something+about+the+platform+of+a+1988+presidential++candidate" title="">Résultat de la requête n°23</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=machine+translation+system" title="">Résultat de la requête n°24</a></li>
<li><a href="http://localhost/Moteur%20de%20recherche/recherche_vectorielle.php?mots_cles_vect=acquisition+by+the+U.S.+Army+of+specified+advanced+weapons+systems" title="">Résultat de la requête n°25</a></li>
</ul>

<h3>&Eacute;valuation des résultats</h3>

<p>Les résultats des reqûetes demandées sont peu pertinents car beaucoup de mots-clés n'ont pas de stem associé (61% sur les 25 exemples donnés), et cela parceque notre base de stems est insuffisante (selon '<em>stems.txt</em>'). Pour rendre le système plus pertinent, il faudrait être capable de stematiser chaque mot du document "à la volée" sans avoir besoin d'un fichier comme 'stem.txt' qui sera toujours insuffisant. Piste : <em>the Porter Stemming Algorithm</em>.</p>

<p><a href="./rapport/rapport.pdf" title="">Rapport en version PDF</a></p>

<hr/>

<p style="text-align:center;"><a href="presentation.php" title="">Présentation du moteur de recherche</a> - <a href="http://localhost/phpmyadmin/" title="">Accès à la base de données</a><br/><a href="<?echo $documents;?>" title="">Voir les documents</a> - <a href="./rapport/rapport.pdf" title="">Rapport en version PDF</a></p>

</body>

</html>
