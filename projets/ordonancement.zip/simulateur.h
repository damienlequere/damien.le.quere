#ifndef SIMULATEUR_H_INCLUDED
#define SIMULATEUR_H_INCLUDED

#define TEMP_CREUX "-"

#include"generateur.h"
#include"liste_taches.h"

struct TacheSimulation{
    Tache t;
    int ci_restant;
    };

#include"BG.h"
#include"RMPS.h"
#include"EDFEDL.h"
#include"gestionnaire_stats.h"

using namespace std;

class Simulateur{

    public:

    Simulateur(int);
    void simuler_ordonnancement(ListeTaches*,int,int);
    void afficher_resultats_simulation(ostream&);

    private:

    string *_historiqueSimulation;
    int _dureeSim;
    Gestionnaire_stats _gestionnaire_statistiques;

};

#endif // SIMULATEUR_H_INCLUDED
