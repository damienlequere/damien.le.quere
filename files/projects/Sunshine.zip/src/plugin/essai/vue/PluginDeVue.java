package plugin.essai.vue;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import plugin.ControleurAbstrait;
import plugin.VueAbstraite;

/**
 * Exemple d'implementation de l'interface de VueAbstraite.
 * @author stephane
 */
@SuppressWarnings("serial")
public class PluginDeVue extends JFrame implements VueAbstraite {
	/**
	 * Le resultat a afficher.
	 */
	private int resultat = 0;
	
	/**
	 * Panel du resultat.
	 */
	private final JPanel panneauResultat = new JPanel(){
		public void paintComponent(Graphics g) {
			this.setBackground(new Color(128, 129, 135));
			g.setColor(new Color(128, 129, 135));
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			Font font = new Font("Arial", Font.BOLD, 40);
			g.setColor(new Color(0, 0, 0));
			g.setFont(font);
			g.drawString(String.valueOf(resultat), 190, 60);
		}
	};
	
	/**
	 * Champs de texte.
	 */
	private JTextField textField;
	
	/**
	 * Le controleur.
	 */
	private ControleurAbstrait controleur;
	
	/**
	 * Constructeur par defaut.
	 */
	public PluginDeVue() {
		super();
		this.initialiseInterface();
	}
	
	/**
	 * Constructeur avec parametre.
	 * @param controleur Le controleur que l'on desire.
	 */
	public PluginDeVue(ControleurAbstrait controleur) {
		super();
		this.initialiseInterface();
		this.controleur = controleur;
	}
	
	/**
	 * Initialise l'interface graphique.
	 */
	private void initialiseInterface() {
		this.setLocationRelativeTo(null);
		this.setSize(400, 200);
		this.setTitle("Vue");
		
		JPanel panneauPrincipal = new JPanel();
		JPanel panneauTemp = new JPanel();
		
		JPanel panneauBoutons = new JPanel();
		panneauBoutons.setBackground(new Color(109, 120, 136));
		JPanel panneauChampTexte = new JPanel();
		panneauChampTexte.setBackground(new Color(50, 58, 75));
		
		this.textField = new JTextField();
		this.textField.setPreferredSize(new Dimension(300, 30));
		panneauChampTexte.add(textField);
		
		JButton boutonPlus = new JButton("+");
		boutonPlus.addActionListener(new EcouteurPlus());
		
		JButton boutonMoins = new JButton("-");
		boutonMoins.addActionListener(new EcouteurMoins());
		
		JButton boutonMult = new JButton("*");
		boutonMult.addActionListener(new EcouteurMult());
		
		panneauBoutons.add(boutonPlus);
		panneauBoutons.add(boutonMoins);
		panneauBoutons.add(boutonMult);
		
		panneauPrincipal.setLayout(new GridLayout(2, 1));
		panneauTemp.setLayout(new GridLayout(2, 1));
		panneauPrincipal.add(panneauResultat);
		panneauTemp.add(panneauChampTexte);
		panneauTemp.add(panneauBoutons);
		panneauPrincipal.add(panneauTemp);
		
		this.setContentPane(panneauPrincipal);
	}
	
	/**
	 * Renvoie le controleur.
	 * @return Le controleur.
	 * @see plugin.VueAbstraite#getControleur()
	 */
	public ControleurAbstrait getControleur() {
		return this.controleur;
	}

	/**
	 * Initialise le programme.
	 * @see plugin.VueAbstraite#initialiser()
	 */
	public void initialiser() {
		this.setVisible(true);
	}

	/**
	 * Permet de changer le controleur.
	 * @param controleur Le controleur.
	 * @see plugin.VueAbstraite#setControleur(plugin.ControleurAbstrait)
	 */
	public void setControleur(ControleurAbstrait controleur) {
		this.controleur = controleur;
	}

	/**
	 * Met a jour les donnees recu depuis l'observable.
	 * @param o Donnees recu depuis l'observable.
	 * @see plugin.PluginObserveur#update(java.lang.Object)
	 */
	public void update(Object o) {
		resultat = (Integer) o;
		this.panneauResultat.repaint();
	}

	/**
	 * Renvoie le nom du plugin.
	 * @return Nom du plugin.
	 * @see plugin.Plugin#getNom()
	 */
	public String getNom() {
		return "Plugin de vue";
	}
	
	/**
	 * @author stephane
	 *
	 */
	public class EcouteurPlus implements ActionListener {
		/**
		 * Reagit a une action.
		 * @param e Action lancee.
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		public void actionPerformed(ActionEvent e) {
			controleur.controle("+", textField.getText());
		}
	}
	
	/**
	 * @author stephane
	 *
	 */
	public class EcouteurMoins implements ActionListener {
		/**
		 * Reagit a une action.
		 * @param e Action lancee.
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		public void actionPerformed(ActionEvent e) {
			controleur.controle("-", textField.getText());
		}
	}
	
	/**
	 * @author stephane
	 *
	 */
	public class EcouteurMult implements ActionListener {
		/**
		 * Reagit a une action.
		 * @param e Action lancee.
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		public void actionPerformed(ActionEvent e) {
			controleur.controle("*", textField.getText());
		}
	}

}
