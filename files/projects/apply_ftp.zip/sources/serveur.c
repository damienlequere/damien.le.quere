#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <dirent.h>

#define MAXNOM 256


struct instruction_s{
      int commande;
      char parametre[128];
   };


long fsize(FILE * fp)
{
    long pos, size;
    pos = ftell(fp);
    fseek(fp, 0, SEEK_END);
    size = ftell(fp);
    fseek(fp, pos, SEEK_SET);
    return size;
}

/* Verifier connection securisee ********************************************/

int verif_connec(char log[50], char mdp[50]){
   // A FAIRE verifier dans un fichier texte la correspondance log/mdp
   return 1;
}

/* Existence d'un repertoire ************************************************/
int existe_rep(char rep_courant[128], char nom_rep[256])
{
   char commande_sys[100];
   sprintf(commande_sys,"cd %s/%s",rep_courant,nom_rep);
   if(system(commande_sys)==0)
      return 1;
   else
      return 0;
}

/* Attente instruction *************************************0**********************/
int attente_instruction(int sock, char *msg[256]){
	char buf[256],
	     coms[128],
	     message[256];
	int lon,
	    c,
	    i=0,
	    commande;
	    
	if ((lon = read(sock, buf, sizeof(buf))) > 0){
	   buf[lon]='\0';
	   
	   // Recuperation de la commande
	   strncpy(coms,buf,3);
	   coms[3]='\0';
	   // Conversion pour avoir la commande en (int)
	   commande = strtol(coms,NULL,10);
	   // Recuperation du message
	   for(c=4;c<=lon;c++){
	      message[i] = buf[c];
	      i++;
	   }
	   message[lon+1] = '\0';
	   sprintf(msg,"%s",message);
	   return commande;
	}
}
/* Envoi message *************************************************************/
void envoi_message(int sd, char * message){
	int lon;
	char buf[256];
	if((write(sd,message,strlen(message))) < 0){
      perror(">>Pb sur le write");
      exit(1);
    }
}
/* Attente fichier ***********************************************************/
void attente_fichier(int sock, char *fichier,int taille_fic){
	int n,taille=32,cpt = 0;
	unsigned char buf[taille];
	
	FILE* fp = fopen(fichier, "wb");
	printf("Reception d'un fichier par buffer de [%i] octets ...\n",taille);
	while (((n = recv (sock, buf, sizeof buf, 0)) > 0) && (cpt*taille<(taille_fic-taille))){
	   fwrite(buf, sizeof buf, 1, fp);
		cpt = cpt+1;
	}
	// On calcul la taille du dernier buffer puis on l'ecrit dans le fichier
	int t_mod;t_mod = taille_fic % taille;
	fwrite(buf, t_mod, 1, fp);
	
	printf("Taille fichier recu : %i octets\n",fsize(fp));
	fclose(fp);
	return;
}

/*################ POINT D'ENTREE DU SERVEUR ################*/
int main(int argc,char **argv){

//Variables globales
char rep_courant[128],
     rep_racine[128]="./Repserveur",
     login[50],
     mot_de_pass[50];
struct instruction_s instruction;

	int sd, nsd, ladcour;
	struct sockaddr_in adsock, adclcour;
	struct hostent *hptr;
	struct servent *sptr;
	char machine[MAXNOM+1];
	
	gethostname(machine, MAXNOM);
	
	/* recuperation de la structure d'adresse en utilisant le nom */
	if ((hptr=gethostbyname(machine)) == NULL)
	{
		perror(">> Machine inconnue");
		exit(1);
	}
	
	/* initialisation de la structure adsock avec les infos recuperes */
	/*  copie de hptr vers adsock */
	
	bcopy((char *)hptr -> h_addr, (char *)&adsock.sin_addr, hptr->h_length);
	adsock.sin_family = hptr->h_addrtype;
	adsock.sin_addr.s_addr=INADDR_ANY;
	adsock.sin_port = htons(1026);
	/* creation d'un socket */
	if ((sd=socket(AF_INET, SOCK_STREAM,0)) <0){
		perror(">> Probleme de creation du socket");
		exit(1);
	}
	/* association du socket sd à la structure d'adresse adsock */
	if ((bind(sd, &adsock, sizeof(adsock))) <0){
		perror(">> Probleme avec le binding");
		exit(1);
	}
	printf("%d = Num-Port\n", ntohs(adsock.sin_port));
	/* initialisation de la queue d'ecoute */
	listen(sd,5);
	
	/* attente des connexions et traitement */
	for(;;){
		ladcour = sizeof(adclcour);
		
		/* adclcour sera renseigne par accept via les infos du connect */
		if ((nsd = accept(sd, &adclcour, &ladcour)) <0){
			perror(">> Problème sur l'accept");
			exit(1);
		}else{
			int pid;pid = fork();
			if (pid == 0){
				int identification_en_cours = 0;
				char reponse[256];
				
			/* IDENTIFICATION **************************************************************************************/
			while(identification_en_cours == 0){
		      // On attend un message du client et on le decompose 
				// en parametre(s) de la commande serveur
				instruction.commande = attente_instruction(nsd,&instruction.parametre);
				
				printf("Commande : %d; ",instruction.commande);
				printf("Parametre : %s\n",instruction.parametre);
				
			   if((instruction.commande==101)||(instruction.commande==102)){
					   
			   /****** Connexion non-securisee ******/
			   if(instruction.commande==101){
				   sprintf(login,"%s",instruction.parametre);
					char commande_sys[100];
					      
					if(!existe_rep(rep_racine,instruction.parametre)){
					   // On creer le repertoire de session
					   sprintf(commande_sys,"mkdir %s/%s",rep_racine,instruction.parametre);
					   system(commande_sys);
					   // On se deplace dans le repertoire cree et on le designe comme repertoire racine
					   // pour que l'utilisateur ne puisse remonte plus haut
					   sprintf(rep_courant,"%s/%s",rep_racine,instruction.parametre);
					   sprintf(rep_racine,"%s",rep_courant);
					   sprintf(reponse,"Le repertoire de session [%s] n'existe pas ... creation\n",instruction.parametre);
					   }else{
					      sprintf(rep_courant,"%s/%s",rep_racine,instruction.parametre);
					      sprintf(rep_racine,"%s",rep_courant);
					      sprintf(reponse,"Le repertoire de session [%s] existe ... ouverture\nVous etes dans [%s]\n",instruction.parametre,rep_courant);
					   }
					   identification_en_cours = 1;
					   envoi_message(nsd,reponse);
					}
					
					/****** Connexion securisee ******/
					if(instruction.commande==102){
                  char log[50],
                       mdp[50];
                  int c,
                      taille_param,
                      trouve_slash = 1,
                      taille_l = 0,       // taille du login
                      taille_m = 0;       // taille du mot de pass
                      
               // Recuperation login et mot de pass depuis instruction.parametre
               taille_param = strlen(instruction.parametre);
               for (c=0 ; c<=taille_param ; c++){
                  //Avant le '/'
                  if (trouve_slash){
                     if (instruction.parametre[c]=='/')
                        {trouve_slash=0;log[taille_l]='\0';}
                     else{
                        log[taille_l] = instruction.parametre[c];
                        taille_l++;
                        }
                  }//Après le '/'
                     else{
                        if (instruction.parametre[c]!='/'){
                           mdp[taille_m] = instruction.parametre[c];
                           taille_m++;
                        }
                     }
                  }//endfor
                     
                  sprintf(login,"%s",log);
                  sprintf(mot_de_pass,"%s",mdp);
                  
                  if(verif_connec(login,mot_de_pass)==0){
                     // Si connection OK
					      sprintf(rep_courant,"%s/%s",rep_racine,login);
					      sprintf(rep_racine,"%s",rep_courant);
					      sprintf(reponse,"Login et pass corrects ouverture de [%s]\n\n",login);
					      envoi_message(nsd,reponse);
					      identification_en_cours = 1;
                  }else{
                     // Si connection echoue
                     sprintf(reponse,"Login ou pass incorrect!\n");
                     envoi_message(nsd,reponse);
                  }
               }
            }
         }
		   /* FIN IDENTIFICATION **********************************************************************************/
		   
			/* ON EST IDENTIFIE, ON ATTEND DES INSTRUCTIONS DU CLIENT **********************************************/
				
		   while(instruction.commande!=666){   
		   
			// On attend un message du client et on le decompose 
			// en parametre(s) de la commande serveur
		   instruction.commande = attente_instruction(nsd,&(instruction.parametre));
		   
		   printf("Commande : %d; ",instruction.commande);
			printf("Parametre : %s\n",instruction.parametre);
		   
		   // Selon la commande du message recu on traite le ou les parametre(s) du message
         switch (instruction.commande){
            case 107 : /* retourner repertoire courant */
            {
               sprintf(reponse,"Repertoire courant : [%s]\n",rep_courant);
               reponse[strlen(reponse)]='\0';
               envoi_message(nsd,reponse);
            }
            break;
            
				case 201 : /* Lister les repertoires du repertoire courant */
            {
            int nb_rep = 0;
      
            sprintf(reponse,"Liste des repertoires de [%s]\n",rep_courant);
            DIR * rep = opendir (rep_courant);
            if (rep != NULL){
               struct dirent * ent;
               while ((ent = readdir (rep)) != NULL){
                  if((strcmp(ent->d_name,".")) && (strcmp(ent->d_name,".."))){
                     char nouveau_rep[256];
                     sprintf(nouveau_rep,"%s/%s",rep_courant,ent->d_name);
                     DIR * testrep = opendir(nouveau_rep);
                     if(testrep!= NULL){
                        //printf("   * %s\n",ent->d_name);
                        char ligne_temp[50];sprintf(ligne_temp,"   * %s\n",ent->d_name);
                        strcat(reponse,ligne_temp);
                        nb_rep++;
                     }
                  }
               }
               if(nb_rep==0){
                  reponse[0]='\0';
                  sprintf(reponse,"\n[ AUCUN REPERTOIRE ]\n\n");
               }
               closedir (rep);
               reponse[strlen(reponse)]='\0';
               envoi_message(nsd,reponse);
            }
            }
            break;
           
            case 202 : /* Creer un repertoire dans le repertoire courant */
            {
            char nouveau_rep[50],commande_sys[100];
            sprintf(nouveau_rep, "%s/%s", rep_courant, instruction.parametre);
            sprintf(commande_sys,"mkdir %s;",nouveau_rep);
            if(system(commande_sys)==0){
               printf("#%d : Creation du repertoire [%s]\n",instruction.commande, nouveau_rep);
               sprintf(reponse,"Creation du repertoire [%s] effectuee\n", nouveau_rep);
            }else{
               printf("#%d : Impossible de creer le repertoire [%s]\n",instruction.commande, nouveau_rep);
               sprintf(reponse,"Impossible de creer le repertoire [%s]\n", nouveau_rep);
            }
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
           
            case 203 : /* Changer de repertoire courant */
            {
            char commande_sys[100],
            test[50];
            sprintf(test,"%s/%s",rep_courant,instruction.parametre);
            sprintf(commande_sys,"cd %s",test);
            if(system(commande_sys)==0){
               if(!strcmp(instruction.parametre,".")){
                  rep_courant[0]='\0';
                  strncat(rep_courant,test,strlen(test)-2);
                  //printf("#%d : Le nouveau repertoire courant est : %s\n",instruction.commande,rep_courant);
                  sprintf(reponse,"Le nouveau repertoire courant est : %s\n",rep_courant);
               }else{
                  if(!strcmp(instruction.parametre,"..")){
                     if(strcmp(rep_courant,rep_racine)){
                        int c,nb_slashes=0;
                        for(c=strlen(test);nb_slashes<2;c--){
                           if(test[c]=='/')
                              nb_slashes++;
                           test[c+1]='\0';
                        }
                     rep_courant[0]='\0';
                     strncat(rep_courant,test,strlen(test)-1);
                     sprintf(reponse,"Le nouveau repertoire courant est : %s\n",rep_courant);
                     }else{
                        printf("Acces interdit !\n");
                        sprintf(reponse,"! Vous n'avez pas le droit de monter plus haut !\nLe nouveau repertoire courant est : %s\n",rep_courant);
                        }
                     }else{
                        sprintf(rep_courant,"%s/%s",rep_courant,instruction.parametre);
                        sprintf(reponse,"Le nouveau repertoire courant est : %s\n",rep_courant);
                     }
                  }
               
               }else{ 
                  printf("#%d : Le repertoire [%s] n'existe pas !\n",instruction.commande,instruction.parametre);
                  sprintf(reponse,"Le repertoire [%s] n'existe pas !\n",instruction.parametre);
               }
            
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
           
            case 204 : /* Renommer un repertoire du repertoire courant */
            {
            char ancien_nom[50],    // ancien repertoire
                 nouveau_nom[50],   // nouveau repertoire
                 commande_sys[100]; // commande pour l'appel systeme
            int c,                  // compteur pour parcour du message
                taille_msg,
                trouve_slash = 1,
                taille_a = 0,         // taille du nom de l'ancien repertoire
                taille_n = 0;         // taille du nom du nouveau repertoire
            taille_msg = strlen(instruction.parametre);
            for (c=0 ; c<=taille_msg ; c++){
               //Avant le '/'
               if (trouve_slash){
                  if (instruction.parametre[c]=='/')
                     {trouve_slash=0;ancien_nom[taille_a]='\0';}
                  else{
                     ancien_nom[taille_a] = instruction.parametre[c];
                     taille_a++;
                  }
               }//Après le '/'
               else{
                  if (instruction.parametre[c]!='/'){
                     nouveau_nom[taille_n] = instruction.parametre[c];
                     taille_n++;
                  }
               }
            }//endfor
            
            // Construction des adresse absolue des repertoires depuis le repertoire racine
            char ancien_nom_abs[50], nouveau_nom_abs[50];
            sprintf(ancien_nom_abs,"%s/%s",rep_courant,ancien_nom);
            sprintf(nouveau_nom_abs,"%s/%s",rep_courant,nouveau_nom);
            
            // Construction de la commande
            sprintf(commande_sys,"mv %s %s",ancien_nom_abs, nouveau_nom_abs);
            // Appel systeme pour renommer
            if(system(commande_sys)==0){
               printf("\n#%d : Le repertoire [%s] a ete renomme [%s]\n",instruction.commande,ancien_nom_abs,nouveau_nom_abs);
               sprintf(reponse,"Le repertoire [%s] a ete renomme [%s]\n",ancien_nom_abs,nouveau_nom_abs);
            }else{
               printf("\n%d : Le repertoire [%s] n'a pas pu etre renomme [%s]\n",instruction.commande,ancien_nom_abs,nouveau_nom_abs);
               sprintf(reponse,"Le repertoire [%s] n'a pas pu etre renomme [%s]\n",ancien_nom_abs,nouveau_nom_abs);
            }
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
            
            case 205 : /* Supprimer un repertoire du repertoire courant */
            {
            char supp_rep[256], commande_sys[256];
            sprintf(supp_rep, "%s/%s", rep_courant, instruction.parametre);
            printf("%s\n",supp_rep);
            sprintf(commande_sys, "rm -rf %s/*;rmdir %s;",supp_rep,supp_rep);
            if(system(commande_sys)==0){
               printf("#%d : Suppression de [%s] et de tout ce qu'il contient effectuee\n",instruction.commande,supp_rep);
               sprintf(reponse,"Suppression de [%s] et de tout ce qu'il contient effectuee\n",supp_rep);
            }else{
               printf("#%d : Le repertoire [%s] n'existe pas\n",instruction.commande,supp_rep);
               sprintf(reponse,"Le repertoire [%s] n'existe pas\n",supp_rep);
               }
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
            
            case 301 : /* Lister les fichiers du repertoire courant */
            {
            int nb_fic = 0;
      
            //printf("#%d : Liste des fichiers de [%s]\n",instruction.commande,rep_courant);
            sprintf(reponse,"Liste des fichiers de [%s]\n",rep_courant);
            DIR * rep = opendir (rep_courant);
            if (rep != NULL){
               struct dirent * ent;
               while ((ent = readdir (rep)) != NULL){
                  if((strcmp(ent->d_name,".")) && (strcmp(ent->d_name,".."))){
                     char nouveau_rep[256];
                     sprintf(nouveau_rep,"%s/%s",rep_courant,ent->d_name);
                     DIR * testrep = opendir(nouveau_rep);
                     if(testrep== NULL){
                        //printf("   * %s\n",ent->d_name);
                        nb_fic++;
                        char ligne_temp[50];sprintf(ligne_temp,"   * %s\n",ent->d_name);
                        strcat(reponse,ligne_temp);
                     }
                  }
               }
               closedir (rep);
            }
            if (nb_fic == 0){
               sprintf(reponse,"\n   [ AUCUN FICHIER ]\n\n");
            }
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
      
            case 302 : /* Receptionner un fichier */
            {
            char nom_fic_abs[50];
            int taille_fic;
            /* Recuperation du nom du fichier a recevoir et de sa taille *******************/
            char nom_fic[50],taille_fic_s[50],commande_sys[100];
            int c,taille_msg,trouve_slash = 1,taille_a = 0,taille_n = 0;
            taille_msg = strlen(instruction.parametre);
            for (c=0 ; c<=taille_msg ; c++){
               //Avant le '/'
               if (trouve_slash){
                  if (instruction.parametre[c]=='/'){
                     trouve_slash=0;
                     nom_fic[taille_a]='\0';
                  }else{
                     nom_fic[taille_a] = instruction.parametre[c];
                     taille_a++;
                  }
               }//Après le '/'
               else{
                  if (instruction.parametre[c]!='/'){
                     taille_fic_s[taille_n] = instruction.parametre[c];
                     taille_n++;
                  }
               }  
            }//endfor
            /*********************************************************************************/
            sprintf(nom_fic_abs,"%s/%s",rep_courant,nom_fic);
            taille_fic = strtol(taille_fic_s,NULL,10);
            
            printf("nom fic abs : [%s]\n",nom_fic_abs);
            printf("taille fic : [%d]\n",taille_fic);
            
            sprintf(reponse,"Serveur pres\n");
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            
            attente_fichier(nsd, nom_fic_abs, taille_fic);
            }
            break;
      
            case 303 : /* Deplacer un fichier du repertoire courant */
            {
            char nom_fic[50],          // nom du fichier a deplacer
                 nouveau_rep[50],      // nouveau repertoire du fichier
                 commande_sys[100];    // commande pour l'appel systeme
            int c,                     // compteur pour parcour du message
                taille_msg,
                trouve_slash = 1,
                taille_a = 0,
                taille_n = 0;
             
            taille_msg = strlen(instruction.parametre);
            for (c=0 ; c<=taille_msg ; c++){
               //Avant le '/'
               if (trouve_slash){
                  if (instruction.parametre[c]=='/'){
                     trouve_slash=0;
                     nom_fic[taille_a]='\0';
                  }else{
                     nom_fic[taille_a] = instruction.parametre[c];
                     taille_a++;
                  }
               }//Après le '/'
               else{
                  if (instruction.parametre[c]!='/'){
                     nouveau_rep[taille_n] = instruction.parametre[c];
                     taille_n++;
                  }
               }  
            }//endfor
      
            // Construction des adresse absolue des fichier depuis le repertoire racine
            char nom_fic_abs[50], nouveau_rep_abs[50];
            sprintf(nom_fic_abs,"%s/%s",rep_courant,nom_fic);
            sprintf(nouveau_rep_abs,"%s/%s",rep_courant,nouveau_rep);
      
            // Construction de la commande
            sprintf(commande_sys,"mv %s %s/%s;",nom_fic_abs, nouveau_rep_abs,nom_fic);
            // Appel systeme pour renommer
            if(system(commande_sys)==0){
               printf("\n#%d : Le fichier [%s] a ete deplace [%s]\n",instruction.commande,nom_fic,nouveau_rep_abs);
               sprintf(reponse,"Le fichier [%s] a ete deplace [%s]\n",nom_fic,nouveau_rep_abs);
            }else{
               printf("\n#%d : Le fichier [%s] n'a pas pu etre deplace [%s]\n",instruction.commande,nom_fic,nouveau_rep_abs);
               sprintf(reponse,"Le fichier [%s] n'a pas pu etre deplace [%s]\n",nom_fic,nouveau_rep_abs);
            }
            
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
          
            case 304 : /* Renommer un fichier du repertoire courant */
            {
            char ancien_nom[50],       // ancien nom de fichier
                 nouveau_nom[50],      // nouveau nom de fichier
                 commande_sys[100];    // commande de renommage (pour l'appel systeme)
            int c,                     // compteur pour parcour du message
                taille_msg,
                trouve_slash = 1,
                taille_a = 0,         // taille du nom de l'ancien fichier
                taille_n = 0;         // taille du nom du nouveau fichier
           
            taille_msg = strlen(instruction.parametre);
            for (c=0 ; c<=taille_msg ; c++){
               //Avant le '/'
               if (trouve_slash){
                  if (instruction.parametre[c]=='/'){
                     trouve_slash=0;
                     ancien_nom[taille_a]='\0';
                  }else{
                   ancien_nom[taille_a] = instruction.parametre[c];
                   taille_a++;
                  }
               }//Après le '/'
               else{
                  if (instruction.parametre[c]!='/'){
                     nouveau_nom[taille_n] = instruction.parametre[c];
                     taille_n++;
                  }
               }
            }//endfor
          
            // Construction des adresse absolue des fichier depuis le repertoire racine
            char ancien_nom_abs[50], nouveau_nom_abs[50];
            sprintf(ancien_nom_abs,"%s/%s",rep_courant,ancien_nom);
            sprintf(nouveau_nom_abs,"%s/%s",rep_courant,nouveau_nom);

            // Construction de la commande
            sprintf(commande_sys,"mv %s %s",ancien_nom_abs, nouveau_nom_abs);
            // Appel systeme pour renommer
            if(system(commande_sys)==0){
               printf("\n#%d : Le fichier [%s] a ete renomme [%s]\n",instruction.commande,ancien_nom,nouveau_nom);
               sprintf(reponse,"Le fichier [%s] a ete renomme [%s]\n",ancien_nom,nouveau_nom);
            }else{
               printf("\n#%d : Le fichier [%s] n'a pas pu etre renomme [%s]\n",instruction.commande,ancien_nom,nouveau_nom);
               sprintf(reponse,"Le fichier [%s] n'a pas pu etre renomme [%s]\n",ancien_nom,nouveau_nom);
               }
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
          
            case 305 : /* Supprimer un fichier du repertoire courant */
            {
            char supp_fic[256], commande_sys[256];
            sprintf(supp_fic, "%s/%s", rep_courant, instruction.parametre);
            printf("%s\n",supp_fic);
            sprintf(commande_sys, "rm %s;",supp_fic);
            if(system(commande_sys)==0){
               printf("#%d : Suppression de [%s] effectuee\n",instruction.commande,supp_fic);
               sprintf(reponse,"Suppression de [%s] effectuee\n",supp_fic);
            }else{
               printf("#%d : Le fichier [%s] n'existe pas\n",instruction.commande,supp_fic);
               sprintf(reponse,"Le fichier [%s] n'existe pas\n",supp_fic);
               }
            reponse[strlen(reponse)]='\0';
            envoi_message(nsd,reponse);
            }
            break;
            
            case 666 :
            {
               sprintf(reponse,"Bye bye\n");
               reponse[strlen(reponse)]='\0';
               envoi_message(nsd,reponse);
            }
            break;
            
         }//endswitch
         
         }// endwhile
         
         /* FERMETURE DE LA SOCKET */
		   close(nsd);
			exit(0);
			
			}else{
				close(nsd);
			}
		}
	}
	return 0;
} //main
