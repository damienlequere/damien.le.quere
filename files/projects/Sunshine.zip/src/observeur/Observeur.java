package observeur;

/**
 * Deuxieme partie du pattern observeur, cette classe permet d'etre
 * prevenu en cas de mise a jour d'un observable auquel on est enregistre.
 * @author stephane
 */
public interface Observeur {
	/**
	 * Met a jour les donnees recu depuis l'observable.
	 * @param o Donnees recu depuis l'observable.
	 */
	void update(Object o);
}
