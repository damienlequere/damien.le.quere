package decouverte;

import java.util.List;
import java.util.Map;

import plugin.Programme;

/**
 * La classe abstraite de decouverte sert de point de variabilite
 * pour la recherche de jar valide. Ainsi on peut choisir ou creer
 * une maniere de decouvrir les jars differente de celle de base.
 * Cette classe abstraite propose differente methode a implementer.
 * La premiere indique si un jar donne est valide ou non.
 * La seconde permet de donner la liste des repertoires dans lesquels
 * on doit aller chercher les jars.
 * Enfin la troisieme permet d'extraire les donnees d'un jar donne
 * afin de creer les objets programmes qui serviront a lancer les
 * plugins.
 * @author stephane
 */
public abstract class Decouverte {
	/**
	 * La liste des repertoires dans lesquels on va chercher nos jars.
	 */
	protected List<String> repertoiresDeRecherche;
	
	/**
	 * Indique si un jar est valide ou non.
	 * @param jar L'adresse absolue du fichier jar.
	 * @return True si le jar est valide, false sinon.
	 */
	public abstract boolean estJarValide(String jar);
	
	/**
	 * Renvoie la liste des repertoires ou chercher les jars.
	 * @return La liste des repertoires ou chercher les jars.
	 */
	public List<String> getRepertoiresDeRecherche() {
		return this.repertoiresDeRecherche;
	}
	
	/**
	 * Si le jar contient un morceau de programme, celui ci est ajoute a la map des programmes.
	 * @param jar Le fichier jar en contenant un eventuel programme.
	 * @param map La map des programmes.
	 * @return La map des programmes.
	 */
	public abstract Map<String, Programme> putProgramme(String jar, Map<String, Programme> map);
}
