package vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

import observeur.Observeur;
import plugin.Programme;
import principal.Sunshine;

import controleur.Controleur;

/**
 * Cette classe sert d'interface graphique a notre projet.
 * @author stephane
 */
@SuppressWarnings("serial")
public class Fenetre extends JFrame implements Observeur {
	/**
	 * Le logger de Sunshine.
	 */
	private static final Logger LOGGER = Logger.getLogger("vue.Fenetre");
	
	/**
	 * Le controleur.
	 */
	private Controleur controleur;
	
	/**
	 * Le panneau de fond de la fenetre.
	 */
	private final JPanel panneau = new JPanel();
	
	/**
	 * Le panneau central.
	 */
	private final JPanel panCentral = new JPanel();
	
	/**
	 * Le panneau du menu.
	 */
	private final JPanel panMenu = new JPanel();
	
	/**
	 * La liste deroulante.
	 */
	private JComboBox comboBox;
	
	/**
	 * La liste des programmes.
	 */
	private Map<String, Programme> listeProgramme;
	
	/**
	 * Contructeur par defaut.
	 */
	public Fenetre() {
		super();
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "Fenetre", e);
		}
		
		listeProgramme = new HashMap<String, Programme>();
		this.initialisationInterface();
	}
	
	/**
	 * Initialise l'interface graphique.
	 */
	private void initialisationInterface() {
		LOGGER.entering(this.getClass().getName(), "initialisationInterface");
		
		this.setTitle("Sunshine");
		this.setSize(300, 150);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton bouton = new JButton("Lancer !");		
		bouton.addActionListener(new Ecouteur(this));
		
		comboBox = new JComboBox(listeProgramme.keySet().toArray());
		
		panMenu.add(bouton);
		panCentral.setLayout(new BorderLayout());
		panCentral.add(comboBox, BorderLayout.CENTER);
		
		panCentral.setPreferredSize(new Dimension(300, 110));
		panMenu.setPreferredSize(new Dimension(300, 40));
		panCentral.setBackground(new Color(109, 120, 136));
		panMenu.setBackground(new Color(50, 58, 75));
		
		panneau.setLayout(new BorderLayout());
		panneau.add(panCentral, BorderLayout.CENTER);
		panneau.add(panMenu, BorderLayout.SOUTH);
		
		this.setContentPane(panneau);
		
		LOGGER.exiting(this.getClass().getName(), "initialisationInterface");
	}
	
	/**
	 * Renvoie la valeur selectionnee dans la liste deroulante.
	 * @return La valeur selectionnee dans la liste deroulante.
	 */
	public String getValue() {
		LOGGER.entering(this.getClass().getName(), "getValue");
		
		String str = (String) this.comboBox.getSelectedItem();
		
		LOGGER.exiting(this.getClass().getName(), "getValue", str);
		return str;
	}
	
	/**
	 * Renvoie le programme associe au nom donne en parametre.
	 * @param nom Le nom du programme desire.
	 * @return Le programme associe au nom.
	 */
	public Programme getProgramme(String nom) {
		LOGGER.entering(this.getClass().getName(), "getProgramme", nom);
		
		Programme p = this.listeProgramme.get(nom); 
		
		LOGGER.exiting(this.getClass().getName(), "getProgramme", p);
		return p;
	}
	
	/**
	 * Initialise le programme.
	 */
	public void initialiser() {
		LOGGER.entering(this.getClass().getName(), "initialiser");
		
		this.controleur.controle("preparer_les_programmes", null);
		this.setVisible(true);
		
		LOGGER.exiting(this.getClass().getName(), "initialiser");
	}
	
	/**
	 * Permet de changer le controleur.
	 * @param controleur Le controleur.
	 */
	public void setControleur(Controleur controleur) {
		LOGGER.entering(this.getClass().getName(), "setControle", controleur);
		
		LOGGER.exiting(this.getClass().getName(), "setControle");
		this.controleur = controleur;
	}
	
	/**
	 * Renvoie le controleur.
	 * @return Le controleur.
	 */
	public Controleur getcontroleur() {
		LOGGER.entering(this.getClass().getName(), "getControleur");
		
		LOGGER.exiting(this.getClass().getName(), "getControleur", this.controleur);
		return this.controleur;
	}

	/**
	 * Met a jour les donnees recu depuis l'observable.
	 * @param o Donnees recu depuis l'observable.
	 * @see observeur.Observeur#update(java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	public void update(Object o) {
		LOGGER.entering(this.getClass().getName(), "update", o);
		this.listeProgramme = (HashMap<String, Programme>) o;
		
		if(o != null)
		{
			for(String str : listeProgramme.keySet())
			{
				LOGGER.log(Level.INFO, "Programme pret : "+listeProgramme.get(str).estPret());
				LOGGER.log(Level.INFO, listeProgramme.get(str).getNom()+" "+listeProgramme.get(str).getVersion());
				LOGGER.log(Level.INFO, "Controleur : "+listeProgramme.get(str).getControleurJar()+" "+listeProgramme.get(str).getControleurClasse());
				LOGGER.log(Level.INFO, "Modele : "+listeProgramme.get(str).getModeleJar()+" "+listeProgramme.get(str).getModeleClasse());
				LOGGER.log(Level.INFO, "Vue : "+listeProgramme.get(str).getVueJar().toString()+" "+listeProgramme.get(str).getVueClasses().toString());
				
				this.comboBox.addItem(str);
			}
		}
		
		LOGGER.exiting(this.getClass().getName(), "update");
	}
}
