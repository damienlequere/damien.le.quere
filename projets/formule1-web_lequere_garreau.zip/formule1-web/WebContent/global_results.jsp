<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Vector" %>
<% Vector<String> lignesTableClassement = (Vector<String>) request.getAttribute("lignesTableClassement"); %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Résultats de Abu-Dhabi du 17/../2009</title>

<style>
body{font-family: Arial, Helvetica, "Liberation Sans", FreeSans, sans-serif;font-size:0.9em;}
table, td, th{border:1px solid #444;}
table:hover{cursor:default;}
table{border-collapse:collapse;}
td{padding:0 0.5em;}
th{background:#444;padding:0.1em 0.5em;color:white;font-weight:normal;}
tr:hover{background:#ddd;}
a{color:#2777BC;}
a:hover{color:#1D588C;}
</style>

</head>

<body>
<h1>Résultats de Abu-Dhabi du 17/../2009</h1>

<table>
<tr><th>Classement</th><th>N° Pilote<th>Nom Pilote</th><th>Dernier Temps</th><th>Meilleur Temps</th></tr>
<% for (String resPilote : lignesTableClassement) out.println(resPilote);%></table>

</body>

</html>