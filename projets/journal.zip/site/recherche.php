<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Encore un quotidien national</title>

<link rel="stylesheet" type="text/css" media="screen" href="./style/ecran.css" />

<script type="text/javascript" src="./resources/jquery.js"></script>          

<script type="text/javascript">
$(document).ready(function() {
   $("#connect").hide();
   $("a#lien_connect").click(function() {
      $("#connect").show();
   });
   $("#titre").click(function () {
         $("#connect").hide();
    });
   $("#champ_recherche").focus(function() {
      $("#champ_recherche").val("");
   });

   $("#champ_recherche").blur(function() {
      $("#champ_recherche").val("Rechercher un article");
   });

 });

</script>

</head>

<body>

<div id="page">

<? include("./blocs/titre.html"); ?>

<ul id="menu">

<li><a href="./index.php" title="">Accueil</a></li>
<li><a href="./politique.php" title="">Politique</a></li>
<li><a href="./sport.php" title="">Sport</a></li>
<li><a href="./economie.php" title="">&Eacute;conomie</a></li>
<li><a href="./sante.php" title="">Santé</a></li>

</ul>

<table>

<tr>

<td id="contenu">

<form id="recherche" method="get" action="recherche.php">
<input type="text" value="Rechercher un article" class="texte" id="champ_recherche" name="mots"/>
<input type="submit" value="Rechercher"/>
</form>

<?

$mois = $_GET["mois"];
$mots = $_GET["mots"];

echo("<h2>Articles trouvés</h2><p>Résultat de votre recherche pour \"".$mots."\" : 2 articles trouvés</p>");

?>

<div class="article">
<img src="./img/grippe.jpg" alt="" style="float:right;"/>
<h2 style="margin-top:0;"><a href="" title="">100.000 cas de grippe A
la semaine dernière</a></h2>

<p>Le seuil épidémique est dépassé en France. Au total, 147 malades ont été hospitalisés, dont 19 pour des formes graves.
</p>
<ul>
<li><a href="" title="">DOSSIER SPECIAL - Grippe A, l'alerte mondiale </a></li>
</ul>

<hr/>

</div>

<div class="article">

<h2 style="margin-top:0;"><a href="" title="">Solvants : un risque accru
de malformations fœtales</a></h2>

<img src="./img/echo.jpg" alt=""/>

<p>Une étude de l'Inserm auprès de 3 000 femmes enceintes montre que 30 % d'entre elles sont exposées à des solvants sur leur lieu de travail.</p>

<hr/>

</div>

<td id="sidebar">

<form method="post" action="" style="text-align:center;margin-bottom:15px;">

Articles par mois :
<select id="mois" name="mois">
<option value=''> août 2009 </option>
<option value=''> juillet 2009 </option>
<option value=''> juin 2009 </option>
<option value=''> mai 2009 </option>
<option value=''> avril 2009 </option>
<option value=''> mars 2009 </option>
<option value=''> février 2009 </option>
<option value=''> janvier 2009 </option>
<option value=''> décembre 2008 </option>
<option value=''> novembre 2008 </option>
<option value=''> octobre 2008 </option>
<option value=''> septembre 2008 </option>
<option value=''> août 2008 </option>
<option value=''> juillet 2008 </option>
<option value=''> juin 2008 </option>
<option value=''> mai 2008 </option>
<option value=''> avril 2008 </option>
<option value=''> mars 2008 </option>
<option value=''> février 2008 </option>
<option value=''> janvier 2008 </option>
<option value=''> décembre 2007 </option>
<option value=''> novembre 2007 </option>
<option value=''> octobre 2007 </option>
<option value=''> septembre 2007 </option>
<option value=''> août 2007 </option>
<option value=''> juin 2007 </option>
<option value=''> mai 2007 </option>
<option value=''> avril 2007 </option>
<option value=''> mars 2007 </option>
<option value=''> février 2007 </option>
<option value=''> janvier 2007 </option>
<option value=''> septembre 2006 </option>
<option value=''> août 2006 </option>
<option value=''> juillet 2006 </option>
<option value=''> juin 2006 </option>
<option value=''> mai 2006 </option>
<option value=''> avril 2006 </option>
<option value=''> mars 2006 </option>
<option value=''> février 2006 </option>
<option value=''> janvier 2006 </option>
<option value=''> décembre 2005 </option>
</select>
</form>

</td>

</tr>

</table>

<? include("./blocs/pied_page.html"); ?>

</div>

</body>

</html>
