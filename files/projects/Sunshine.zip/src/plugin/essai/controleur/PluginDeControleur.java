package plugin.essai.controleur;

import plugin.ControleurAbstrait;
import plugin.ModeleAbstrait;

/**
 * Exemple d'implementation de l'interface de ControleurAbstrait.
 * @author stephane
 */
public class PluginDeControleur implements ControleurAbstrait {
	/**
	 * Le modele.
	 */
	private ModeleAbstrait modele;
	
	/**
	 * Constructeur par defaut.
	 */
	public PluginDeControleur() {
		super();
	}
	
	/**
	 * Le constructeur avec parametre.
	 * @param modele Le modele.
	 */
	public PluginDeControleur(ModeleAbstrait modele) {
		this.modele = modele;
	}
	
	/**
	 * Permet de controler les donnnees avant de transmettre le calcul au modele.
	 * @param operateur L'operateur du calcul.
	 * @param argument Le(s) argument(s) du calcul.
	 * @see plugin.ControleurAbstrait#controle(java.lang.String, java.lang.String)
	 */
	public void controle(String operateur, String argument) {
		try 
		{
			Integer arg = Integer.parseInt(argument);
			this.modele.setOperateur(operateur);
			this.modele.setArguments(arg);
			this.modele.effectueOperation();
		}
		catch (NumberFormatException e)
		{
			this.modele.setOperateur("");
			this.modele.setArguments(0);
			this.modele.effectueOperation();
		}
	}

	/**
	 * Renvoie le modele.
	 * @return Le modele.
	 * @see plugin.ControleurAbstrait#getModele()
	 */
	public ModeleAbstrait getModele() {
		return this.modele;
	}

	/**
	 * Permet de changer le modele.
	 * @param modele Le modele.
	 * @see plugin.ControleurAbstrait#setModele(plugin.ModeleAbstrait)
	 */
	public void setModele(ModeleAbstrait modele) {
		this.modele = modele;
	}

	/**
	 * Renvoie le nom du plugin.
	 * @return Le nom du plugin.
	 * @see plugin.Plugin#getNom()
	 */
	public String getNom() {
		return "Plugin de controleur";
	}

}
