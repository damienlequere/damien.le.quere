1/ PRÉ-REQUIS 
   
   * PosgreSQL 8.4.2 installé + une base créée
   
2/ INITIALISATION

   a) Importer le repertoire 'formule1-web' dans Eclipse JEE ayant un serveur d'application
   	  Le serveur utilisé pour le développement a été apache-tomcat-5.5.28

   b) Eventuellement recompiler les sources
      > src/client
      	- Formule1Servlet.java
      > src/serveur
      	- ResultServerInterface.java
      > src/common
      	- InsertionDonnees.java
      	- ResultServer.java
      	- ResultServerImpl.java
   
   c) Insertion des données dans la base
      > Lancer 'InsertionDonnees' avec les arguments : nom_bd, proprietaire, mot_de_pass
   
   d) Creer le bouchon pour l'objet distant ResultServer et lancer rmiregistry
      > Dans un terminal : (à partir du repertoire du projet)
           cd build/classes/;
           rmic serveur.ResultServerImpl;
           rmiregistry;
   
   e) Actualiser le projet Eclipse dans le Package Explorer pour bien prendre en compte le stub (F5)
   
3/ LANCEMENT

   a) Lancement du serveur :
      > Lancer dans Eclipse ResultServer avec les arguments : nom_bd, proprietaire, mot_de_pass
   b) Lancement du servlet :
      > Lancer dans Eclipse Formule1Servlet
      > Lancer un navigateur web à l'addresse suivante : 
        "http://localhost:8080/formule1-web/Formule1Servlet"
