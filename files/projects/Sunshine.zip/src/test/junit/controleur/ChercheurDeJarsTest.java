package test.junit.controleur;

import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import controleur.ChercheurDeJars;

/**
 * @author stephane
 *
 */
public class ChercheurDeJarsTest {
	/**
	 * Le chercheur de jar a tester.
	 */
	private ChercheurDeJars chercheurDeJars;
	
	/**
	 * Initialisation du test.
	 * @see junit.framework.TestCase#setUp()
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		this.chercheurDeJars = new ChercheurDeJars();
	}

	/**
	 * Test de la methode getListeJars.
	 */
	@org.testng.annotations.Test(groups="controleur")
	@Test
	public void testGetListeJars() {
		String extensionFichier;
		File fichier;
		
		for(String str : this.chercheurDeJars.getListeJars())
		{
			extensionFichier = str.substring(str.length()-4);
			fichier = new File(str);
			assertTrue("Le fichier n'existe pas", fichier.exists());
			assertTrue("Le fichier est un dossier", fichier.isFile());
			assertTrue("L'extension du fichier n'est pas jar", extensionFichier.equalsIgnoreCase(".jar"));
		}
	}

}
