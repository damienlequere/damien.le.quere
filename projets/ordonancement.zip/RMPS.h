#ifndef RMPS_H_INCLUDED
#define RMPS_H_INCLUDED

#include"ordonnanceur_TP_TA.h"

class RMPS : public Ordonnanceur_TP_TA{

    public:

    RMPS(TacheSimulation *TP_PS){
        _TP_PS = TP_PS;
        };

    TacheSimulation *next_tache(list<TacheSimulation*>* listTachesPeriodiques,list<TacheSimulation*>* listTachesAperiodiques, int t,Gestionnaire_stats &g){
        TacheSimulation *resultat;

        //si le serveur de réveille, on regarde si des tâches apériodiques se sont réveillées
        //si oui on met la capacité de serveur au maximum
        //sinon on "vide" la capacité du serveur
        if( t%(_TP_PS->t.getPi()) == 0 ){
            if(next_TA(listTachesAperiodiques,t) != NULL)
                _TP_PS->ci_restant = _TP_PS->t.getCi();
            else
                _TP_PS->ci_restant = 0;
            }

        //on regarde quelle est la prochaine tâche périodique
        //si la prochaîne tâche périodique est le serveur PS
        //alors la prochaîne tâche sera la prochaîne tâche apériodique
        resultat = RM::next_TP(listTachesPeriodiques,t);
        if (resultat != NULL)
            if(resultat->t.getId() == "PS"){
                if(next_TA(listTachesAperiodiques,t) != NULL){
                    if( (next_TA(listTachesAperiodiques,t)->t.getDi() == 0) &&
                        (next_TA(listTachesAperiodiques,t)->ci_restant == next_TA(listTachesAperiodiques,t)->t.getCi()) )
                        g.ajout_temps_reponse_TAPNC( t - next_TA(listTachesAperiodiques,t)->t.getRi() );
                    next_TA(listTachesAperiodiques,t)->ci_restant--;
                }else{
                    _TP_PS->ci_restant = 0;
                    resultat = NULL;
                    }
                }


        return resultat;
        };

    private:

    TacheSimulation *_TP_PS;


    };

#endif // RMPS_H_INCLUDED
