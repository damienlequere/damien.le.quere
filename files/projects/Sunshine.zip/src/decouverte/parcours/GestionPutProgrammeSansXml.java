package decouverte.parcours;

import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Logger;

import modele.Modele;

import plugin.Programme;
import principal.Sunshine;

/**
 * La classe GestionPutProgrammeSansXml est destinee a extraire les
 * donnees d'un jar afin de reconstituer les objets programmes.
 * Ces donnees sont extraites a partir des interfaces implementees
 * par les classes du jars.
 * @author stephane
 */
public class GestionPutProgrammeSansXml extends GestionnaireDeFichiers {
	/**
	 * Le logger de GestionPutProgrammeSansXml.
	 */
	private static final Logger LOGGER = Logger.getLogger("decouverte.parcours.GestionPutProgrammeSansXml");
	
	/**
	 * Constructeur.
	 * @param jar Le fichier jar charge en memoire.
	 * @param loader Le classe loader du fichier jar en memoire.
	 */
	public GestionPutProgrammeSansXml(File jar, URLClassLoader loader) {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "GestionPutProgrammeSansXml", e);
		}
		
		this.jar = jar;
		this.loader = loader;
	}
	
	/**
	 * Renvoie une map contenant les programmes.
	 * @return Une map contenant les programmes (a caster depuis Object).
	 * @throws ClassNotFoundException Si le classe loader ne trouve pas la classe dans le jar.
	 * @throws IOException Si le jar n'est pas trouve.
	 * @see decouverte.parcours.GestionnaireDeFichiers#getResultats()
	 */
	public Object getResultats() throws ClassNotFoundException, IOException {
		LOGGER.entering(this.getClass().getName(), "getResultats");
		
		String nomFichier = jar.getName().replaceAll(".jar", "");
		Programme programme = new Programme(nomFichier, "1.0");
		Map<String, Programme> map = Modele.getMapProgramme(); 
		
		JarFile jarFile = new JarFile(jar.getAbsolutePath());
		Enumeration<JarEntry> enumeration = jarFile.entries();
		String fichierCourant = "";
		Class<?> tmpClass = null;
		
		while(enumeration.hasMoreElements())
		{
			fichierCourant = enumeration.nextElement().toString();
			// On vérifie que le fichier courant est un .class (et pas un fichier d'informations du jar )
			if(fichierCourant.length() > 6 && fichierCourant.substring(fichierCourant.length()-6).compareTo(".class") == 0)
			{
				fichierCourant = fichierCourant.substring(0, fichierCourant.length()-6);
				fichierCourant = fichierCourant.replaceAll("/", ".");

				tmpClass = Class.forName(fichierCourant, true, loader);

				programme = parseProgramme(programme, tmpClass, fichierCourant, jar);
			}
		}
		
		if(programme.estPret() && (!map.containsKey(nomFichier)))
		{
			map.put(nomFichier, programme);
		}
		
		LOGGER.exiting(this.getClass().getName(), "getResultats", map);
		
		return map;
	}
	
	/**
	 * @param programme Le programme actuel.
	 * @param tmpClass La classe courante.
	 * @param fichierCourant Le fichier courant dans le parcours du jar.
	 * @param jar Le fichier jar.
	 * @return programme On retourne un programme mis a jour.
	 */
	private Programme parseProgramme(Programme programme, Class<?> tmpClass, String fichierCourant, File jar) {
		LOGGER.entering(this.getClass().getName(), "parseProgramme", new Object[] {programme, tmpClass, fichierCourant, jar});
		
		// On verifie la presence d'un controleur, d'une vue et d'un modele 
		for(int i = 0; i < tmpClass.getInterfaces().length; i++) 
		{
			if(tmpClass.getInterfaces()[i].getName().equalsIgnoreCase("plugin.ControleurAbstrait"))
			{
				programme.addControleur(jar.getAbsolutePath(), fichierCourant);
			}
			if(tmpClass.getInterfaces()[i].getName().equalsIgnoreCase("plugin.VueAbstraite"))
			{
				programme.addVue(jar.getAbsolutePath(), fichierCourant);
			}
			if(tmpClass.getInterfaces()[i].getName().equalsIgnoreCase("plugin.ModeleAbstrait"))
			{
				programme.addModele(jar.getAbsolutePath(), fichierCourant);
			}
		}
		
		LOGGER.exiting(this.getClass().getName(), "parseProgramme", programme);
		return programme;
	}
}
