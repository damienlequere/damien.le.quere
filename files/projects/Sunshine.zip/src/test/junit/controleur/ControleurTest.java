package test.junit.controleur;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import test.stub.modele.ModeleStub;

import controleur.Controleur;

/**
 * Classe de test du controleur.
 * @author stephane
 */
public class ControleurTest {
	/**
	 * Le controleur a tester.
	 */
	private Controleur controleur;

	/**
	 * Initialisation du test.
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		this.controleur = new Controleur();
	}
	
	/**
	 * Test de la methode controle.
	 */
	@org.testng.annotations.Test(groups="controleur")
	@Test
	public void testControle() {
		String operateur = "preparer_les_programmes";
		ArrayList<String> args = null;
		Object argument = (ArrayList<String>) args;
		
		ModeleStub modele = new ModeleStub();
		controleur.setModele(modele);
		
		controleur.controle(operateur, argument);
		
		assertEquals("Le modele n'a pas recu le bon operateur", operateur, modele.getOperateur());
		assertNotNull("Le modele n'a pas recu la liste des jars", modele.getArgument());
		
	}
}
