package decouverte.parcours;

import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;

import plugin.ControleurAbstrait;
import plugin.ModeleAbstrait;
import plugin.VueAbstraite;
import principal.Sunshine;

import xml.Controle;
import xml.ControleParSchema;

/**
 * La GestionJarValideAvecXml permet de savoir si un jar est valide
 * dans le cadre d'une verification avec un fichier xml.
 * @author stephane
 */
public class GestionJarValideAvecXml extends GestionnaireDeFichiers {
	/**
	 * Le logger de GestionJarValideAvecXml.
	 */
	private static final Logger LOGGER = Logger.getLogger("decouverte.parcours.GestionJarValideAvecXml");
	
	/**
	 * Methode de controle du fichier Xml.
	 */
	private Controle controle;
	
	/**
	 * Constructeur.
	 * @param jar Le fichier jar charge en memoire.
	 * @param loader Le classe loader du fichier jar en memoire.
	 */
	public GestionJarValideAvecXml(File jar, URLClassLoader loader) {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "GestionJarValideAvecXml", e);
		}
		
		this.jar = jar;
		this.loader = loader;
		this.controle = new ControleParSchema(System.getProperty("user.dir")+"/resources/plugin.xsd");
	}
	
	/**
	 * Renvoie un boolean indiquant si un jar est valide par rapport a un fichier xml.
	 * @return Le boolean indiquant si le jar est valide (a caster depuis Object).
	 * @throws ClassNotFoundException Si le classe loader ne trouve pas la classe dans le jar.
	 * @throws IOException Si le jar n'est pas trouve.
	 * @see decouverte.parcours.GestionnaireDeFichiers#getResultats()
	 */
	public Object getResultats() throws ClassNotFoundException, IOException {
		LOGGER.entering(this.getClass().getName(), "getResultats");
		
		boolean xmlValide = false;
		boolean classesValides = false;
		
        JarFile jarFile = new JarFile(jar.getAbsolutePath());
		Enumeration<JarEntry> enumeration = jarFile.entries();
		String fichierCourant = "";
		
		
		while(enumeration.hasMoreElements())
		{
			fichierCourant = enumeration.nextElement().toString();
			Map<String, LinkedList<String>> map = null;
			
			// Traitement du xml
			if(fichierCourant.length() == 10 && fichierCourant.substring(fichierCourant.length()-10).compareTo("plugin.xml") == 0)
			{
				xmlValide = controle.estValide(fichierCourant, loader);
				LOGGER.log(Level.INFO, "Fichier XML valide : "+xmlValide);
				if(xmlValide)
				{
					map = controle.parametreXml(fichierCourant, loader);
				}
				
				classesValides = classesValides(map, loader);
			}
		}
		
		
		boolean result = (Boolean) (xmlValide && classesValides);
		LOGGER.exiting(this.getClass().getName(), "getResultats", result);
		return result;
	}
	
	/**
	 * Indique si les classes implementent les interfaces qu'elles declarent.
	 * @param map La map contenant les donnees.
	 * @param loader Le classe loader.
	 * @return Un boolean indiquant si les classes sont valides.
	 */
	private boolean classesValides(Map<String, LinkedList<String>> map, URLClassLoader loader) {
		boolean vueOk = false;
		boolean modeleOk = false;
		boolean controleurOk = false;
		
		for(String str : map.keySet())
		{
			LOGGER.log(Level.INFO, "Cle : "+str+" Valeur : "+map.get(str).toString());
			if("modele".equals(str))
			{
				modeleOk = verifModele(map.get(str), loader);
			}
			if("controleur".equals(str))
			{
				controleurOk = verifControleur(map.get(str), loader);
			}
			if("vue".equals(str))
			{
				vueOk = verifVue(map.get(str), loader);
			}
		}
		
		LOGGER.log(Level.INFO, "Vues : "+vueOk+" Controleur : "+controleurOk+" Modele : "+modeleOk);
		
		return (vueOk && modeleOk && controleurOk);
	}
	
	/**
	 * Verifie si les vues annoncees sont conformes.
	 * @param liste La liste des vues annonces.
	 * @param loader La classe loader du jar.
	 * @return Un boolean indiquant si tout est conforme.
	 */
	private boolean verifVue(List<String> liste, URLClassLoader loader) {
		boolean result = true;
		
		try
		{
			for(String str : liste) {
				Class<?> tmpClass = Class.forName(str, true, loader);
				LOGGER.log(Level.INFO, "Classes vues : "+tmpClass.getName());
				if(!VueAbstraite.class.isAssignableFrom(tmpClass))
				{
					result = false;
				}
			}
		}
		catch(Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "verifModele", e);
		}
		return result;
	}
	
	/**
	 * Verifie si le controleur annonce est conforme.
	 * @param liste La liste des controleurs annonces.
	 * @param loader La classe loader du jar.
	 * @return Un boolean indiquant si tout est conforme.
	 */
	private boolean verifControleur(List<String> liste, URLClassLoader loader) {
		boolean result = false;
		
		try
		{
			Class<?> tmpClass = Class.forName(liste.get(0), true, loader);
			
			if(ControleurAbstrait.class.isAssignableFrom(tmpClass))
			{
				result = true;
			}
			
		}
		catch(Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "verifModele", e);
		}
		return result;
	}
	
	/**
	 * Verifie si le modele annonce est conforme.
	 * @param liste La liste des modeles annonces.
	 * @param loader La classe loader du jar.
	 * @return Un boolean indiquant si tout est conforme.
	 */
	private boolean verifModele(List<String> liste, URLClassLoader loader) {
		boolean result = false;
		
		try
		{
			Class<?> tmpClass = Class.forName(liste.get(0), true, loader);
			
			if(ModeleAbstrait.class.isAssignableFrom(tmpClass))
			{
				result = true;
			}
			
		}
		catch(Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "verifModele", e);
		}
		return result;
	}

	/**
	 * Renvoie le controleur de fichier xml.
	 * @return Le controleur de fichier xml.
	 */
	public Controle getControle() {
		LOGGER.entering(this.getClass().getName(), "getControle");
		LOGGER.exiting(this.getClass().getName(), "getControle", controle);
		return controle;
	}

	/**
	 * Permet de changer le mode de controle du fichier xml.
	 * @param controle Mode de controle du fichier xml.
	 */
	public void setControle(Controle controle) {
		LOGGER.entering(this.getClass().getName(), "setControle", controle);
		LOGGER.exiting(this.getClass().getName(), "setControle");
		this.controle = controle;
	}

}
