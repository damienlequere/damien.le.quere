import java.rmi.*;

public interface PersonInterface extends Remote{
	String getFirstName() throws RemoteException;
	String getLastName() throws RemoteException;
}
