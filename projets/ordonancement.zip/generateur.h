#ifndef GENERATEUR_H_INCLUDED
#define GENERATEUR_H_INCLUDED

#define CI_MAX 30       //
#define DI_MAX 30       //
#define RI_MAX 60       //
#define RATIO_MIN 0.05  //
#define PRECISION 1000  //

#include<iostream>
#include<math.h>
#include <time.h>
#include"liste_taches.h"

class Generateur{

    public:

    //generateur de taches
    static ListeTaches *genTaches(string,int,float,int,float);

    //random sur les float entre deux bornes
    static float mon_random(float,float);
    //un booleen aleatoire
    static bool mon_random_bool();
    //arondissement d'un flotant de precision donnee
    static float arrondir(float,int);
    //calcule le pgcd
    static int pgcd(int,int);
    //calcul un rapport c/p aleatoirement et verifiant l'egalite c/p = rapport
    static void calcul_rapport(int &c, int &p, float rapport,float num_max);
    };


#endif // GENERATEUR_H_INCLUDED
