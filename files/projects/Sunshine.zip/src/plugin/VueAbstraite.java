package plugin;

/**
 * L'interface de vue abstraite definie les methodes a implementer par la 
 * partie vue de nos plugins.
 * @author stephane
 */
public interface VueAbstraite extends PluginObserveur {
	/**
	 * Premire methode du sous plugins, permet de lancer le programme.
	 */
	void initialiser();
	
	/**
	 * Permet de changer le controleur.
	 * @param controleur Le controleur.
	 */
	void setControleur(ControleurAbstrait controleur);
	
	/**
	 * Renvoie le controleur.
	 * @return Le controleur.
	 */
	ControleurAbstrait getControleur();
}
