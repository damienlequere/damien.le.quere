<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Encore un quotidien national</title>

<link rel="stylesheet" type="text/css" media="screen" href="./style/ecran.css" />

<script type="text/javascript" src="./resources/jquery.js"></script>          

<script type="text/javascript">
$(document).ready(function() {
   $("#connect").hide();
   $("a#lien_connect").click(function() {
      $("#connect").show();
   });
   $("#titre").click(function () {
         $("#connect").hide();
    });
   $("#champ_recherche").focus(function() {
      $("#champ_recherche").val("");
   });

 });

</script>

</head>

<body>

<div id="page">

<? include("./blocs/titre.html"); ?>

<ul id="menu">

<li><a href="./index.php" title="">Accueil</a></li>
<li><a href="./politique.php" title="">Politique</a></li>
<li><a href="./sport.php" title="">Sport</a></li>
<li><a href="./economie.php" title="">&Eacute;conomie</a></li>
<li><a href="./sante.php" title="">Santé</a></li>

</ul>

<table>

<tr>

<td id="contenu">

<form id="recherche" method="get" action="recherche.php">
<input type="text" value="Rechercher un article" class="texte" id="champ_recherche" name="mots"/>
<input type="submit" value="Rechercher"/>
</form>

<div style="padding:10px;">

<h2 style="margin-top:0;">Clearstream : Villepin réclame la vérité</h2>

<img src="./img/villepin-big.jpg" alt="" />

<p style="margin-top:0;font-family: Arial, Helvetica, 'Liberation Sans', FreeSans, sans-serif;"><span style="color:#888;font-size:small;">Dominique de Villepin, à son arrivée au procès lundi.  Crédits photo : AFP</span></p>

<p><strong>«Je suis ici par l'acharnement d'un homme», a déclaré lundi l'ancien premier ministre, peu avant l'ouverture du procès dans lequel il est soupçonné d'avoir ourdi un complot politique contre Nicolas Sarkozy.</strong></p>

<p>Les autres duels du procès :</p>

<ul><li><a href="">Imad Lahoud contre Jean-Louis Gergorin</a></li>
<li><a href="">Me Olivier Metzner face au procureur Marin</a></li></ul>

<p>Le duel singulier qui oppose Dominique de Villepin et Nicolas Sarkozy captive tellement l'attention qu'ilcontrarie toute volonté d'examiner à froid le dossier Clearstream, d'évaluer la responsabilité potentielle des quatre autres prévenus, le préjudice des quarante autres parties civiles. Le procès a commencé lundi devant le tribunal correctionnel de Paris. Il doit s'achever, en principe, le 23 octobre, sans que nul ne puisse prédire le tour que prendront les débats.</p>

<p>«Je suis ici par la volonté d'un homme, par l'acharnement d'un homme», a déclaré l'ancien premier ministre à son arrivée au tribunal de Paris entouré de sa femme, de ses deux filles et de son fils. «La justice est un bien précieux et est aussi un bien fragile, je sais que la vérité triomphera.»</p>

<p>Les juges d'instruction Jean-Marie d'Huy et Henri Pons ont conclu que, de leur point de vue, l'ancien premier ministre était le chef d'orchestre d'un complot destiné à abattre politiquement celui qui deviendra président de la République. Dès lors, écartant la piste de la «simple» escroquerie au renseignement ourdie par un faussaire opportuniste (en l'occurrence Imad La­houd), ils n'expliquent pas vraiment pourquoi les noms de plusieurs dizaines de personnalités, politiques ou non et totalement étrangères à la rivalité Sarkozy-Villepin, ont été frauduleusement introduits sur les listings. Jean-Louis Gergorin, présenté comme le «corbeau», et Imad Lahoud comme l'artisan faussaire sont, dans ce schéma, des instruments de M. de Villepin. Cette grille de lecture est séduisante d'un point de vue psychologique. Tient-elle la route judiciairement ? C'est au tribunal correctionnel qu'il appartient de répondre.</p>

<h3>Une exaspération intacte</h3>

<p>La détestation entre Nicolas Sarkozy et Dominique de Villepin atteint, par le truchement de la procédure, une intensité inédite pour des rivaux politiques du même camp sous la Ve République. Les confidences du chef de l'État lors de son récent voyage au Brésil («Il est grand temps que toutes ces combines, ces officines sous la Ve  République, on en soit débarrassé une bonne fois pour toutes») témoignent d'une exaspération intacte, impossible à dissimuler.</p>

<p>D'autant que, selon certains protagonistes, Dominique de Villepin se prévalait d'instructions de Jacques Chirac pour diligenter les enquêtes autour des fichiers explosifs. Certes, l'ancien locataire de l'Élysée a fermement démenti toute implication de sa part, et son entourage a fait de même. Mais celui de Nicolas Sarkozy subodore une collusion entre les deux hommes, destinée à ruiner ses chances à la présidentielle de 2007.</p>

<p>En retour, l'offensive médiatique inouïe déclenchée par Dominique de Villepin à deux semaines de l'ouverture des débats - à noter, toutefois, que le procureur de Paris avait tiré le premier contre lui - trahit sa volonté de marquer des points dans l'opinion avant que le tribunal n'ouvre le dossier. Le président de la République est mis en cause, de manière assez cocasse, pour n'avoir pas porté plainte… assez tôt. Le principe même de sa constitution de partie civile est contesté, au prétexte que, bénéficiant d'une immunité totale, le chef de l'État - qui n'en est pourtant pas à son premier procès - ne peut se comporter en plaignant ordinaire.</p>

<p>La victime Sarkozy portera, sans aucun doute, par la voix de son avocat et ami Thierry Herzog, une accusation sans nuance contre le prévenu Villepin. Celui-ci, dé­fendu par Mes Olivier Metzner, Henri Le­clerc, Luc Brossolet et Olivier d'Antin, rétorquera par un système de défense minimaliste, qu'on peut résumer en une phrase : je n'étais au courant de rien.</p>

</div>

</td>

<td id="sidebar">

<form method="post" action="" style="text-align:center;margin-bottom:15px;">

Articles par mois :
<select id="mois" name="mois">
<option value=''> août 2009 </option>
<option value=''> juillet 2009 </option>
<option value=''> juin 2009 </option>
<option value=''> mai 2009 </option>
<option value=''> avril 2009 </option>
<option value=''> mars 2009 </option>
<option value=''> février 2009 </option>
<option value=''> janvier 2009 </option>
<option value=''> décembre 2008 </option>
<option value=''> novembre 2008 </option>
<option value=''> octobre 2008 </option>
<option value=''> septembre 2008 </option>
<option value=''> août 2008 </option>
<option value=''> juillet 2008 </option>
<option value=''> juin 2008 </option>
<option value=''> mai 2008 </option>
<option value=''> avril 2008 </option>
<option value=''> mars 2008 </option>
<option value=''> février 2008 </option>
<option value=''> janvier 2008 </option>
<option value=''> décembre 2007 </option>
<option value=''> novembre 2007 </option>
<option value=''> octobre 2007 </option>
<option value=''> septembre 2007 </option>
<option value=''> août 2007 </option>
<option value=''> juin 2007 </option>
<option value=''> mai 2007 </option>
<option value=''> avril 2007 </option>
<option value=''> mars 2007 </option>
<option value=''> février 2007 </option>
<option value=''> janvier 2007 </option>
<option value=''> septembre 2006 </option>
<option value=''> août 2006 </option>
<option value=''> juillet 2006 </option>
<option value=''> juin 2006 </option>
<option value=''> mai 2006 </option>
<option value=''> avril 2006 </option>
<option value=''> mars 2006 </option>
<option value=''> février 2006 </option>
<option value=''> janvier 2006 </option>
<option value=''> décembre 2005 </option>
</select>
</form>

<div style="border:1px solid #444;height:250px;margin-bottom:10px;background:orange;">
<p style="background:#444;color:#fff;padding:2px 4px;margin:0;font-size:0.7em;font-family: Arial, Helvetica, FreeSans, sans-serif;font-weight:bold;">Publicité</p>
<p style="text-align:center;color:#444;font-weight:bold;font-size:3.2em;margin-top:75px;">PUB</p>
</div>


</td>

</tr>

</table>

<? include("./blocs/pied_page.html"); ?>

</div>

</body>

</html>

