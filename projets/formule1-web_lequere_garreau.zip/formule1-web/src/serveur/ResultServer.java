package serveur;

import java.net.MalformedURLException;
import java.rmi.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultServer {

	 /**
	 * @param args
	 */
	public static void main(String[] args) {
        String	nomBase	= args[0],
        		proprietaire = args[1],
        		passwd = args[2];
        
        Statement stmt = null;
        Connection con;
        
        ResultServerImpl s;
        
		try {
            con = DriverManager.getConnection("jdbc:postgresql:" + nomBase, proprietaire, passwd);
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
        } catch (SQLException e) { e.printStackTrace(); }
		
        try {
        	s = new ResultServerImpl(stmt);
        	Naming.rebind("rmi://localhost:1099/ResultsCourse",s);
        }
        catch (RemoteException e) { e.printStackTrace(); }
        catch (MalformedURLException e) { e.printStackTrace(); }
        
        System.out.println("Serveur Lance...");
	}
}