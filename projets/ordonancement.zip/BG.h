#ifndef BG_H_INCLUDED
#define BG_H_INCLUDED

#include"ordonnanceur_TP_TA.h"

class RMBG : public Ordonnanceur_TP_TA{

    public:

    static TacheSimulation *next_tache(list<TacheSimulation*>* listTachesPeriodiques,list<TacheSimulation*>* listTachesAperiodiques, int t){
        return RM::next_TP(listTachesPeriodiques,t);
    };

};

class EDFBG : public Ordonnanceur_TP_TA{

    public:

    static TacheSimulation *next_tache(list<TacheSimulation*>* listTachesPeriodiques,list<TacheSimulation*>* listTachesAperiodiques, int t){
        return EDF::next_TP(listTachesPeriodiques,t);
    };

};


class BG : public Ordonnanceur_TP_TA{


    public:

    static TacheSimulation *next_tache(string type_ord,list<TacheSimulation*>* listTachesPeriodiques,list<TacheSimulation*>* listTachesAperiodiques, int t,Gestionnaire_stats &g){

        TacheSimulation *resultat = NULL;
        if (type_ord == "RM")
            resultat = RMBG::next_tache(listTachesPeriodiques,listTachesAperiodiques,t);
        if (type_ord == "EDF")
            resultat = EDFBG::next_tache(listTachesPeriodiques,listTachesAperiodiques,t);
        if(resultat == NULL){
            if(next_TA(listTachesAperiodiques,t) != NULL){
                if( (next_TA(listTachesAperiodiques,t)->t.getDi() == 0) &&
                (next_TA(listTachesAperiodiques,t)->ci_restant == next_TA(listTachesAperiodiques,t)->t.getCi()) )
                    g.ajout_temps_reponse_TAPNC( t - next_TA(listTachesAperiodiques,t)->t.getRi() );
                }
            resultat = next_TA(listTachesAperiodiques,t);
            }
        return resultat;
        };


    };

#endif // BG_H_INCLUDED
