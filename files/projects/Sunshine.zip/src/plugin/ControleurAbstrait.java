package plugin;

/**
 * L'interface de controleur abstrait defini les methodes a implementer
 * par la partie controleur d'un plugin.
 * @author stephane
 */
public interface ControleurAbstrait extends Plugin {
	/**
	 * Permet de controler les donnees de l'operation avant de la transmettre au modele.
	 * @param operateur Operateur du calcul.
	 * @param argument Argument(s) du calcul.
	 */
	void controle(String operateur, String argument);
	
	/**
	 * Permet de changer de modele.
	 * @param modele Le modele.
	 */
	void setModele(ModeleAbstrait modele);
	
	/**
	 * Renvoie le modele.
	 * @return Le modele.
	 */
	ModeleAbstrait getModele();
}
