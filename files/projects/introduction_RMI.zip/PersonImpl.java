import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;


public class PersonImpl extends UnicastRemoteObject implements PersonInterface{
	
	public String first_name;
	public String last_name;
	public PersonImpl(String fn,String ln)throws RemoteException{
		first_name = fn;
		last_name = ln;
	}
	
	public PersonImpl () throws RemoteException{
		super();
	}
	public String getFirstName() throws RemoteException{
		return first_name;
	}
	
	public String getLastName() throws RemoteException{
		return last_name;
	}
}
