package decouverte.parcours;

import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;

import principal.Sunshine;

/**
 * La GestionJarValideSansXml permet de determiner si un jar est
 * valide dans le cadre d'une verification sans fichier xml.
 * @author stephane
 */
public class GestionJarValideSansXml extends GestionnaireDeFichiers {
	/**
	 * Le logger de GestionJarValideSansXml.
	 */
	private static final Logger LOGGER = Logger.getLogger("decouverte.parcours.GestionJarValideSansXml");
	
	/**
	 * Constructeur par defaut.
	 */
	public GestionJarValideSansXml() {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "GestionJarValideSansXml", e);
		}
	}
	
	/**
	 * Constructeur.
	 * @param jar Le fichier jar charge en memoire.
	 * @param loader Le classe loader du fichier jar en memoire.
	 */
	public GestionJarValideSansXml(File jar, URLClassLoader loader) {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "GestionJarValideSansXml", e);
		}
		
		this.jar = jar;
		this.loader = loader;
	}
	
	/**
	 * Renvoie un boolean indiquant si un jar est valide.
	 * @return Le boolean indiquant si le jar est valide (a caster depuis Object).
	 * @throws ClassNotFoundException Si le classe loader ne trouve pas la classe dans le jar.
	 * @throws IOException Si le jar n'est pas trouve.
	 * @see decouverte.parcours.GestionnaireDeFichiers#getResultats()
	 */
	public Object getResultats() throws ClassNotFoundException, IOException {
		LOGGER.entering(this.getClass().getName(), "getResultats");
		
		boolean controleur = false;
        boolean modele = false;
        boolean vue = false;
		
        JarFile jarFile = new JarFile(jar.getAbsolutePath());
		Enumeration<JarEntry> enumeration = jarFile.entries();
		String fichierCourant = "";
		Class<?> tmpClass = null;
		
		while(enumeration.hasMoreElements())
		{
			fichierCourant = enumeration.nextElement().toString();
			// On vérifie que le fichier courant est un .class (et pas un fichier d'informations du jar )
			if(fichierCourant.length() > 6 && fichierCourant.substring(fichierCourant.length()-6).compareTo(".class") == 0)
			{
				fichierCourant = fichierCourant.substring(0, fichierCourant.length()-6);
				fichierCourant = fichierCourant.replaceAll("/", ".");
				LOGGER.log(Level.INFO, "Fichier courant : "+fichierCourant+" fichier jar : "+jar.getAbsolutePath());
				tmpClass = Class.forName(fichierCourant, true, loader);

				// On verifie la presence d'un controleur, d'une vue et d'un modele 
				for(int i = 0; i < tmpClass.getInterfaces().length; i++) 
				{
					if(tmpClass.getInterfaces()[i].getName().equalsIgnoreCase("plugin.ControleurAbstrait"))
					{
						controleur = true;
					}
					if(tmpClass.getInterfaces()[i].getName().equalsIgnoreCase("plugin.VueAbstraite"))
					{
						vue = true;
					}
					if(tmpClass.getInterfaces()[i].getName().equalsIgnoreCase("plugin.ModeleAbstrait"))
					{
						modele = true;
					}
				}
			}
		}
		
		boolean result = (Boolean) (modele && vue && controleur);
		LOGGER.exiting(this.getClass().getName(), "getResultats", result);
		
		return result;
	}
}
