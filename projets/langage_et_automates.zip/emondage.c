#include "emondage.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* SUPPRESSION_DES_ETATS_TRIVIALEMENT_INUTILES : 
* 
***********************************************************************/
void suppression_des_etats_trivialement_inutiles(struct Liste_chaine ** liste_a_redefinir, struct Liste_chaine * liste_modele)
{
   struct Liste_chaine * liste =*liste_a_redefinir;
   struct Liste_chaine * liste_aux = liste->chaine_suivante;
   while (liste_aux !=NULL){
      if (!est_mot_de_la_liste(liste_modele, liste_aux->chaine)){
         struct Liste_chaine * a_virer = liste_aux;
         liste->chaine_suivante = liste_aux->chaine_suivante;
         free(a_virer);
      } else {
         liste = liste_aux;
      }
      liste_aux= liste->chaine_suivante;
   }
   if(!est_mot_de_la_liste(liste_modele, (*liste_a_redefinir)->chaine)){
      struct Liste_chaine * a_virer=*liste_a_redefinir;
      *liste_a_redefinir = (*liste_a_redefinir)->chaine_suivante;
      free(a_virer);
   }
}


/* AJOUTER_ETATS_ACCESSIBLES : 
* 
***********************************************************************/
void ajouter_etats_accessibles(char * etat, struct Liste_regle * liste_des_regles, struct Liste_chaine ** etats_accessibles)
{
   struct Regle r;
   struct Liste_regle * lr_aux = liste_des_regles;
   int comp;
   while (lr_aux!=NULL){
      r = lr_aux->la_regle;
      comp = strcmp(r.etat_depart,etat);
      if(comp==0){
         if(!est_mot_de_la_liste(*etats_accessibles, r.etat_arrive)){
            ajout_liste_en_tete(r.etat_arrive,etats_accessibles);
            ajouter_etats_accessibles(r.etat_arrive,liste_des_regles,etats_accessibles);
         }
      }
      lr_aux=lr_aux->regle_suivante;
   }
}


/* AJOUTER_ETATS_COACCESSIBLES : 
* 
***********************************************************************/
void ajouter_etats_coaccessibles(char * etat, struct Liste_regle * liste_des_regles, struct Liste_chaine ** etats_coaccessibles)
{
   struct Regle r;
   struct Liste_regle * lr_aux = liste_des_regles;
   int comp;
   while (lr_aux!=NULL){
      r = lr_aux->la_regle;
      comp = strcmp(r.etat_arrive,etat);
      if(comp==0){
         if(!est_mot_de_la_liste(*etats_coaccessibles, r.etat_depart)){
              ajout_liste_en_tete(r.etat_depart,etats_coaccessibles);
            ajouter_etats_coaccessibles(r.etat_depart,liste_des_regles,etats_coaccessibles);
         }
      }
      lr_aux=lr_aux->regle_suivante;
   }
}


/* INTERSECTION_DE_LISTES : 
* 
***********************************************************************/
void intersection_de_listes(struct Liste_chaine ** liste_resultat, struct Liste_chaine * listeA, struct Liste_chaine * listeB)
{
   int comp;
   while (listeA!=NULL){
      if(est_mot_de_la_liste(listeB, listeA->chaine)){
            ajout_liste_en_tete(listeA->chaine,liste_resultat);
      }
      listeA=listeA->chaine_suivante;
   }
}


/* SUPPRIME_REGLES_INUTILES : 
* 
***********************************************************************/
void supprime_regles_inutiles(struct Liste_chaine * liste_etats_utiles, struct Liste_regle ** liste_des_regles)
{
   if(*liste_des_regles!=NULL){
      struct Regle r;
      struct Liste_regle * liste=*liste_des_regles;
      struct Liste_regle * liste_aux=(*liste_des_regles)->regle_suivante;
      while(liste_aux!=NULL){
         r = liste_aux->la_regle;
         if(!est_mot_de_la_liste(liste_etats_utiles,r.etat_arrive) || !est_mot_de_la_liste(liste_etats_utiles,r.etat_depart)){
            struct Liste_regle * a_virer=liste_aux;
            liste->regle_suivante = liste_aux->regle_suivante;
            free(a_virer);
         } else {
            liste = liste_aux;
         }
         liste_aux=liste->regle_suivante;
      }
      r = (*liste_des_regles)->la_regle;
      if(!est_mot_de_la_liste(liste_etats_utiles,r.etat_arrive) || !est_mot_de_la_liste(liste_etats_utiles,r.etat_depart)){
            struct Liste_regle * a_virer=*liste_des_regles;
           *liste_des_regles = (*liste_des_regles)->regle_suivante;
           free(a_virer);
      }
   }
}


/* EMONDAGE : 
* 
***********************************************************************/
void emondage(struct Liste_regle ** liste_des_regles,
              struct Liste_chaine ** liste_etats_initiaux,
              struct Liste_chaine ** liste_etats_finaux,
              struct Liste_chaine ** liste_etats_utiles)
{
   struct Liste_chaine * etats_accessibles = NULL;
   struct Liste_chaine * etats_coaccessibles = NULL;
   // On supprime tous les états initiaux et finaux qui n'apparaissent dans aucune règle
   suppression_des_etats_trivialement_inutiles(liste_etats_initiaux, *liste_etats_utiles);
   suppression_des_etats_trivialement_inutiles(liste_etats_finaux, *liste_etats_utiles);
   // D'emblé tous les états initiaux sont accessibles :
   etats_accessibles=*liste_etats_initiaux;
   
   // De même tous les états finaux sont coaccessibles :
   etats_coaccessibles=*liste_etats_finaux;

   // On regarde quels états sont accessibles depuis les états initiaux:
   struct Liste_chaine * liste_aux = *liste_etats_initiaux;
   while (liste_aux!=NULL){
      ajouter_etats_accessibles(liste_aux->chaine,*liste_des_regles,&etats_accessibles);
      liste_aux = liste_aux->chaine_suivante;
   }
   // On regarde quels états ont accès aux états finaux:
   liste_aux = *liste_etats_finaux;
   while (liste_aux!=NULL){
      ajouter_etats_coaccessibles(liste_aux->chaine,*liste_des_regles,&etats_coaccessibles);
      liste_aux = liste_aux->chaine_suivante;
   }
   // Il suffit maintenant de faire l'intersection des 2 listes pour trouver la liste des états utiles
   *liste_etats_utiles = NULL;
   intersection_de_listes(liste_etats_utiles,etats_accessibles,etats_coaccessibles);
   // On supprime des règles toutes les transitions qui possède au moins un état inutile
   supprime_regles_inutiles(*liste_etats_utiles,liste_des_regles);
}
