package modele;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import decouverte.Decouverte;

import observeur.Observable;
import observeur.Observeur;
import plugin.Programme;
import principal.Sunshine;

/**
 * Cette classe va contenir la structure de donnees des programmes.
 * Dans le cadre d'une extension de ce logiciel, c'est cette classe
 * que l'on interrogera pour appliquer des traitements plus complexe
 * sur les programmes.
 * @author stephane
 */
public class Modele implements Observable {
	/**
	 * Le logger de Modele.
	 */
	private static final Logger LOGGER = Logger.getLogger("modele.Modele");
	
	/**
	 * L'operateur du calcul.
	 */
	private String operateur;
	
	/**
	 * Les arguments du calcul.
	 */
	private Object argument;
	
	/**
	 * La liste des observeurs.
	 */
	private final List<Observeur> listeObserveurs;
	
	/**
	 * La map des programmes.
	 */
	private static Map<String, Programme> mapProgramme = new HashMap<String, Programme>();
	
	/**
	 * Constructeur par defaut.
	 */
	public Modele() {
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "Modele", e);
		}
		
		this.listeObserveurs = new ArrayList<Observeur>();
	}
	
	/**
	 * Permet de changer l'operateur du calcul en cour.
	 * @param operateur Operateur du calcul.
	 */
	public void setOperateur(String operateur) {
		this.operateur = operateur;
	}
	
	/**
	 * Permet de changer le(s) argument(s) du calcul.
	 * @param argument Le(s) argument(s) du calcul.
	 */
	public void setArgument(Object argument) {
		this.argument = argument;
	}
	
	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void effectueOperation() {
		LOGGER.entering(this.getClass().getName(), "efectueOperation");
		if(operateur.equalsIgnoreCase("preparer_les_programmes"))
		{
			List<Object> liste = (ArrayList<Object>) argument;
			List<String> listeJar = (ArrayList<String>) liste.get(0);
			Decouverte decouverte = (Decouverte) liste.get(1);
			
			for(String str : listeJar)
			{
				mapProgramme = decouverte.putProgramme(str, mapProgramme);
			}
			
			this.notifyObserveur(mapProgramme);
		}
		LOGGER.exiting(this.getClass().getName(), "effectueOperation");
	}
	
	/**
	 * Permet d'ajouter un observeur sur le modele.
	 * @param o L'observeur a ajouter.
	 * @see observeur.Observable#addObserveur(observeur.Observeur)
	 */
	public void addObserveur(Observeur o) {
		this.listeObserveurs.add(o);
	}

	/**
	 * Permet de prevenir les observeurs d'un evenement.
	 * @param o Les donnees transmises par le modele aux observeurs.
	 * @see observeur.Observable#notifyObserveur(java.lang.Object)
	 */
	public void notifyObserveur(Object o) {
		for(Observeur obs : this.listeObserveurs)
		{
			obs.update(o);
		}
	}
	
	/**
	 * Permet de supprimer un observeur.
	 * @param o L'observeur a supprimer.
	 * @see observeur.Observable#removeObserveur(observeur.Observeur)
	 */
	public void removeObserveur(Observeur o) {
		this.listeObserveurs.remove(o);
	}

	/**
	 * Retourne la map des programmes.
	 * @return La map des programmes.
	 */
	public static Map<String, Programme> getMapProgramme() {
		return mapProgramme;
	}
}
