package test.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import test.junit.controleur.ChercheurDeJarsTest;
import test.junit.controleur.ControleurReTest;
import test.junit.controleur.ControleurTest;
import test.junit.decouverte.DecouverteAvecFichierXmlTest;
import test.junit.decouverte.DecouverteSansFichierXmlTest;
import test.junit.decouverte.parcours.GestionJarValideAvecXmlTest;
import test.junit.decouverte.parcours.GestionJarValideSansXmlTest;
import test.junit.decouverte.parcours.GestionPutProgrammeAvecXmlTest;
import test.junit.decouverte.parcours.GestionPutProgrammeSansXmlTest;
import test.junit.decouverte.parcours.ParcoureurDeJarTest;
import test.junit.modele.ModeleReTest;
import test.junit.modele.ModeleTest;
import test.junit.plugin.ProgrammeTest;
import test.junit.vue.FenetreTest;
import test.junit.xml.ControleParSchemaTest;

/**
 * @author stephane
 *
 */
@RunWith(Suite.class)
@SuiteClasses(value={ProgrammeTest.class, ControleParSchemaTest.class, GestionJarValideSansXmlTest.class,
		GestionPutProgrammeSansXmlTest.class, GestionJarValideAvecXmlTest.class, GestionPutProgrammeAvecXmlTest.class,
		ParcoureurDeJarTest.class, DecouverteSansFichierXmlTest.class, DecouverteAvecFichierXmlTest.class,
		ChercheurDeJarsTest.class, ControleurTest.class, ModeleTest.class, FenetreTest.class, ModeleReTest.class, 
		ControleurReTest.class})
public final class TestSequentiel {
	/**
	 * The constructor.
	 */
	protected TestSequentiel() {
		super();
	}
}
