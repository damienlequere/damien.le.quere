<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Vector" %>
<% 
Vector<String> ligneTablePilote = (Vector<String>) request.getAttribute("ligneTablePilote");
String nomP = (String) request.getAttribute("nomP"); 
Integer numP = (Integer) request.getAttribute("numP");
Float moyenne = (Float) request.getAttribute("moyenne");
%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<style>
body{font-family: Arial, Helvetica, "Liberation Sans", FreeSans, sans-serif;font-size:0.9em;}
table, td, th{border:1px solid #444;}
table:hover{cursor:default;}
table{border-collapse:collapse;}
td{padding:0 0.5em;}
th{background:#444;padding:0.1em 0.5em;color:white;font-weight:normal;}
tr:hover{background:#ddd;}
a{color:#2777BC;}
a:hover{color:#1D588C;}
</style>

<title>Résultats de <%= nomP %> (n°<%= numP %>)</title>

</head>

<body>

<h1>Résultats de <%= nomP %> (n°<%= numP %>)</h1>

<table>
<tr><th>Tour</th><th>Position</th><th>Temps/Tour</th><th>Temps total</th></tr>
<% for (String resTour : ligneTablePilote) out.println(resTour);%></table>

<p><strong>Temps moyen au tour : <%= moyenne %></strong></p>

<p><a href="http://localhost:8080/formule1-web/Formule1Servlet" title="">Retour aux résultats généraux</a></p>

</body>

</html>