#ifndef RM_H_INCLUDED
#define RM_H_INCLUDED

#include"ordonnanceur_TP.h"

class RM : public Ordonnanceur_TP{

    public:
    static TacheSimulation *next_TP(list<TacheSimulation*>* listTachesPeriodiques, int t){
        TacheSimulation *resultat = NULL;
        list<TacheSimulation*>::iterator it;
        for(it = listTachesPeriodiques->begin(); it != listTachesPeriodiques->end(); it++){
            if ( (*it)->ci_restant != 0 ){
                if ( resultat == NULL )
                    resultat = *it;
                else{
                    if( (*it)->t.getPi() < resultat->t.getPi() )
                        resultat = *it;
                    if( (*it)->t.getPi() == resultat->t.getPi() )
                        if(derniere_date_reveil((*it)->t,t) < derniere_date_reveil(resultat->t,t))
                            resultat = *it;
                    }
                }
            }
        return resultat;
        };


    };
#endif // RM_H_INCLUDED
