package controleur;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import principal.Sunshine;

import decouverte.Decouverte;
import decouverte.DecouverteAvecFichierXml;

/**
 * Cette classe permet de trouver la liste des fichiers jars valides.
 * Pour cela, on utilise la methode recursive ajoutJarsValides.
 * Cette methode va faire appel a une decouverte afin de trouver les jars
 * repondant a certains criteres.
 * @author stephane
 */
public class ChercheurDeJars {
	/**
	 * Le logger de ChercheurDeJars.
	 */
	private static final Logger LOGGER = Logger.getLogger("controleur.ChercheurDeJars");
	
	/**
	 * Permet de choisir le mode de validation d'un fichier jar (avec/sans xml).
	 */
	private Decouverte decouverte;
	/**
	 * Liste des jars.
	 */
	private final List<String> listeJars;
	
	/**
	 * Constructeur par defaut.
	 */
	public ChercheurDeJars() {
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "ChercheurDeJars", e);
		}
		
		this.listeJars = new ArrayList<String>();
		this.decouverte = new DecouverteAvecFichierXml();
	}
	
	/**
	 * Fourni la liste des jar dans les repertoires de recherche.
	 * @return liste des jars.
	 */
	public List<String> getListeJars() {
		LOGGER.entering(this.getClass().getName(), "getListeJars");
		for(String str : this.decouverte.getRepertoiresDeRecherche())
		{
			this.ajoutJarsValides(new File(str));
		}
		LOGGER.exiting(this.getClass().getName(), "getListeJars", this.listeJars);
		return this.listeJars;
	}
	
	/**
	 * Permet de changer le mode de decouverte des jars.
	 * @param decouverte Le mode de decouverte des jars.
	 */
	public void setDecouverte(Decouverte decouverte) {
		LOGGER.entering(this.getClass().getName(), "setDecouverte", decouverte);
		LOGGER.exiting(this.getClass().getName(), "setDecouverte");
		this.decouverte = decouverte;
	}
	
	/**
	 * Renvoie le mode de decouverte des jars.
	 * @return le mode de deouverte des jars.
	 */
	public Decouverte getDecouverte() {
		LOGGER.entering(this.getClass().getName(), "getDecouverte");
		LOGGER.exiting(this.getClass().getName(), "getDecouverte", decouverte);
		return this.decouverte;
	}
	
	/**
	 * Cherche tous les jars valides dans le repertoire passe en parametre.
	 * La liste des jars valide est stockee dans l'attribut "listeJars".
	 * @param fichier le repertoire ou l'on doit chercher les jars.
	 */
	private void ajoutJarsValides(File fichier) {
		LOGGER.entering(this.getClass().getName(), "ajoutJarsValides", fichier);
		if(fichier.isDirectory())
		{
			File[] list = fichier.listFiles();
			if (list != null)
			{
				for(int i = 0; i < list.length; i++)
				{
					// Appel récursif sur les sous-répertoires
					ajoutJarsValides(list[i]);
				} 
			}
		}
		else
		{
			if(fichier.isFile())
			{
				StringTokenizer str = new StringTokenizer(fichier.getName(), ".");
				String extenFic = "";
				
				while(str.hasMoreTokens())
				{
					extenFic = str.nextToken();
				}
				
				
				if((extenFic.equalsIgnoreCase("jar")) && (this.decouverte.estJarValide(fichier.getAbsolutePath())))
				{
					LOGGER.log(Level.INFO, "Jar trouve : "+fichier.getAbsolutePath());
					listeJars.add(fichier.getAbsolutePath());
				}
			}
		}
		LOGGER.exiting(this.getClass().getName(), "ajoutJarsValides");
	}
}
