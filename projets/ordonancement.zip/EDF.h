#ifndef EDF_H_INCLUDED
#define EDF_H_INCLUDED

#include"ordonnanceur_TP.h"

class EDF : public Ordonnanceur_TP{

    public:

    static TacheSimulation *next_TP(list<TacheSimulation*>* listTacheSimulation, int t){
        TacheSimulation *resultat = NULL;
        list<TacheSimulation*>::iterator it;
        for(it = listTacheSimulation->begin(); it != listTacheSimulation->end(); it++){
            if ( (*it)->ci_restant != 0 ){
                if ( resultat == NULL )
                    resultat = *it;
                else{
                    if( temps_restant((*it)->t,t) < temps_restant(resultat->t,t) )
                        resultat = *it;
                    if( temps_restant((*it)->t,t) == temps_restant(resultat->t,t) )
                        if(derniere_date_reveil((*it)->t,t) < derniere_date_reveil(resultat->t,t))
                            resultat = *it;
                    }
                }
            }
        return resultat;
        };

    };

#endif // EDF_H_INCLUDED
