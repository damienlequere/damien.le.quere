package plugin.essai.vue;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

import plugin.ControleurAbstrait;
import plugin.VueAbstraite;

/**
 * Autre exemple d'implementation de l'interface de Vueabstraite.
 * @author stephane
 */
@SuppressWarnings("serial")
public class PluginDeVueAnnexe extends JFrame implements VueAbstraite {
	/**
	 * Le resultat a afficher.
	 */
	private int resultat = 0;
	
	/**
	 * Panel du resultat.
	 */
	private final JPanel panneauResultat = new JPanel() {
		public void paintComponent(Graphics g) {
			this.setBackground(new Color(128, 129, 135));
			g.setColor(new Color(128, 129, 135));
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			Font font = new Font("Arial", Font.BOLD, 40);
			g.setColor(new Color(0, 0, 0));
			g.setFont(font);
			g.drawString(String.valueOf(resultat), 190, 60);
		}
	};
	
	/**
	 * Le controleur.
	 */
	private ControleurAbstrait controleur;
	
	/**
	 * Constructeur par defaut.
	 */
	public PluginDeVueAnnexe() {
		super();
		this.initialiseInterface();
	}
	
	/**
	 * Constructeur avec parametre.
	 * @param controleur Le controleur que l'on desire.
	 */
	public PluginDeVueAnnexe(ControleurAbstrait controleur) {
		super();
		this.initialiseInterface();
		this.controleur = controleur;
	}
	
	/**
	 * Initialise l'interface graphique.
	 */
	private void initialiseInterface() {
		this.setSize(400, 100);
		this.setTitle("Vue Annexe");
		this.setContentPane(this.panneauResultat);
	}
	
	/**
	 * Renvoie le controleur.
	 * @return Le controleur.
	 * @see plugin.VueAbstraite#getControleur()
	 */
	public ControleurAbstrait getControleur() {
		return this.controleur;
	}

	/**
	 * Initialise le programme.
	 * @see plugin.VueAbstraite#initialiser()
	 */
	public void initialiser() {
		this.setVisible(true);
	}

	/**
	 * Permet de changer le controleur.
	 * @param controleur Le controleur.
	 * @see plugin.VueAbstraite#setControleur(plugin.ControleurAbstrait)
	 */
	public void setControleur(ControleurAbstrait controleur) {
		this.controleur = controleur;
	}

	/**
	 * Met a jour les donnees recu depuis l'observable.
	 * @param o Donnees recu depuis l'observable.
	 * @see plugin.PluginObserveur#update(java.lang.Object)
	 */
	public void update(Object o) {
		resultat = (Integer) o;
		this.panneauResultat.repaint();
	}

	/**
	 * Renvoie le nom du plugin.
	 * @return Nom du plugin.
	 * @see plugin.Plugin#getNom()
	 */
	public String getNom() {
		return "Plugin de vue";
	}

}
