package xml;

import java.io.File;
import java.net.URLClassLoader;
import java.util.logging.Logger;

import principal.Sunshine;

/**
 * Cette classe, consideree comme depreciee est la pour montrer une 
 * autre maniere de valider un fichier xml. Malheureusement des 
 * difficultees techniques ont rendues difficilement implementable
 * la controle par DTD d'un fichier xml avec une DTD externe et non 
 * declaree dans le fichier xml.
 * @author stephane
 */
public class ControleParDtd extends Controle {
	/**
	 * Le logger de Sunshine.
	 */
	private static final Logger LOGGER = Logger.getLogger("xml.ControleParDtd");
	
	/**
	 * L'adresse de la dtd.
	 */
	private String adresse;
	
	/**
	 * Constructeur qui prend en parametre l'adresse du fichier de dtd.
	 * @param adresse L'adresse de la dtd.
	 */
	public ControleParDtd(String adresse) {
		super();
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "ControleParDTD", e);
		}
		
		this.adresse = adresse;
	}

	/**
	 * Renvoie un boolean indiquant si un fichier xml est valide.
	 * @param fichierXml Le fichier xml.
	 * @param loader Le classe loader du jar ou aller chercher le xml.
	 * @return Un boolean indiquant si le fichier xml est valide.
	 * @see xml.Controle#estValide(java.lang.String, java.net.URLClassLoader)
	 */
	@Override
	public boolean estValide(String fichierXml, URLClassLoader loader) {
		LOGGER.entering(this.getClass().getName(), "estValide", new Object[] {fichierXml, loader});
		
		// Extraire le fichier xml, le modifier pour inserer un doctype avec la dtd puis controler la dtd.
		
		boolean reussi=false;
		if(loader == null || !new File(fichierXml).exists())
		{
			reussi =  false;
		}
		else
		{
			try {
				// Construction d'un fichier xml avec reference vers une DTD
				/*File fInput = new File(fichierXml);
				Scanner sc = new Scanner(fInput);
				FileWriter fOutput = new FileWriter("test");
				String uneLigne = sc.nextLine();
				
				fOutput.write(uneLigne);
				fOutput.write("\n<!DOCTYPE plugin SYSTEM \"" + adresse + "\">");
				
				while (sc.hasNextLine()) {
					uneLigne = sc.nextLine();
					fOutput.write(uneLigne+'\n');
				}
				fOutput.close();
				
				// Validation
				DocumentBuilderFactory fabrique = DocumentBuilderFactory.newInstance();
				fabrique.setValidating(true);
				DocumentBuilder constructeur = fabrique.newDocumentBuilder();
				constructeur.parse(new File("test"));
				
				// TEST
				sc = new Scanner(new File("test"));
				while (sc.hasNextLine()) {
					System.out.println(sc.nextLine());
				}*/
				reussi=true;

			}
			catch (Exception e)
			{
				LOGGER.throwing(this.getClass().getName(), "estValide", e);
			}
			
			LOGGER.exiting(this.getClass().getName(), "estValide", reussi);
			
		}
		return reussi;		
	}

	/**
	 * Renvoie l'adresse de la dtd.
	 * @return L'adresse de la dtd.
	 */
	public String getAdresse() {
		LOGGER.entering(this.getClass().getName(), "getAdresse");
		LOGGER.exiting(this.getClass().getName(), "getAdresse", adresse);
		return adresse;
	}

	/**
	 * Permet de changer l'adresse de la dtd.
	 * @param adresse La nouvelle adresse de la dtd.
	 */
	public void setAdresse(String adresse) {
		LOGGER.entering(this.getClass().getName(), "setadresse", adresse);
		LOGGER.exiting(this.getClass().getName(), "setAdresse");
		this.adresse = adresse;
	}

}
