// inclusion des librairies necessaires
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>

#define FIFO_SIZE 1

int main(int argc,char **argv)
{
   // fichier d'entree a retaper par l'utilisateur
   FILE * fichier_e;

   // caractere marquant la fin de fichier dans la FIFO	
   char fin_fichier = '~';

   // FIFOS temps reel
   int  fifo_n0 = 0;

   // ouverture des FIFOS temps reel
   if( (fifo_n0 = open("/dev/rtf0",O_WRONLY)) <0){
      fprintf(stderr,"erreur pour l'ouverture de /dev/rtf0\n",fifo_n0);
      exit(1);
   }

   // ouverture du fichier d'entree en lecture
   if( (fichier_e = fopen(argv[1],"r+")) == NULL )
      printf("\"%s\" : fichier introuvable\n",argv[1]);
   else{
       // caractere utilise pour recopie
      char caractere_courant;

      // recopie du fichier dans la FIFO n�0 caractere par caractere
      while(!feof(fichier_e)){
         fscanf(fichier_e,"%c",&caractere_courant);
         write(fifo_n0,&caractere_courant,FIFO_SIZE);
      }

      // envoi sur la FIFO n�0 du caractere special signalant la fin du fichier
      write(fifo_n0,&fin_fichier,FIFO_SIZE);

      // notification dans la FIFO n�1 de la fin de lecture du fichier
      write(fifo_n1,&fin_fichier,FIFO_SIZE);

      fclose(fichier_e);
   }

   close(fifo_n0);
   close(fifo_n1);

   /* on attend pour que l'utilisateur puisse tapper le texte
    * il devra quitter avec ^C */
   while(1){}

   /* Ici quand on intercept un ^C, on lance l'appel system :
   *  system("rm modulertai"); */

   return 0;
}

