package decouverte.parcours;

import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;

import modele.Modele;

import plugin.Programme;
import principal.Sunshine;
import xml.Controle;
import xml.ControleParSchema;

/**
 * @author stephane
 *
 */
public class GestionPutProgrammeAvecXml extends GestionnaireDeFichiers {
	/**
	 * Le logger de GestionPutProgrammeAvecXml.
	 */
	private static final Logger LOGGER = Logger.getLogger("decouverte.parcours.GestionPutProgrammeAvecXml");
	
	/**
	 * Methode de controle du fichier Xml.
	 */
	private final Controle controle;
	
	/**
	 * Constructeur.
	 * @param jar Le fichier jar charge en memoire.
	 * @param loader Le classe loader du fichier jar en memoire.
	 */
	public GestionPutProgrammeAvecXml(File jar, URLClassLoader loader) {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "GestionPutProgrammeAvecXml", e);
		}
		
		this.jar = jar;
		this.loader = loader;
		this.controle = new ControleParSchema(System.getProperty("user.dir")+"/resources/plugin.xsd");
	}
	
	/**
	 * Renvoie une map contenant les programmes.
	 * @return Une map contenant les programmes (a caster depuis Object).
	 * @throws ClassNotFoundException Si le classe loader ne trouve pas la classe dans le jar.
	 * @throws IOException Si le jar n'est pas trouve.
	 * @see decouverte.parcours.GestionnaireDeFichiers#getResultats()
	 */
	public Object getResultats() throws ClassNotFoundException, IOException {
		LOGGER.entering(this.getClass().getName(), "getResultats");
		
		String nomFichier = jar.getName().replaceAll(".jar", "");
		Map<String, Programme> map = Modele.getMapProgramme(); 
		
		JarFile jarFile = new JarFile(jar.getAbsolutePath());
		Enumeration<JarEntry> enumeration = jarFile.entries();
		String fichierCourant = "";
		
		Map<String, LinkedList<String>> mapParametre = null;
		
		while(enumeration.hasMoreElements())
		{
			fichierCourant = enumeration.nextElement().toString();
			
			// Recuperation du xml
			if(fichierCourant.length() == 10 && fichierCourant.substring(fichierCourant.length()-10).compareTo("plugin.xml") == 0)
			{
				LOGGER.log(Level.INFO, "Fichier courant : "+fichierCourant);
				mapParametre = controle.parametreXml(fichierCourant, loader);
			}
		}
		
		String nom = mapParametre.get("programme").get(0);
		String version = mapParametre.get("version").get(0);
		Programme programme = new Programme(nom, version);
		
		String nomClasse = mapParametre.get("controleur").get(0);
		programme.addControleur(this.jar.getAbsolutePath(), nomClasse);
		
		nomClasse = mapParametre.get("modele").get(0);
		programme.addModele(this.jar.getAbsolutePath(), nomClasse);
		
		for(String string : mapParametre.get("vue"))
		{
			programme.addVue(this.jar.getAbsolutePath(), string);
		}
		
		LOGGER.log(Level.INFO, "Programme est pret : "+programme.estPret());
		if(programme.estPret() && (!map.containsKey(nom)))
		{
			map.put(nomFichier, programme);
		}
		
		LOGGER.exiting(this.getClass().getName(), "getResultats", map);
		return map;
	}

}
