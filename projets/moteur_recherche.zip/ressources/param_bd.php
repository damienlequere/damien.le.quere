<?

   // PARAMÈTRES DE CONNEXION À LA BASE DE DONNÉES
   $hote = "localhost";
   $admin = "root";
   $mot_de_pass = "dadouda";
   $bd_moteur = "moteur_recherche";
   
   // RÉPERTOIRE CONTENANT LES DOCUMENTS À INDEXER PAR DÉFAUT
   $documents = "./docs/";
   
   function affiche_caracteristiques(){
      // CONNEXION À LA BASE DE DONNÉES
      $id_cx = mysql_connect("localhost","root","dadouda") or die ("<p style=\"color:red;\">Erreur de connexion</p>");
      mysql_select_db("information_schema",$id_cx);
      $sql = "SELECT data_length, index_length, table_rows FROM TABLES WHERE table_name='documents'";
      $result = mysql_query($sql);
      $tuple = mysql_fetch_array($result);
      $data_length = $tuple['data_length'];
      $index_length = $tuple['index_length'];
      $taille_totale = $data_length + $index_length;
      $taille_mio = $taille_totale / 1000000;
      $table_rows = $tuple['table_rows'];
      echo "<ul>\n";
      echo "<li>Taille de la base : ".$taille_mio." Mio</li>\n";
      echo "<li>Nombre d'enregistrements : ".$table_rows."</li>\n";
      echo "</ul>\n";
   }

?>
