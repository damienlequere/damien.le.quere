#ifndef ORDONNANCEUR_TP_H_INCLUDED
#define ORDONNANCEUR_TP_H_INCLUDED

class Ordonnanceur_TP{

    public:

    static TacheSimulation *next_TP(list<TacheSimulation*>* listTacheSimulation, int t);

    protected:

    static int temps_restant(Tache tache, int t){
        return ((t / tache.getPi()) * tache.getPi() + tache.getDi()) - t;
        };

    static int derniere_date_reveil(Tache tache, int t){
        return (t / tache.getPi()) * tache.getPi();
        };

    };

#endif // ORDONNANCEUR_TP_H_INCLUDED
