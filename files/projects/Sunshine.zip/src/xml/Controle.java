package xml;

import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import principal.Sunshine;

/**
 * Cette classe abstraite permet de definir les bases du controle d'un jar
 * grace a un fichier xml, ainsi que l'extraction de ces donnees.
 * @author stephane
 */
public abstract class Controle {
	/**
	 * Le logger de Controle.
	 */
	private static final Logger LOGGER = Logger.getLogger("xml.Controle");
	
	/**
	 * Indique si un fichier xml est valide.
	 * @param fichierXml Le fichier xml a valider.
	 * @param loader Le classe loader depuis lequel on charge le fichier xml.
	 * @return Un boolean indiquant si le xml est valide.
	 */
	public abstract boolean estValide(String fichierXml, URLClassLoader loader);
	
	/**
	 * Retourne les parametres inscrits dans le fichier xml.
	 * @param fichierXml Le fichier xml depuis lequel on doit recuperer les donnees.
	 * @param loader Le loader depuis lequel on charge le xml.
	 * @return Les parametres du fichier xml.
	 */
	public Map<String, LinkedList<String>> parametreXml(String fichierXml, URLClassLoader loader) {
		Map<String, LinkedList<String>> result = null;
		
		if(loader != null)
		{
			try
			{
				LOGGER.setLevel(Sunshine.LEVEL);
			}
			catch (Exception e)
			{
				LOGGER.throwing(this.getClass().getName(), "Controle", e);
			}
			
			LOGGER.entering(this.getClass().getName(), "parametreXml", new Object[] {fichierXml, loader});
			
			Document document = null;
			
			LOGGER.log(Level.INFO, fichierXml);
			
			try
			{
				DocumentBuilderFactory fabrique = DocumentBuilderFactory.newInstance();
				DocumentBuilder constructeur = fabrique.newDocumentBuilder();
				document = constructeur.parse(loader.findResource(fichierXml).toString());
			}
			catch(Exception e)
			{
				LOGGER.throwing(this.getClass().getName(), "parametreXml", e);
			}
			
			result = parseXml(document); 
			LOGGER.exiting(this.getClass().getName(), "parametreXml", result);
		}
		
		return result;
	}
	
	/**
	 * Parse le fichier xml.
	 * @param document Le document xml a parser.
	 * @return Une table de hachage contenant les donnees du fichier xml.
	 * @throws Exception 
	 */
	private Map<String, LinkedList<String>> parseXml(Document document) {
		LOGGER.entering(this.getClass().getName(), "parseXml", document);
		HashMap<String, LinkedList<String>> hashMap = null;
		
		LOGGER.log(Level.INFO, "Document null ? "+(document == null));
		if(document != null)
		{
			hashMap = new HashMap<String, LinkedList<String>>();
			Element racine = document.getDocumentElement();
			
			LinkedList<String> liste = new LinkedList<String>();
			liste.add(racine.getElementsByTagName("programme").item(0).getTextContent());
			hashMap.put("programme", liste);
			
			liste = new LinkedList<String>();
			liste.add(racine.getElementsByTagName("version").item(0).getTextContent());
			hashMap.put("version", liste);
			
			liste = new LinkedList<String>();
			Node node = null;
			String fonction ="";
			String classe = "";
			
			for(int cpt = 0; cpt < racine.getElementsByTagName("role").getLength(); cpt++)
			{
				liste = new LinkedList<String>();
				node = racine.getElementsByTagName("role").item(cpt);
				fonction = node.getFirstChild().getTextContent();
				classe = node.getLastChild().getTextContent();
				if(fonction.equalsIgnoreCase("vue"))
				{
					if(hashMap.containsKey("vue"))
					{
						hashMap.get("vue").add(classe);
					}
					else
					{
						liste.add(classe);
						hashMap.put(fonction, liste);
					}
				}
				if(fonction.equalsIgnoreCase("modele"))
				{
					if(hashMap.containsKey("modele"))
					{
						hashMap.get("modele").add(classe);
					}
					else
					{
						liste.add(classe);
						hashMap.put(fonction, liste);
					}
				}
				if(fonction.equalsIgnoreCase("controleur"))
				{
					if(hashMap.containsKey("controleur"))
					{
						hashMap.get("controleur").add(classe);
					}
					else
					{
						liste.add(classe);
						hashMap.put(fonction, liste);
					}
				}
			}
		}
		
		LOGGER.exiting(this.getClass().getName(), "parseXml", hashMap);
		
		return hashMap;
	}
}
