<? include('./ressources/modules_indexation.php'); ?>
<? include('./ressources/param_bd.php'); ?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Recherche documentaire</title>

<link rel="stylesheet" type="text/css" media="screen" href="./ressources/ecran.css" />

</head>

<body>


<?
   ini_set("memory_limit",'200M');
   set_time_limit(3600);
   
   $fic_a_indexe = $_GET["nom_fic"];
   $rep_a_indexe = $_GET["nom_rep"];
   $minutes = $_GET["minutes"];
   $secondes = $_GET["secondes"];
   $nb_termes_indexes = 0;
   
   // TRAVAIL PRÉLIMINAIRE : remmplir un tableau associatif terme->stem (sans les stopwords)
   $tableau_stems = remplir_tab_stems("./ressources/stem.txt","./ressources/stopwords.txt");
  
   // CONNEXION À LA BASE DE DONNÉES
   $id_cx = mysql_connect($hote,$admin,$mot_de_pass) or die ("<p style=\"color:red;\">Erreur de connexion</p>");
   mysql_select_db($bd_moteur,$id_cx);
  
   // INDEXATION DEMANDÉE
   if($fic_a_indexe == $documents){
      echo "<div class=\"titre\">";
      echo "<h1>Indexation du repertoire <em>".$rep_a_indexe."</em></h1>\n";
      echo "<p><a href=\"index.php\" title=\"\">Retour accueil</a></p>";
      echo "</div>";
      $nb_termes_indexes = indexation_fichiers($rep_a_indexe, $id_cx);
   }else{
      echo "<div class=\"titre\">";
      echo "<h1>Indexation du fichier <em>".$fic_a_indexe."</em></h1>\n";
      echo "<p><a href=\"index.php\" title=\"\">Retour accueil</a></p>";
      echo "</div>";
      $nb_termes_indexes = indexation_fichier($fic_a_indexe, $id_cx);
   }
      
   
   /*
   foreach($tableau_stems as $cle=>$valeur){
      $sql = "INSERT INTO stems (terme,stem) VALUES ('".$cle."','".$valeur."')";
      mysql_query($sql);
   }*/
   
   
   /*
   $tableau_stopwords = remplir_tab_stopwords("./ressources/stopwords.txt");
   for($cpt = 0;$cpt < count($tableau_stopwords)-1;$cpt++){
      $sql = "INSERT INTO stopwords (stopword) VALUES ('".$tableau_stopwords[$cpt]."')";
      mysql_query($sql);
   }*/
   
   $min_act = date('i');
   $sec_act = date('s'); 
?>
   <script>
      alert("Indexation terminnée en <? affiche_temps_indexation($minutes,$secondes,$min_act,$sec_act);?> secondes\n<? echo $nb_termes_indexes; ?> termes indexés");
   </script>

<hr/>

<p style="text-align:center;"><a href="index.php" title="">Retour accueil</a></p>

</body>

</html>

