package serveur;

import java.rmi.*;
import java.rmi.server.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import common.ResultServerInterface;

public class ResultServerImpl extends UnicastRemoteObject implements ResultServerInterface{

    private static final long serialVersionUID = -1926306807175178886L;
    
    private Statement stmt;
    
    public ResultServerImpl (Statement st) throws RemoteException{
        super();
        stmt = st;
    }
    
    @Override
    public Vector<Integer> classement() throws RemoteException, SQLException{
        String requete = "SELECT num_pilote ,count(tour),sum(temps) FROM course GROUP BY (num_pilote) ORDER BY count(tour) DESC,sum(temps) ASC;";
        ResultSet rs = stmt.executeQuery(requete);
        
        Vector<Integer> nums_pilotes = new Vector<Integer>();
        while(rs.next())
            nums_pilotes.add(rs.getInt("num_pilote"));
        return nums_pilotes;
    }
    
    @Override
    public Integer getNbTourPremier() throws RemoteException, SQLException{
    	String requete = "SELECT count(tour) as nb_tour FROM course GROUP BY (num_pilote) ORDER BY count(tour) DESC,sum(temps) ASC;";
        ResultSet rs = stmt.executeQuery(requete);
        rs.next();
        Integer nbTourPremier = 0;
        nbTourPremier = rs.getInt("nb_tour");
        return nbTourPremier;
    }
    
    @Override
    public Float getMeilleurTempsTour(Integer tour)throws RemoteException, SQLException{
    	String requetePilote = "SELECT temps FROM course WHERE tour=" + tour + " ORDER BY temps ASC;";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
    	return rs.getFloat("temps");
    }
    
    @Override
	public Float getDernierTemps(Integer numP) throws RemoteException, SQLException {
		String requetePilote = "SELECT temps FROM pilotes NATURAL JOIN course WHERE num_pilote=" + numP + " ORDER BY tour DESC;";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
    	return rs.getFloat("temps");
    }
    
    @Override
    public Integer getDernierTour(Integer numP) throws RemoteException, SQLException{
    	String requetePilote = "SELECT tour FROM pilotes NATURAL JOIN course WHERE num_pilote=" + numP + " ORDER BY tour DESC;";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
        Integer dernierTour = 0;
        if (rs != null)
        	dernierTour = rs.getInt("tour");
    	return dernierTour;
    }

	@Override
	public Float getMeilleurTemps(Integer numP) throws RemoteException, SQLException {
		String requetePilote = "SELECT temps FROM course NATURAL JOIN pilotes WHERE num_pilote="+ numP +" ORDER BY temps;";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
    	return rs.getFloat("temps");
	}
    
	@Override
	public String getNom(Integer numP) throws RemoteException, SQLException {
		String requetePilote = "SELECT nom_pilote FROM pilotes WHERE num_pilote=" + numP + ";";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
        String nomPilote = "";
        if(rs.getString("nom_pilote")!= null)
         nomPilote = rs.getString("nom_pilote");
        return nomPilote;
	}

	@Override
	public Vector<Float> getTemps(Integer numP) throws RemoteException, SQLException {
		String requetePilote = "SELECT temps FROM pilotes NATURAL JOIN course WHERE num_pilote=" + numP + ";";
        ResultSet rs = stmt.executeQuery(requetePilote);
        
     // RÉCUPÉRATION DES TEMPS DU PILOTE
        Vector<Float> tempsPilote = new Vector<Float>();
        while(rs.next()) 
        	tempsPilote.add(rs.getFloat("num_pilote"));
		return tempsPilote;
	}

	@Override
	public Integer getToutCourant(Integer numP) throws RemoteException, SQLException {
		String requetePilote = "SELECT tour FROM pilotes NATURAL JOIN course WHERE num_pilote=" + numP + " ORDER BY tour DESC;";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
        return rs.getInt("temps");
	}
	
	@Override
	public Float getMoyenne(Integer numP) throws RemoteException, SQLException{
		String requetePilote = "SELECT avg(temps) as moyenne FROM course NATURAL JOIN pilotes WHERE num_pilote="+ numP +";";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
    	return rs.getFloat("moyenne");
	}
	
	@Override
	public Float getTempsTour(Integer numP, Integer tour) throws RemoteException, SQLException{
		String requetePilote = "SELECT temps FROM pilotes NATURAL JOIN course WHERE num_pilote="+numP+" AND tour="+tour+";";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
        return rs.getFloat("temps");
	}
	
	@Override
	public Float getTempsTotalTour(Integer numP, Integer tour) throws RemoteException, SQLException{
		String requetePilote = "SELECT sum(temps) as temps_total FROM pilotes NATURAL JOIN course WHERE num_pilote="+numP+" AND tour<="+tour+";";
        ResultSet rs = stmt.executeQuery(requetePilote);
        rs.next();
        return rs.getFloat("temps_total");
	}
	
	@Override
	public Integer getPositionTour(Integer numP, Integer tour) throws RemoteException, SQLException{
		String requete = "SELECT num_pilote ,count(tour),sum(temps) FROM course WHERE tour<=" + tour + " GROUP BY (num_pilote) ORDER BY count(tour) DESC,sum(temps) ASC;";
        ResultSet rs = stmt.executeQuery(requete);
        
        Integer pos = 0, pos_trouvee = 0;
        while(rs.next()){
        	pos++;
            if (numP.equals(rs.getInt("num_pilote")))
            	pos_trouvee = pos; 
        }
        return pos_trouvee;
	}
	
}
