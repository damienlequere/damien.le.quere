package test.junit.decouverte.parcours;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import decouverte.parcours.GestionJarValideAvecXml;
import decouverte.parcours.GestionJarValideSansXml;
import decouverte.parcours.GestionPutProgrammeAvecXml;
import decouverte.parcours.GestionPutProgrammeSansXml;
import decouverte.parcours.GestionnaireTypeEnum;
import decouverte.parcours.ParcoureurDeJar;

/**
 * @author stephane
 *
 */
public class ParcoureurDeJarTest {
	/**
	 * Le jar en cours d'examen.
	 */
	private String jar;
	
	/**
	 * Initialisation des tests.
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		this.jar = System.getProperty("user.dir")+"/plugins/calcul.jar";
	}
	
	/**
	 * Test de la methode traiter.
	 */
	@org.testng.annotations.Test(groups="decouverte.parcours")
	@Test
	public void testTraiter() {
		ParcoureurDeJar parcoureur;
		
		parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionJarValideSansXml);
		assertTrue("Le resultat ne contient pas un GestionJarValideSansXml", GestionJarValideSansXml.class.isAssignableFrom(parcoureur.traiter().getClass()));
		
		parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionJarValideAvecXml);
		assertTrue("Le resultat ne contient pas un GestionJarValideAvecXml", GestionJarValideAvecXml.class.isAssignableFrom(parcoureur.traiter().getClass()));
		
		parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionPutProgrammeSansXml);
		assertTrue("Le resultat ne contient pas un GestionPutProgrammeSansXml", GestionPutProgrammeSansXml.class.isAssignableFrom(parcoureur.traiter().getClass()));
		
		parcoureur = new ParcoureurDeJar(jar, GestionnaireTypeEnum.GestionPutProgrammeAvecXml);
		assertTrue("Le resultat ne contient pas un GestionPutProgrammeAvecXml", GestionPutProgrammeAvecXml.class.isAssignableFrom(parcoureur.traiter().getClass()));
	}

}
