#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <dirent.h>

struct instruction_s{
      int commande;
      char parametre[128];
   };

long fsize(FILE * fp)
{
    long pos, size;
    pos = ftell(fp);
    fseek(fp, 0, SEEK_END);
    size = ftell(fp);
    fseek(fp, pos, SEEK_SET);
    return size;
}


/* Etablissement connexion *************************************************************/
int etablissement_connexion(char *host, int port){
   int sd;                    /* descripteur de socket */
   struct sockaddr_in adsock; /* adresse de socket local */
   struct hostent *hptr;      /* info sur une machine */
   struct servent *sptr;      /* info sur service */
   
   
   if((hptr = gethostbyname(host)) == NULL){
      perror(">>Pb pour la recup des infos du host");
      exit(1);
   }
      
   /* copie car/car des infos de hptr vers adsock */
   bcopy((char *)hptr->h_addr,(char *)&adsock.sin_addr,hptr->h_length);
   adsock.sin_family = AF_INET;
   adsock.sin_port = htons(port);
   
   if((sd = socket(AF_INET, SOCK_STREAM, 0))<0){
      perror(">>Pb de creation de la socket");
      exit(1);
   }

   //Affichage des infos de l'envoi
   printf("Etablissement de la connexion ...\n");
   printf("   IPServeur = %s\n",host);
   printf("   Num port = %d\n",ntohs(adsock.sin_port));
   printf("   IDsocket = %d\n",sd);
      
   /* tentative de connexion au serveur dont les infos sont dans adsock */
   if((connect(sd,&adsock,sizeof(adsock)))<0){
      perror(">>Pb de connexion");
      exit(1);
   }
   return sd;
}

/* Attente retour ***********************************************************/
void attente_retour(int sock, char * msg[256]){
	char buf[256],
	     message[256];
	int lon,
	    c,
	    i=0;
	    
	if ((lon = read(sock, buf, sizeof(buf))) > 0){
	   buf[lon]='\0';
	   // Recuperation du message
	   for(c=0;c<=lon;c++){
	      message[i] = buf[c];
	      i++;
	   }
	   message[lon+1] = '\0';
	   sprintf(msg,"%s",message);
	}
}
/* Envoi MESSAGE *************************************************************/
void envoi_message(int sd, char * message){
	int lon;
	char buf[256];
	if((write(sd,message,strlen(message))) < 0){
      perror(">>Pb sur le write");
      exit(1);
    }
}

/* Envoi INSTRUCTION ********************************************************/
int envoi_instr(int sock, struct instruction_s instruction){
	char message[512],
	     message_retour[512];
	
	sprintf(message, "%i#%s", instruction.commande, instruction.parametre);
	//printf("%s\n",message);
	envoi_message(sock,message);
	attente_retour(sock,&message_retour);
	printf("%s",message_retour);
	if(!strcmp(message_retour,"Connexion acceptee"))
	   return 0;
	else
	   return 1;
}

/* Envoi FICHIER *************************************************************/
void envoi_fichier(int sock, char nom_fichier[50]){
   int n,
       cpt = 0,
       taille = 32;
   unsigned char buf[taille];
   char nom_fic_abs[128],
        message[128],
        rep[50];
   
   
   sprintf(nom_fic_abs,"./Repclient/%s",nom_fichier);
   FILE* fp = fopen(nom_fic_abs, "rb");
   
   // On commence par envoyer une instruction contenant le nom et la taille du fichier
   struct instruction_s instruction;
   sprintf(instruction.parametre,"%s/%i",nom_fichier,fsize(fp));
   instruction.commande = 302;
   envoi_instr(sock,instruction);
   
   
   
   while ((n = fread (buf, sizeof buf, 1,fp)) > 0)
   {
   	  cpt = cpt + 1;
   	  send (sock, buf, sizeof buf, 0);
   }
   send (sock, buf, sizeof buf, 0);
   
   fclose(fp);
   return;
}

struct instruction_s instruction;

/*################ POINT D'ENTREE DU CLIENT ################*/
int main(int argc,char **argv){
   int sock,
       choix=0,
       ident=1;
   
   // Connexion avec le serveur
   sock = etablissement_connexion(argv[1],1026);
   
   // Choix du type de connexion
   do{
      printf("\n");
      printf("1 - Identification securise\n");
      printf("2 - Identification non securise\n");
      printf("Votre choix : ");
      scanf ("%i",&choix);
   }while((choix < 1)||(choix > 2));
   
   char login[128],
        mdp[128];
   
   // Continuer de demander login/pass 
   // jusqu'a ce que l'autentification soit valide
   do{
   if(choix == 1){
   	printf("\nLogin : ");scanf ("%s",login);
   	printf("Mot de passe : ");scanf ("%s",mdp);
      instruction.commande = 102;
      sprintf(instruction.parametre,"%s/%s",login,mdp);
      ident = envoi_instr(sock,instruction);
   }else{
   	printf("\nLogin : ");scanf ("%s",login);
   	instruction.commande = 101;
      sprintf(instruction.parametre,"%s", login);
      envoi_instr(sock,instruction);
      ident = 0;
   }
   }while(ident==1);
   
   do{
   
      choix = 0;
      
      
   do{
   	  printf("1 - Lister les repertoires\n");
   	  printf("2 - Creer un repertoire\n");
   	  printf("3 - Changer de repertoire\n");
   	  printf("4 - Renommer un repertoire\n");
   	  printf("5 - Supprimer un repertoire\n");	  
   	  printf("6 - Lister les fichiers\n");
   	  printf("7 - Envoyer un fichier\n");
   	  printf("8 - Deplacer un fichier\n");
   	  printf("9 - Renommer un fichier\n");
   	  printf("10 - Supprimmer un fichier\n");
   	  printf("11 - Quitter le client\n");
   	  printf("Votre choix : ");
   	  scanf ("%i",&choix);
   }
   while((choix < 1) || (choix > 13));
   
   
   switch(choix){
      case 1: //Lister les repertoire
      {
         instruction.commande = 201;
         sprintf(instruction.parametre,"%s","listerrepertoire");
    	   envoi_instr(sock,instruction);
      }
      break;
      
      case 2: // Creer un repertoire
      {
         char nom_rep[50];
         instruction.commande = 202;
         printf("Donnez le nom du repertoire : ");scanf("%s",nom_rep);
         sprintf(instruction.parametre,"%s",nom_rep);
         envoi_instr(sock,instruction);
      }
      break;
      
      case 3: // Changer de repertoire
      {
         char nom_rep[50];
         instruction.commande = 203;
         printf("Donnez le nom du repertoire : ");scanf("%s",nom_rep);
         sprintf(instruction.parametre,"%s",nom_rep);
         envoi_instr(sock,instruction);
      }
      break;
      
      case 4: // Renommer un repertoire
      {
         char nom_rep[50],nom_rep2[50];
         instruction.commande = 204;
         printf("Donnez le nom du repertoire a renommer : ");scanf("%s",nom_rep);
         printf("Donnez le nom du repertoire a renommer : ");scanf("%s",nom_rep2);
         sprintf(instruction.parametre,"%s/%s",nom_rep,nom_rep2);
         envoi_instr(sock,instruction);
      }
      break;
      
      case 5: // Supprimer un repertoire
      {
         char nom_rep[50];
         instruction.commande = 205;
         printf("Donnez le nom du repertoire a supprimer : ");scanf("%s",nom_rep);
         sprintf(instruction.parametre,"%s",nom_rep);
         envoi_instr(sock,instruction);
      }
      break;
      
      case 6: // Lister les fichiers
         instruction.commande = 301;
         sprintf(instruction.parametre,"%s","listerfichiers");
    	   envoi_instr(sock,instruction);
      break;
      
      case 7: // Envoyer un fichier
      {
      char nom_fichier[128];
      int trouve = 0;
      // On boucle en attendant un nom de fichier qui existe
      do{
         char fichier_abs[128];
         FILE * fp;
         printf("Nom du fichier a envoyer : ");scanf("%s",nom_fichier);
      	
      	sprintf(fichier_abs,"./Repclient/%s",nom_fichier);
      	fp = fopen(fichier_abs, "r");
      	
      	if(fp==NULL){
      	   printf("Fichier non trouve [%s]\n",fichier_abs);
      	   fclose(fp);
      	}else{
      	   trouve = 1;
      	   fclose(fp);
      	}
      }
      while(trouve==0);
      
      	envoi_fichier(sock,nom_fichier);
      }
      break;
      
      case 8: // Deplacer un fichier
      {
         char nom_fic[50],nom_rep[50];
         printf("Donnez le nom du fichier a deplacer : ");scanf("%s",nom_fic);
         printf("Donnez le nom du repertoire : ");scanf("%s",nom_rep);
         sprintf(instruction.parametre,"%s/%s",nom_fic,nom_rep);
         instruction.commande = 303;
         envoi_instr(sock,instruction);
      }	   
      break;
      
      case 9: // Renommer un fichier
      {
         char nom_fic[50],nom_fic2[50];
         printf("Donnez le nom du fichier a renommer : ");scanf("%s",nom_fic);
         printf("Donnez le nom du nouveau fichier : ");scanf("%s",nom_fic2);
         sprintf(instruction.parametre,"%s/%s",nom_fic,nom_fic2);
         instruction.commande = 304;
         envoi_instr(sock,instruction);
      }   
      break;
      	
      case 10: // Supprimer un fichier
      {
         char nom_fic[50];
         instruction.commande = 305;
         printf("Donnez le nom du fichier a supprimer : ");scanf("%s",nom_fic);
         sprintf(instruction.parametre,"%s",nom_fic);
         envoi_instr(sock,instruction);
      }
      break;
      
      case 11: // Quitter le client
      {
      	instruction.commande = 666;
         sprintf(instruction.parametre,"%s","quitter client");
    	   envoi_instr(sock,instruction);
    	}
      break;
      }//end switch
      
      }while(choix!=11);
      
}
