Commandes de compilation :

gcc -c serveur.c client.c;
gcc -o client client.o;
gcc -o serveur serveur.o;

Lancement serveur/client :

./serveur
./client [@IP_serveur]
