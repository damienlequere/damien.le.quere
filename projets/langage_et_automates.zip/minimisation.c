#include "minimisation.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/* Modules utilises pour la minimisation **************/
/******************************************************/

//
int sont_etats_de_classes_differentes(char * etatA,
                                      char * etatB,
                                      struct Liste_de_listes * Ens_Des_Classes)
{
	struct Liste_chaine * l_aux;
	while(Ens_Des_Classes!=NULL){
		l_aux=Ens_Des_Classes->pt_liste_etats;
		if(est_mot_de_la_liste(l_aux,etatA)){
			if(est_mot_de_la_liste(l_aux,etatB)){
				return 0;
			} else {
				return 1;
			}
		}
		Ens_Des_Classes=Ens_Des_Classes->pt_liste_suivante;
	}
}


//
int sont_distingables(char * etatA, 
                      char * etatB,
                      struct Liste_regle * liste_des_regles,
                      struct Liste_de_listes * Ens_Des_Classes,
                      struct Liste_chaine * liste_symboles)
{
	char * etat_arriveA;
	char * etat_arriveB;
	int comp, distingables = 0;
	struct Regle r;
	struct Liste_regle * l_regles_aux;
	
	while(liste_symboles != NULL){
		l_regles_aux = liste_des_regles;
		while(l_regles_aux != NULL){
			r = l_regles_aux->la_regle;
			comp = strcmp(liste_symboles->chaine, r.symbole);
			if(comp == 0){
				comp = strcmp(etatA, r.etat_depart);
				if (comp == 0){
					etat_arriveA = r.etat_arrive;
				}
				comp = strcmp(etatB, r.etat_depart);
				if (comp == 0){
					etat_arriveB = r.etat_arrive;
				}
			}
			l_regles_aux = l_regles_aux->regle_suivante;
		}
		distingables = (distingables || sont_etats_de_classes_differentes(etat_arriveA, etat_arriveB,Ens_Des_Classes));
		liste_symboles = liste_symboles->chaine_suivante;
	}
	return distingables;
}


/* MINIMISATION : 
* Module de minimisation prenant une matrice de transitionen entree / sortie
*
* IMPORTANT : la matrice doit avoir ete emondee, completee et determinisee
*  avant d'utiliser ce module
***********************************************************************/
void minimisation(struct Liste_regle ** liste_des_regles, 
                  struct Liste_chaine ** liste_etats_initiaux,
                  struct Liste_chaine ** liste_etats_finaux,
                  struct Liste_chaine ** liste_etats_utiles,
                  struct Liste_chaine * liste_symboles)
{
	struct Liste_de_listes * Ens_Des_Classes=NULL;
	struct Liste_de_listes * Nouvel_Ens_Des_Classes=NULL;
	struct Liste_de_listes * Ens_Des_Classes_aux;  // Liste des differentes classes
	struct Liste_chaine * classe = NULL;
	struct Liste_chaine * l_etats_aux = *liste_etats_finaux;
	struct Liste_de_listes * l_classe_aux;

	// Creation de la liste des etats finaux
	while(l_etats_aux!=NULL){
		ajout_liste_en_tete(l_etats_aux->chaine,&classe);
		l_etats_aux=l_etats_aux->chaine_suivante;
	}
	// Insertion de la liste dans l ensemble des classes
	ajout_liste_de_listes_en_queue(classe,&Ens_Des_Classes);
	classe = NULL;

	// Creation de la liste des etats non finaux
	l_etats_aux = *liste_etats_utiles;
	while(l_etats_aux!=NULL){
		if(!est_mot_de_la_liste(*liste_etats_finaux,l_etats_aux->chaine)){
			ajout_liste_en_tete(l_etats_aux->chaine,&classe);
		}
		l_etats_aux=l_etats_aux->chaine_suivante;
	}
	
	// Insertion de la liste dans l ensemble des classes
	if(classe!=NULL){
	   ajout_liste_de_listes_en_queue(classe,&Ens_Des_Classes);
	}
	Ens_Des_Classes_aux=Ens_Des_Classes;
	
	// A cette etape on a donc deux classes dans l ensemble des classes: les etats finaux et les non finaux

	// On separe maintenant les etats tant que c est possible
	while(!sont_listes_de_listes_identiques(Ens_Des_Classes,Nouvel_Ens_Des_Classes)){
		Ens_Des_Classes = Ens_Des_Classes_aux; // Ensemble des classes avant le tour de boucle
		Nouvel_Ens_Des_Classes = NULL;         // Ensemble permettant de stocker les classes crees pendant le tour de boucle
		struct Liste_chaine * ancienne_classe;
		l_classe_aux = Ens_Des_Classes;
		
		// Parcours de l ensemble des classes
		while(l_classe_aux!=NULL){
			ancienne_classe = l_classe_aux->pt_liste_etats;                 // On considere la classe en debut de liste
			struct Liste_chaine * nouvelle_classeA = NULL;                  // Classe servant à stocker les etats non-distingables du premier etat de la classe
			struct Liste_chaine * nouvelle_classeB = NULL;                  // Classe servant à stocker les etats distingables du premier etat de la classe
			ajout_liste_en_tete(ancienne_classe->chaine,&nouvelle_classeA); // Ajout du premier etat de la classe dans la classe A
			l_etats_aux = ancienne_classe->chaine_suivante;
			
			// Parcours du reste des etats de la classe
			while(l_etats_aux!=NULL){	
				if(sont_distingables(l_etats_aux->chaine,nouvelle_classeA->chaine,*liste_des_regles,Ens_Des_Classes,liste_symboles))
				{
				   // Si l etat n est pas distingable il est ajoute dans la classe B
				   ajout_liste_en_queue(l_etats_aux->chaine,&nouvelle_classeB);
				} else {
				   // Si l etat est distingable il est ajoute dans la classe A
				   ajout_liste_en_queue(l_etats_aux->chaine,&nouvelle_classeA);
				}
				l_etats_aux=l_etats_aux->chaine_suivante;
			}
			// Ajout de la classe A dans le nouvel ensemble des classes
			ajout_liste_de_listes_en_queue(nouvelle_classeA,&Nouvel_Ens_Des_Classes);
			if(nouvelle_classeB != NULL)
			{
			   // Ajout de la classe B dans le nouvel ensemble des classes à condition que la classe B contienne au moins un etat
			   ajout_liste_de_listes_en_queue(nouvelle_classeB,&Nouvel_Ens_Des_Classes);	
			}
			l_classe_aux = l_classe_aux->pt_liste_suivante;
		}
		Ens_Des_Classes_aux = Nouvel_Ens_Des_Classes; //Remplacement de l ancien ensemble de classes par le nouveau
	}
	
	// A cette etape on a donc un ensemble de classes de taille minimal pour obtenir un automate equivalent à la matrice

	//Creation des nouvelles regles de transition
	char * nom_etat;
	char * etat_arrive;
	struct Liste_regle * l_regle_aux;
	struct Regle r;
	struct Regle r_aux;
	struct Liste_chaine * l_symboles_aux;
	struct Liste_de_listes * l_ens_classes_aux;
	int comp, est_etat_initial, est_etat_final;
	
	struct Liste_regle * nouvelle_liste_des_regles = NULL;      // Liste permettant de stocker la nouvelle liste de regles
	struct Liste_chaine * nouvelle_liste_etats_utiles = NULL;   // Liste permettant de stocker la nouvelle liste des etats utiles
	struct Liste_chaine * nouvelle_liste_etats_finaux = NULL;   // Liste permettant de stocker la nouvelle liste des etats finaux
	struct Liste_chaine * nouvelle_liste_etats_initiaux = NULL; // Liste permettant de stocker la nouvelle liste des etats initiaux
	
	// Parcours de l ensemble des classes
	while(Ens_Des_Classes!=NULL){
		nom_etat = (char *)calloc(2500,sizeof(char));	// Nom du nouvel etat
		l_etats_aux = Ens_Des_Classes->pt_liste_etats;  // On considere la premiere classe de l ensemble
		est_etat_final = 0; est_etat_initial = 0;
		
		// Parcours de la classe consideree afin de creer un nouvel etat
		while(l_etats_aux!=NULL){
		   // Determine si au moins un etat de la classe fait parti des etats finaux
			if(est_mot_de_la_liste(*liste_etats_finaux,l_etats_aux->chaine)){est_etat_final = 1;}
			// Determine si au moins un etat de la classe fait parti des etats initiaux
			if(est_mot_de_la_liste(*liste_etats_initiaux,l_etats_aux->chaine)){est_etat_initial = 1;}
			// Le nom du nouvel etat est la concatenation des noms des etats qui compose la classe
			strcat(nom_etat,l_etats_aux->chaine);
			l_etats_aux = l_etats_aux->chaine_suivante;
		}
		// Si au moins un des etats de la classe fait parti des etats finaux alors le nouvel etat fait parti des nouveaux etats finaux
		if(est_etat_final==1){ajout_liste_en_tete(nom_etat,&nouvelle_liste_etats_finaux);}
		// Si au moins un des etats de la classe fait parti des etats initiaux alors le nouvel etat fait parti des nouveaux etats initiaux
		if(est_etat_initial==1){ajout_liste_en_tete(nom_etat,&nouvelle_liste_etats_initiaux);}
		// Ajout du nouvel etat dans la nouvelle liste des etats utiles
		ajout_liste_en_tete(nom_etat,&nouvelle_liste_etats_utiles);
		
		r.etat_depart = nom_etat;
		l_symboles_aux = liste_symboles;
		while(l_symboles_aux!=NULL){
			l_regle_aux = *liste_des_regles;
			while(l_regle_aux){
				r_aux = l_regle_aux->la_regle;
				comp = strcmp(r_aux.symbole,l_symboles_aux->chaine);
				if(comp==0){
					comp = strcmp(r_aux.etat_depart,(Ens_Des_Classes->pt_liste_etats)->chaine);
					if(comp==0){etat_arrive = r_aux.etat_arrive;}
				}
				l_regle_aux = l_regle_aux->regle_suivante;
			}
			r.symbole = l_symboles_aux->chaine;
			l_ens_classes_aux = Nouvel_Ens_Des_Classes;
			while(l_ens_classes_aux!=NULL){
				l_etats_aux = l_ens_classes_aux->pt_liste_etats;
				if(est_mot_de_la_liste(l_etats_aux,etat_arrive)){
					nom_etat = (char *)calloc(2500,sizeof(char));
					while(l_etats_aux!=NULL){
						strcat(nom_etat,l_etats_aux->chaine);
						l_etats_aux = l_etats_aux->chaine_suivante;
					}
					r.etat_arrive = nom_etat;
				}
				l_ens_classes_aux = l_ens_classes_aux->pt_liste_suivante;
			}
			ajout_regle_dans_liste(r,&nouvelle_liste_des_regles);
			l_symboles_aux = l_symboles_aux->chaine_suivante;
		}
		Ens_Des_Classes = Ens_Des_Classes->pt_liste_suivante;
	}
	
	// On modifie les listes originales
	*liste_des_regles = nouvelle_liste_des_regles;
	*liste_etats_utiles = nouvelle_liste_etats_utiles;
	*liste_etats_finaux = nouvelle_liste_etats_finaux;
	*liste_etats_initiaux = nouvelle_liste_etats_initiaux;
	
	// Enfin on emonde l automate pour supprimer l etat puits
   emondage(liste_des_regles, liste_etats_initiaux, liste_etats_finaux, liste_etats_utiles);
}
