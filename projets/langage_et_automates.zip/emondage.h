/***************************************************************
* NOTE SUR CE FICHIER :
* Ce fichier contient le module EMONDAGE et les fonctions necessaires
* a son fonctionnement.
***************************************************************/

#include "mt.h"

#ifndef EMONDAGE_H
#define EMONDAGE_H


// Suppression des etats qui n apparaissent jamais dans une liste de regles
void suppression_des_etats_trivialement_inutiles(struct Liste_chaine ** liste_a_redefinir, struct Liste_chaine * liste_modele);


//
void ajouter_etats_accessibles(char * etat, struct Liste_regle * liste_des_regles, struct Liste_chaine ** etats_accessibles);


//
void ajouter_etats_coaccessibles(char * etat, struct Liste_regle * liste_des_regles, struct Liste_chaine ** etats_coaccessibles);


//
void intersection_de_listes(struct Liste_chaine ** liste_resultat, struct Liste_chaine * listeA, struct Liste_chaine * listeB);


//
void supprime_regles_inutiles(struct Liste_chaine * liste_etats_utiles, struct Liste_regle ** liste_des_regles);


// Module d emondage
void emondage(struct Liste_regle ** liste_des_regles,
              struct Liste_chaine ** liste_etats_initiaux,
              struct Liste_chaine ** liste_etats_finaux,
              struct Liste_chaine ** liste_etats_utiles);


#endif

