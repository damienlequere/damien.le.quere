<? include('./ressources/param_bd.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Mise au point d'un moteur de recherche</title>

<link rel="stylesheet" type="text/css" media="screen" href="./ressources/ecran.css" />

</head>

<body>

<div class="titre">

<a href="index.php" title=""><h1 style="text-align:center;">Mise au point d'un moteur de recherche</h1></a>

<p style="text-align:center;"><em>Pierre-Jean Garreau</em> &amp; <em>Damien Le Quéré</em></p>

</div>

<form method="get" action="indexation.php" style="margin-top:20px;">
<fieldset>
<legend>Indexation de documents</legend>
<table>
<tr>
<td><label for="nom_rep">Indexer <strong>tous les fichiers</strong> d'un répertoire dans la base de données</label> : </td>
<td><input type="text" value="<?echo $documents;?>" name="nom_rep" id="nom_rep" class="texte"/></td>
<td><input type="submit" value="Lancer l'indexation" class="bouton"/></td>
</tr>
<tr>
<td><label for="nom_fic">Indexer <strong>un fichier</strong> dans la base de données</label> : </td>
<td><input type="text" value="<?echo $documents;?>" name="nom_fic" id="nom_fic" class="texte"/></td>
<td><input type="submit" value="Lancer l'indexation" class="bouton"/></td>
</tr>
</table>
</fieldset>

<input type="hidden" value="<? echo date('i');?>" id="minutes" name="minutes"/>
<input type="hidden" value="<? echo date('s');?>" id="secondes" name="secondes"/>

</form>

<fieldset style="margin-top:10px;">
<legend>Recherche documentaire</legend>
<form method="get" action="recherche_booleenne.php" style="margin-top:10px;">
<table style="width:100%;">
<tr>
<td><label for="mots_cles_tous">Rechercher <strong>tous les mots</strong></label></td>
<td><input type="text" value="" name="mots_cles_tous" id="mots_cles_tous" size="53" class="texte"/></td>
<td><input type="submit" value="Recherche Booléenne" class="bouton"/></td>
</tr>
</form>
<form method="get" action="recherche_booleenne.php" style="margin-top:10px;">
<tr>
<td><label for="mots_cles_plus">Rechercher <strong>le plus de mots</strong></label></td>
<td><input type="text" value="" name="mots_cles_plus" id="mots_cles_plus" size="53" class="texte"/></td>
<td><input type="submit" value="Recherche Booléenne" class="bouton"/></td>
</tr>

</form>

<form method="get" action="recherche_vectorielle.php" style="margin-top:10px;">

<tr>
<td><label for="mots_cles_vect">Rechercher <strong>le plus de mots</strong> et ordonner les résultats</label></td>
<td><input type="text" value="" name="mots_cles_vect" id="mots_cles_vect" size="53" class="texte"/></td>
<td><input type="submit" value="Recherche Semie-Vectorielle" class="bouton"/></td>
</tr>
</table>
</form>
</fieldset>


<h3>&Eacute;tat de la base de données</h3>

<? affiche_caracteristiques(); ?>

<hr/>

<p style="text-align:center;"><a href="presentation.php" title="">Présentation du moteur de recherche</a> - <a href="http://localhost/phpmyadmin/" title="">Accès à la base de données</a><br/><a href="<?echo $documents;?>" title="">Voir les documents</a> - <a href="./rapport/rapport.pdf" title="">Rapport en version PDF</a></p>

</body>

</html>


