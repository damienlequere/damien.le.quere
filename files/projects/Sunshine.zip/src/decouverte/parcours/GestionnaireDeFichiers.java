package decouverte.parcours;

import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;

/**
 * Le GestionnaireDeFichiers est une interface permettant de choisir
 * le traitement a realiser sur un jar lors de son ouverture.
 * Grace a cette interface on peut realiser la verification du jar, 
 * l'extraction des informations contenues a l'interieur, voir plus
 * en implementant les methodes definies.
 * @author stephane
 */
public abstract class GestionnaireDeFichiers {
	/**
	 * Fichier jar charge en memoire.
	 */
	protected File jar;
	
	/**
	 * Classe loader du fichier jar en memoire.
	 */
	protected URLClassLoader loader;
	
	/**
	 * Renvoie le resultat du gestionnaire de fichiers apres traitement des fichiers du jar.
	 * @return Resultat du traitement.
	 * @throws ClassNotFoundException Si le classe loader ne trouve pas la classe a charger.
	 * @throws IOException Si le jar n'est pas trouve.
	 */
	public abstract Object getResultats() throws ClassNotFoundException, IOException;
	
	/**
	 * Permet de changer le fichier jar en memoire que l'on traite.
	 * @param jar Fichier jar charge en memoire.
	 */
	public void setFile(File jar) {
		this.jar = jar;
	}
	
	/**
	 * Permet de changer le classe loader du jar en memoire.
	 * @param loader Le classe loader du jar en cours de traitement.
	 */
	public void setLoader(URLClassLoader loader) {
		this.loader = loader;
	}
}
