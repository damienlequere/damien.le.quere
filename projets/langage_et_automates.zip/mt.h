/***************************************************************
* NOTE SUR CE FICHIER :
* Ce fichier contient les declarations des differentes structures
* utilisees pour stocker les informations d une matrice de transition
*
* Ce fichier contient aussi des modules permettant de manipuler
* ces structures.
*
* Enfin ce fichier contient un module de lecture d une matrice de
* transition "lecture_matrice" et un module d affichage d une
* matrice "affiche_matrice".
***************************************************************/

#ifndef MATRICE_TRANSITION_H
#define MATRICE_TRANSITION_H

/***************************************************************/
/****************** Structures de donnees **********************/
/***************************************************************/

struct Regle{
char * etat_depart;
char * etat_arrive;
char * symbole;
};

struct Liste_regle{
struct Regle la_regle;
struct Liste_regle * regle_suivante;
};

struct Liste_chaine{
char * chaine;
struct Liste_chaine * chaine_suivante;
};


/***************************************************************/
/******************* Procedures et fonctions *******************/
/***************************************************************/


/* Modules utilises pour les listes de chaines ou les listes de regles **************/
/************************************************************************************/

// Ajout en tete d'une chaine de caracteres
void ajout_liste_en_tete(char * mot, struct Liste_chaine ** liste);


// Ajout en queue d'une chaine de caracteres
void ajout_liste_en_queue(char * mot, struct Liste_chaine ** liste);


// Ajout d'une regle
void ajout_regle_dans_liste(struct Regle r,struct Liste_regle ** liste_des_regles);


// Affichage d'une liste de chaines :
void affiche_liste_chaine(struct Liste_chaine * liste);


// Affichage d'une liste de regles
void affiche_regles(struct Liste_regle * liste);


// Affichage des structures de donnees correspondants a la matrice de transition de l automate
void affiche_matrice(struct Liste_chaine * liste_etats_initiaux,
                     struct Liste_chaine * liste_etats_finaux,
                     struct Liste_chaine * liste_etats,
                     struct Liste_chaine * liste_symboles,
                     struct Liste_regle * liste_des_regles);


/* Modules utilises dans la procedure lecture matrice **********/
/***************************************************************/

// Predicat determinant si le caractere est un retour chariot
int retour_a_la_ligne(char car);


/* Pour parser on utilise une machine à etats (ensembles de variables booleennes)
* Cette procedure parseur modifie ces variables selon le caractere courant, modifiant ainsi l'etat courant
* (exemple d'etats : "on est en train de lire des etats initiaux", "on est en train de lire des regles") */
void parseur(char car, int * lecture_transition, int * entre_accolades, int * lecture_etats_initiaux, int * lecture_etats_finaux, int * lecture_regle);


// Predicat determinant si la liste "liste" contient le mot "mot"
int est_mot_de_la_liste(struct Liste_chaine * liste, char * mot);


/* Modules utilises dans l'algorithme AFDET **********/
/*****************************************************/

// Taille d une liste chainee de chaines de caracteres
int taille_liste_chaine(struct Liste_chaine * liste);


// Vrai si les listes de chaines sont identiques (sans notion d'ordre car les listes sont utilisees comme des ensembles), faux sinon
int compare_listes_chaines(struct Liste_chaine * liste1, struct Liste_chaine * liste2);


/*****************************************************************************
* Lecture Matrice :
* Permet de stocker des structures de donnees la matrice de transitions
* d'un AF donnee dans un fichier texte dont le nom est passe en parametre
* et place dans le repertoire courant
******************************************************************************/
void lecture_matrice(char * nom_fic,
                     struct Liste_chaine ** liste_etats_initiaux, 
                     struct Liste_chaine ** liste_etats_finaux,
                     struct Liste_chaine ** liste_etats,
                     struct Liste_chaine ** liste_symboles,
                     struct Liste_regle ** liste_des_regles);

#endif
