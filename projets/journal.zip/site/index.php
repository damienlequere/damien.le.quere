<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Encore un quotidien national</title>

<link rel="stylesheet" type="text/css" media="screen" href="./style/ecran.css" />

<script type="text/javascript" src="./resources/jquery.js"></script>          

<script type="text/javascript">
$(document).ready(function() {
   $("#connect").hide();
   $("a#lien_connect").click(function() {
      $("#connect").show();
   });
   $("#titre").click(function () {
         $("#connect").hide();
    });
   $("#champ_recherche").focus(function() {
      $("#champ_recherche").val("");
   });

 });

</script>

</head>

<body>

<div id="page">

<? include("./blocs/titre.html"); ?>

<ul id="menu">

<li><a href="./index.php" title="" class="page_courante">Accueil</a></li>
<li><a href="./politique.php" title="">Politique</a></li>
<li><a href="./sport.php" title="">Sport</a></li>
<li><a href="./economie.php" title="">&Eacute;conomie</a></li>
<li><a href="./sante.php" title="">Santé</a></li>

</ul>

<table>

<tr>

<td id="contenu">

<form id="recherche" method="get" action="recherche.php">
<input type="text" value="Rechercher un article" class="texte" id="champ_recherche" name="mots"/>
<input type="submit" value="Rechercher"/>
</form>

<div class="article">

<h2><a href="villepin.php" title="">Clearstream : Villepin réclame la vérité</a></h2>

<img src="./img/villepin.jpg" alt="" />

<p>
«Je suis ici par l'acharnement d'un homme», a déclaré lundi l'ancien premier ministre, peu avant l'ouverture du procès dans lequel il est soupçonné d'avoir ourdi un complot politique contre Nicolas Sarkozy.
<br/><a href="" title="">» EN IMAGES - Les acteurs clés de l'affaire</a>
<br/><a href="" title="">» Clearstream décidera du destin politique de Villepin</a>
</p>

<hr/>

</div>

<div class="article">

<h2 ><a href="" title="">Les Français toujours aussi nombreux
à lire les journaux</a></h2>

<p>L'audience des quotidiens est restée stable alors que celle des magazines se «fragmente».</p>

<hr/>

</div>

<div class="article">

<img src="./img/foot.jpg" alt="" style="display:block;float:right;"/>

<h2 ><a href="" title="">Cissoko : «On s'attend
à un match fermé»</a></h2>

<p><strong>INTERVIEW</strong> - Découvert la saison dernière lors d'un match de Ligue des Champions entre Porto et Manchester United, c'est en tant que défenseur de l'OL qu'il retrouve la compétition qui l'a fait connaître.</p>

<hr/>

</div>

<div class="article">

<h2 ><a href="" title="">Solvants : un risque accru
de malformations fœtales</a></h2>

<img src="./img/echo.jpg" alt=""/>

<p>Une étude de l'Inserm auprès de 3 000 femmes enceintes montre que 30 % d'entre elles sont exposées à des solvants sur leur lieu de travail.</p>

<hr/>

</div>

<div class="article">

<h2 ><a href="" title="">Un nez électronique
pour détecter les gaz dangereux</a></h2>

<p>Cette machine, mise au point par des chercheur américains, peut donner l'alerte en moins de deux minutes en cas d'émanations immédiatement dangereuses pour la santé, voire pour la vie.</p>

<hr/>

</div>

<div class="article">
<img src="./img/grippe.jpg" alt="" style="float:right;"/>
<h2 ><a href="" title="">100.000 cas de grippe A
la semaine dernière</a></h2>

<p>Le seuil épidémique est dépassé en France. Au total, 147 malades ont été hospitalisés, dont 19 pour des formes graves.
</p>
<ul>
<li><a href="" title="">DOSSIER SPECIAL - Grippe A, l'alerte mondiale </a></li>
</ul>

<hr/>

</div>

<div class="article">
<h2 ><a href="" title="">Comment le virus H1N1
tue de jeunes adultes sains</a></h2>

<p>Comme tous les virus grippaux, le virus H1N1 peut induire des pneumonies graves, imprévisibles.</p>

<ul>
<li><a href="" title="">40 % des décès frappent des bien portants</a></li>
<li><a href="" title="">DOSSIER SPÃ‰CIAL - Grippe A, l'alerte mondiale</a></li>
</ul>

<hr/>

</div>

</td>

<td id="sidebar">

<form method="post" action="" style="text-align:center;margin-bottom:15px;">

Articles par mois :
<select id="mois" name="mois">
<option value=''> août 2009 </option>
<option value=''> juillet 2009 </option>
<option value=''> juin 2009 </option>
<option value=''> mai 2009 </option>
<option value=''> avril 2009 </option>
<option value=''> mars 2009 </option>
<option value=''> février 2009 </option>
<option value=''> janvier 2009 </option>
<option value=''> décembre 2008 </option>
<option value=''> novembre 2008 </option>
<option value=''> octobre 2008 </option>
<option value=''> septembre 2008 </option>
<option value=''> août 2008 </option>
<option value=''> juillet 2008 </option>
<option value=''> juin 2008 </option>
<option value=''> mai 2008 </option>
<option value=''> avril 2008 </option>
<option value=''> mars 2008 </option>
<option value=''> février 2008 </option>
<option value=''> janvier 2008 </option>
<option value=''> décembre 2007 </option>
<option value=''> novembre 2007 </option>
<option value=''> octobre 2007 </option>
<option value=''> septembre 2007 </option>
<option value=''> août 2007 </option>
<option value=''> juin 2007 </option>
<option value=''> mai 2007 </option>
<option value=''> avril 2007 </option>
<option value=''> mars 2007 </option>
<option value=''> février 2007 </option>
<option value=''> janvier 2007 </option>
<option value=''> septembre 2006 </option>
<option value=''> août 2006 </option>
<option value=''> juillet 2006 </option>
<option value=''> juin 2006 </option>
<option value=''> mai 2006 </option>
<option value=''> avril 2006 </option>
<option value=''> mars 2006 </option>
<option value=''> février 2006 </option>
<option value=''> janvier 2006 </option>
<option value=''> décembre 2005 </option>
</select>
</form>

<div style="border:1px solid #444;height:250px;margin-bottom:10px;background:orange;">
<p style="background:#444;color:#fff;padding:2px 4px;margin:0;font-size:0.7em;font-family: Arial, Helvetica, FreeSans, sans-serif;font-weight:bold;">Publicité</p>
<p style="text-align:center;color:#444;font-weight:bold;font-size:3.2em;margin-top:75px;">PUB</p>
</div>


</td>

</tr>

</table>

<? include("./blocs/pied_page.html"); ?>

</div>

</body>

</html>

