import java.net.MalformedURLException;
import java.rmi.*;

public class PersonServer {

	public PersonServer(){
		try {
			PersonServerImpl s=new PersonServerImpl();
			Naming.rebind("rmi://127.0.0.1:1099/Service",s);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} 
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new PersonServer();

	}

}
