<? include('./ressources/param_bd.php'); ?>
<? include('./ressources/modules_indexation.php'); ?>
<? include('./ressources/modules_recherche.php'); ?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Résultats de votre recherche</title>

<link rel="stylesheet" type="text/css" media="screen" href="./ressources/ecran.css" />

</head>

<body>

<?
   // RÉCUPÉRATION DES MOTS CLÉS
   $mots_cles_tous = $_GET["mots_cles_tous"];
   $mots_cles_plus = $_GET["mots_cles_plus"];
?>

<div class="titre">

<h1 style="text-align:center;">Résultats de votre recherche booléenne</h1>

<p>"<em>

<? 

   if($mots_cles_tous == "")
      echo $mots_cles_plus;
   else
      echo $mots_cles_tous;

?>

</em>"</p>

</div>

<?
   ini_set("memory_limit",'200M');
   set_time_limit(3600);
   
   // CONNEXION À LA BASE DE DONNÉES
   $id_cx = mysql_connect($hote,$admin,$mot_de_pass) or die ("<p style=\"color:red;\">Erreur de connexion</p>");
   mysql_select_db($bd_moteur,$id_cx);
   
   // AFFICHAGE DES RÉSULTATS EN HTML
   if($mots_cles_tous == "")
      recherche_booleenne_plus($mots_cles_plus);
   else
      recherche_booleenne_all($mots_cles_tous);
   
?>


<p style="text-align:center;"><a href="#" title="">Haut de page</a> - <a href="index.php" title="">Retour accueil</a></p>

</body>

</html>

