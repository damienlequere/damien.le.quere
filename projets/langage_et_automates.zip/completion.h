/**********************************************************************
* NOTE SUR CE FICHIER :
* Ce fichier contient le module COMPLETION et les fonctions necessaires
* a son fonctionnement.
***********************************************************************/

#include "mt.h"


// Predicat determinant si l'etat a une transition avec le symbole dans une liste de regles donnee
int existe_trans(char * etat, char * symbole, struct Liste_regle * regles);


/* COMPLETION : 
* Complete l'automate en modifiant la liste de regles et la liste d etats.
***********************************************************************/
void completion(struct Liste_chaine ** liste_etats_initiaux, 
                struct Liste_chaine ** liste_etats_finaux, 
                struct Liste_chaine ** liste_etats,
                struct Liste_chaine ** alphabet,
                struct Liste_regle ** liste_des_regles);
