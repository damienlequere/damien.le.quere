#include "completion.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Predicat determinant si l'etat a une transition avec le symbole dans une liste de regles donnee
int existe_trans(char * etat, char * symbole, struct Liste_regle * regles)
{
   int existe = 0;
   struct Liste_regle * regles_aux = regles;

   // On parcour les regles a la recherche d une transition correspondant a l etat et au symbole donnes
   while (regles_aux != NULL)
   {
      if (!strcmp(regles_aux->la_regle.etat_depart, etat) &&
          !strcmp(regles_aux->la_regle.symbole, symbole)) 
         {existe = 1;}
      regles_aux = regles_aux->regle_suivante;
   }
   return existe;
}


/* COMPLETION : 
* Complete l'automate en modifiant la liste de regles et la liste d etats.
***********************************************************************/
void completion(struct Liste_chaine ** liste_etats_initiaux, 
                struct Liste_chaine ** liste_etats_finaux, 
                struct Liste_chaine ** liste_etats,
                struct Liste_chaine ** alphabet,
                struct Liste_regle ** liste_des_regles)
{
   // Pour chaque etat et chaque symbole , on ajoute dans la liste de regles
   // une transition de cet etat avec ce symbole vers l etat puits si il n y a 
   // pas de transition deja existante dans la liste des regles. 
   struct Liste_chaine * etats_aux = *liste_etats;
   while(etats_aux != NULL){
      struct Liste_chaine * alphabet_aux = *alphabet;
      while(alphabet_aux != NULL){
         if(!existe_trans(etats_aux->chaine,alphabet_aux->chaine,*liste_des_regles)){
            struct Regle r;
            r.etat_depart=etats_aux->chaine;
            r.symbole=alphabet_aux->chaine;
            r.etat_arrive="p";
            ajout_regle_dans_liste(r,liste_des_regles);
         }
         alphabet_aux = alphabet_aux->chaine_suivante;
      }
      etats_aux = etats_aux->chaine_suivante;
   }

   // On ajoute l etat puits dans la liste d etats
   ajout_liste_en_queue("p",liste_etats);

   // ainsi que ces regles
   struct Liste_chaine * alphabet2_aux = *alphabet;
   while(alphabet2_aux != NULL)
   {
      struct Regle r2;
      r2.etat_depart="p";
      r2.symbole=alphabet2_aux->chaine;
      r2.etat_arrive="p";
      ajout_regle_dans_liste(r2,liste_des_regles);
      alphabet2_aux = alphabet2_aux->chaine_suivante;
   }

}
