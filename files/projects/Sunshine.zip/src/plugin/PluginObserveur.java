package plugin;

/**
 * Cette classe permet d'implementer la deuxieme partie du pattern observeur
 * dans nos plugins.
 * @author stephane
 */
public interface PluginObserveur extends Plugin {
	/**
	 * Met a jour les donnees recues depuis l'observable.
	 * @param o Les donnees recues depuis l'observable.
	 */
	void update(Object o);
}
