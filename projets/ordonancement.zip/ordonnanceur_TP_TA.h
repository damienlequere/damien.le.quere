#ifndef ORDONNANCEUR_TP_TA_H_INCLUDED
#define ORDONNANCEUR_TP_TA_H_INCLUDED

#include"RM.h"
#include"EDF.h"
#include"gestionnaire_stats.h"

class Ordonnanceur_TP_TA{

    public:

    static TacheSimulation *next_tache(list<TacheSimulation*>* listTachesPeriodiques,list<TacheSimulation*>* listTachesAperiodiques, int t,Gestionnaire_stats &g);

    protected:

    static TacheSimulation *next_TA(list<TacheSimulation*>* listTachesAperiodiques, int t){
        TacheSimulation *resultat = NULL;
        list<TacheSimulation*>::iterator it;
        for(it = listTachesAperiodiques->begin(); it != listTachesAperiodiques->end(); it++){
            if ((resultat == NULL) && ((*it)->ci_restant != 0))
                resultat = *it;
            else{
                if  ((*it)->ci_restant != 0)
                    if( temps_restant((*it)->t,t) < temps_restant(resultat->t,t) )
                        resultat = *it;
                }
            }
        return resultat;
    };

    private:

    static int temps_restant(Tache tache, int t){
        return ((t / tache.getPi()) * tache.getPi() + tache.getDi()) - t;
        };

    };

#endif // ORDONNANCEUR_TP_TA_H_INCLUDED
