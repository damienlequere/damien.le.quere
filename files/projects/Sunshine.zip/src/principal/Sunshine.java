package principal;

import java.util.logging.Level;

import modele.Modele;

import controleur.Controleur;

import vue.Fenetre;

/**
 * Classe du programme principal, elle contient la methode main
 * et elle est chargee d'instancier puis de relier les classes de 
 * notre pattern M.V.C.
 * @author stephane
 */
public final class Sunshine {
	
	/**
	 * Niveau de precision du logger du projet.
	 */
	public static final Level LEVEL = Level.INFO;
	
	/**
	 * Constructeur par defaut en privee comme pour toute classe utilitaire.
	 */
	private Sunshine() {	
	}
	
	/**
	 * Lance le programme.
	 * @param args Les arguments d'entree du programme.
	 */
	public static void main(String[] args) {
		Fenetre fenetre = new Fenetre();
		Controleur controleur = new Controleur();
		Modele modele = new Modele();
		
		controleur.setModele(modele);
		fenetre.setControleur(controleur);
		modele.addObserveur(fenetre);
		
		fenetre.initialiser();
	}
}
