#ifndef EDFEDL_H_INCLUDED
#define EDFEDL_H_INCLUDED

#include"ordonnanceur_TP_TA.h"

class EDFEDL : public Ordonnanceur_TP_TA{

    public:

    EDFEDL(TacheSimulation *T_EDL){
        _T_EDL = T_EDL;
        };

    TacheSimulation *next_tache(list<TacheSimulation*>* listTachesPeriodiques,list<TacheSimulation*>* listTachesAperiodiques, int t,Gestionnaire_stats &g){
        TacheSimulation *resultat;

        //on regarde si des tâches apériodiques se sont réveillées
        //si oui on exécute la prochaîne tâche apériodique
        //sinon on exécute la prochaîne tâche périodique

        if(next_TA(listTachesAperiodiques,t) != NULL){
            if( (next_TA(listTachesAperiodiques,t)->t.getDi() == 0) &&
                (next_TA(listTachesAperiodiques,t)->ci_restant == next_TA(listTachesAperiodiques,t)->t.getCi()) )
                    g.ajout_temps_reponse_TAPNC( t - next_TA(listTachesAperiodiques,t)->t.getRi() );
            resultat = _T_EDL;
            next_TA(listTachesAperiodiques,t)->ci_restant--;
            }
        else
            resultat = EDF::next_TP(listTachesPeriodiques,t);

        return resultat;
        };

    private:

    TacheSimulation *_T_EDL;


};


#endif // EDFEDL_H_INCLUDED
