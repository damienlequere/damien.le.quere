package test.junit.xml;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import xml.ControleParSchema;

/**
 * @author stephane
 *
 */
public class ControleParSchemaTest {
	/**
	 * Le controle a tester.
	 */
	private ControleParSchema controle;
	
	/**
	 * Initialisation du test.
	 * @see junit.framework.TestCase#setUp()
	 */
	@BeforeMethod
	@Before
	public void setUp() {
		this.controle = new ControleParSchema(System.getProperty("user.dir")+"/resources/plugin.xsd");
	}
	
	/**
	 * Test de la methode estValide.
	 */
	@org.testng.annotations.Test(groups="xml")
	@Test
	public void testEstValide() {
		File fichier = new File(controle.getAdresse());
		String extensionFichier = controle.getAdresse().substring(controle.getAdresse().length()-4);
		assertTrue("Le fichier n'existe pas", fichier.exists());
		assertTrue("Le fichier est un repertoire", fichier.isFile());
		assertTrue("Le fichier n'a pas l'extension xsd", extensionFichier.equalsIgnoreCase(".xsd"));
		assertFalse("Le jar est valide avec un classe loader null", controle.estValide(System.getProperty("user.dir")+"/resources/plugin.xml", null));
	}
	
	/**
	 * Test de la methode parametreXml.
	 */
	@org.testng.annotations.Test(groups="xml")
	@Test
	public void testParametreXml() {
		assertNull("On obtient des parametres d'un xml provenant d'un classe loader null", controle.parametreXml(System.getProperty("user.dir")+"/resources/plugin.xml", null));
	}

}
