package plugin;

/**
 * Cette interface permet l'inplementation du pattern observeur
 * dans nos plugins.
 * @author stephane
 */
public interface PluginObservable extends Plugin {
	/**
	 * Ajoute un nouvel observateur sur le modele.
	 * @param o L'observeur a ajouter.
	 */
	void addObserveur(PluginObserveur o);
	
	/**
	 * Supprime un observateur du modele.
	 * @param o L'observateur a supprimer.
	 */
	void removeObserveur(PluginObserveur o);
	
	/**
	 * Informer les observateurs en leur transmettant eventuellement une donne.
	 * @param o La donnee a transmettre dans la notification.
	 */
	void notifyObserveur(Object o);
}
