package decouverte.parcours;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.logging.Level;
import java.util.logging.Logger;

import principal.Sunshine;

/**
 * Le ParcoureurDeJar a pour but d'ouvrir les fichiers jar et de les
 * charger afin de pouvoir les transmettre a un GestionnaireDeFichiers
 * qui appliquera un algorithme sur le contenu de ce jar.
 * @author stephane
 */
public class ParcoureurDeJar {
	/**
	 * Le logger de ParcoureurDeJar.
	 */
	private static final Logger LOGGER = Logger.getLogger("decouverte.parcours.ParcoureurDeJar");
	
	/**
	 * Le jar en cours d'examen.
	 */
	private final String jar;
	
	/**
	 * Le type de gestionnaire du traitement a appliquer sur les fichiers du jar.
	 */
	private final GestionnaireTypeEnum typeGestionnaire;
	
	/**
	 * Constructeur par defaut.
	 * @param jar Le jar en cours d'examen
	 * @param typeGestionnaire Le type de gestionnaire a appliquer sur les fichiers du jar.
	 */
	public ParcoureurDeJar(String jar, GestionnaireTypeEnum typeGestionnaire) {
		
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "ParcoureurDeJar", e);
		}
		
		this.jar = jar;
		this.typeGestionnaire = typeGestionnaire;
	}
	
	/**
	 * Parcours toutes les fichiers du jar et applique un traitement sur chaque fichier.
	 * @return Le gestionnaire de fichier apres traitement des donnees.
	 */
	public GestionnaireDeFichiers traiter() {
		LOGGER.entering(this.getClass().getName(), "traiter");
		
		GestionnaireDeFichiers gestionnaire = null;
		File fichier = new File(jar);
		try
		{
			URL u = fichier.toURI().toURL();
			URLClassLoader loader = new URLClassLoader(new URL[] {u});
			
			switch(this.typeGestionnaire)
			{
			case GestionJarValideSansXml:
				gestionnaire = new GestionJarValideSansXml(fichier, loader);
				break;
			case GestionJarValideAvecXml:
				gestionnaire = new GestionJarValideAvecXml(fichier, loader);
				break;
			case GestionPutProgrammeSansXml:
				gestionnaire = new GestionPutProgrammeSansXml(fichier, loader);
				break;
			case GestionPutProgrammeAvecXml:
				gestionnaire = new GestionPutProgrammeAvecXml(fichier, loader); 
				break;
			default:
				LOGGER.log(Level.INFO, "Gestionnaire de fichier inconnu");
				break;
			}

		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "traiter", e);
		}
		
		LOGGER.exiting(this.getClass().getName(), "traiter", gestionnaire);
		return gestionnaire;
	}
}
