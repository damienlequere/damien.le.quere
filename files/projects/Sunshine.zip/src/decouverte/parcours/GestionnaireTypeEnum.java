package decouverte.parcours;

/**
 * L'enumeration GestionnaireTypeEnum permet de lister
 * les differents types de classe implementant la classe
 * abstraite GestionnaireDeFichiers. Ainsi on peut facilement
 * utiliser un switch / case dans le parcoureur de jar. 
 * @author stephane
 */
public enum GestionnaireTypeEnum {
	/**
	 * Renvoie un boolean indiquant si le jar est valide sans traitement avec XML.
	 */
	GestionJarValideSansXml,
	
	/**
	 * Renvoie un boolean indiquant si le jar est valide avec traitement avec XML.
	 */
	GestionJarValideAvecXml,
	
	/**
	 * Parse le jar pour trouver les programmes mais sans XML.
	 */
	GestionPutProgrammeSansXml,
	
	/**
	 * Parse le jar pour trouver les programmes avec un fichier XML.
	 */
	GestionPutProgrammeAvecXml
}
