package plugin;

/**
 * L'interface de modele abstrait defini les methodes a implementer
 * par la partie modele d'un de nos plugins.
 * @author stephane
 */
public interface ModeleAbstrait extends PluginObservable {
	/**
	 * Permet de changer l'operateur pour l'operation que doit effectuer le modele.
	 * @param operateur L'operateur de l'operation a effectuer.
	 */
	void setOperateur(String operateur);
	
	/**
	 * Permet de changer le(s) argument(s) de l'operation.
	 * @param argument Le(s) argument(s) de l'operation.
	 */
	void setArguments(Object argument);
	
	/**
	 * Declenche l'operation initialisee sur le modele.
	 */
	void effectueOperation();
}
