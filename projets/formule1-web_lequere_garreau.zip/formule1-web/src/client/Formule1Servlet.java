package client;


import java.io.IOException;
import java.rmi.Naming;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.ResultServerInterface;


/**
 * Servlet implementation class Formule1Servlet
 */
public class Formule1Servlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    private ResultServerInterface resultDistant;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Formule1Servlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	
    	/*==============================================*/
    	/* RECUPERATION DE L'OBJET DISTANT RESULTSERVER */
    	/*==============================================*/
    	try{ resultDistant = (ResultServerInterface) Naming.lookup("rmi://localhost:1099/ResultsCourse");}
	    catch(Exception e){
	        System.out.println("Probleme lors du naming lookup de RMI \n" + e.getMessage());
	        e.printStackTrace();
	    }
	    
	    /*===============================================*/
	    /* CONSTRUCTION DU TABLEAU DE CLASSEMENT GENERAL */
	    /*===============================================*/
	    Vector<Integer> classementPilotes = new Vector<Integer>();
	    try { classementPilotes = resultDistant.classement(); }
	    catch (SQLException e) {
	        System.out.println("Pb lors de l'appel de la fonction classement() sur l'objet distant\n" + e.getMessage());    
	    	e.printStackTrace();
	    }
	    
	    // Construction des lignes HTML du tableau
	    Vector<String> lignesTableClassement = new Vector<String>();
	    String ligneCourante = "";
	    Integer classement = 1;
	    try {
		    for(Integer numP : classementPilotes){
		    	Integer dernierTourPilote = resultDistant.getDernierTour(numP);
		    	Float tempsAuTourPilote = resultDistant.getTempsTour(numP, dernierTourPilote);
		    	Float meilleurTempsPilote = resultDistant.getMeilleurTemps(numP);
		    	Float meilleurTempsGeneralTour = resultDistant.getMeilleurTempsTour(dernierTourPilote);
		    	Integer dernierTourPremier = resultDistant.getNbTourPremier();
		    	Float distanceAuPremier = dernierTourPilote.floatValue() / dernierTourPremier.floatValue();
		    
		    	ligneCourante = "";
				ligneCourante = "<tr>";
				ligneCourante += "<td>";
				if(distanceAuPremier < 0.9)
					ligneCourante += "NC";
				else
					ligneCourante += classement;
				ligneCourante += "</td>";
				ligneCourante += "<td>" + numP + "</td>";
				ligneCourante += "<td><a href=\"http://localhost:8080/formule1-web/Formule1Servlet?num_pilote="+numP+"\" title=\"\">" + resultDistant.getNom(numP) + "</a></td>";
				ligneCourante += "<td";
				if(tempsAuTourPilote.equals(meilleurTempsPilote) && tempsAuTourPilote.equals(meilleurTempsGeneralTour) )
					ligneCourante += " style=\"font-weight:bold;color:purple;\"";
				else if(tempsAuTourPilote.equals(meilleurTempsPilote))
					ligneCourante += " style=\"font-weight:bold;color:green;\"";
				ligneCourante += ">" + resultDistant.getDernierTemps(numP) + "</td>";
				ligneCourante += "<td>" + resultDistant.getMeilleurTemps(numP) + "</td>";
				ligneCourante += "</tr>";
				lignesTableClassement.add(ligneCourante);
				classement++;
		    }
	    } catch (SQLException e) {
			System.out.println("Probleme SQL lors de la construction du tableau des resultats generaux\n" + e.getMessage());
			e.printStackTrace();
		}
	    
	    /*=====================================*/
	    /* CONSTRUCTION DU TABLEAU D'UN PILOTE */
	    /*=====================================*/
	    Integer numP = 0;
	    String nomP = "";
	    Float moyenne = new Float(0);
	    Vector<String> ligneTablePilote = new Vector<String>();
	    if(request.getParameter("num_pilote")!= null){
	    	try {
		    	// Récupération du numero du pilote
		    	numP = Integer.parseInt(request.getParameter("num_pilote"));
		    	nomP = resultDistant.getNom(numP);
		    	moyenne = resultDistant.getMoyenne(numP);
				String ligneCourante2 = "";
			    for(Integer tour = resultDistant.getDernierTour(numP); tour >= 1;tour--){
			    	ligneCourante2 = "";
					ligneCourante2 += "<tr><td>" + tour + "</td>";
					ligneCourante2 += "<td>" + resultDistant.getPositionTour(numP, tour) + "</td>";
					ligneCourante2 += "<td>" + resultDistant.getTempsTour(numP,tour) + "</td>";
					ligneCourante2 += "<td>" + resultDistant.getTempsTotalTour(numP,tour) + "</td>";
					ligneCourante2 += "</tr>";
					ligneTablePilote.add(ligneCourante2);
			    }
			}
	    	catch (SQLException e) {
				System.out.println("Probleme SQL lors de la construction du tableau des resultats generaux\n" + e.getMessage());
				e.printStackTrace();
				}
	    }
	    
	    
	    /*==========================================*/
	    /* ENVOI DES RESULTATS AUX PAGES DYNAMIQUES */
	    /*==========================================*/
	   
	    // Pas de parametre = on envoi le classement general
	    if(request.getParameter("num_pilote")== null){
	    	request.setAttribute("lignesTableClassement", lignesTableClassement);
		    RequestDispatcher disp = getServletContext().getRequestDispatcher("/global_results.jsp");
		    disp.forward(request, response);
	    }
	    // Sinon on envoi les performances du pilote passe en parametre
	    else{
	    	request.setAttribute("numP", numP);
	    	request.setAttribute("nomP", nomP);
	    	request.setAttribute("moyenne", moyenne);
	    	request.setAttribute("ligneTablePilote", ligneTablePilote);
		    RequestDispatcher disp = getServletContext().getRequestDispatcher("/details_results.jsp");
		    disp.forward(request, response);
	    }
	    
    }
    
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}
}
