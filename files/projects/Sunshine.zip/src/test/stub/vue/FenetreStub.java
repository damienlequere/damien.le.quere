package test.stub.vue;

import java.util.HashMap;
import java.util.logging.Logger;

import plugin.Programme;
import principal.Sunshine;

import vue.Fenetre;

/**
 * Stub de la fenetre.
 * @author stephane
 */
@SuppressWarnings("serial")
public class FenetreStub extends Fenetre {
	/**
	 * Le logger du stub de Fenetre.
	 */
	private static final Logger LOGGER = Logger.getLogger("test.stub.vue.FenetreStub");
	
	/**
	 * Constructeur.
	 */
	public FenetreStub() {
		super();
		try
		{
			LOGGER.setLevel(Sunshine.LEVEL);
		}
		catch (Exception e)
		{
			LOGGER.throwing(this.getClass().getName(), "FenetreStub", e);
		}
	}
	
	/**
	 * Renvoie le programme associe au nom donne en parametre.
	 * @param nom Le nom du programme desire.
	 * @return Le programme associe au nom.
	 */
	public Programme getProgramme(String nom) {
		LOGGER.entering(this.getClass().getName(), "getProgramme", nom);
		
		Programme p = new Programme(nom, "1.0"); 
		
		LOGGER.exiting(this.getClass().getName(), "getProgramme", p);
		return p;
	}
	
	/**
	 * Met a jour les donnees recu depuis l'observable.
	 * @param o Donnees recu depuis l'observable.
	 * @see observeur.Observeur#update(java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	public void update(Object o) {
		LOGGER.entering(this.getClass().getName(), "update", o);
		
		HashMap<String, Programme> map = (HashMap<String, Programme>) o;
		LOGGER.log(Sunshine.LEVEL, "Valeur recuperee par la fenetre : ", map);
		
		LOGGER.exiting(this.getClass().getName(), "update");
	}
}
