#include"simulateur.h"


Simulateur::Simulateur(int duree):_gestionnaire_statistiques(duree){
    _dureeSim = duree;
    _historiqueSimulation = new string[_dureeSim];
    };


void Simulateur::simuler_ordonnancement(ListeTaches *lstTaches,int typeOrd,int dureeSim){

        /*===============================*/
        /*== TRAITEMENTS PRÉLIMINAIRES ==*/
        /*===============================*/

        // On créer une liste associant les taches de la liste à un ci_restant
        // ce sera sur cette liste que l'on travaillera
        list<Tache>::const_iterator it_const;
        list<TacheSimulation*> *lstTachesSimulation = new list<TacheSimulation*>();
        for(it_const = lstTaches->getTaches()->begin(); it_const != lstTaches->getTaches()->end(); it_const ++){
            TacheSimulation *tache_temp = new TacheSimulation;
            tache_temp->t = *it_const;
            tache_temp->ci_restant = it_const->getCi();
            lstTachesSimulation->push_back(tache_temp);
            if(it_const->getRi() == 0)
                tache_temp->ci_restant = it_const->getCi();
            else
                tache_temp->ci_restant = 0;
        }

        list<TacheSimulation*>::const_iterator it_const2;
        // On créer une liste auxiliaire pointant uniquement vers les tâches périodiques
        list<TacheSimulation*> *lstTachesPeriodiques = new list<TacheSimulation*>();
        for(it_const2 = lstTachesSimulation->begin(); it_const2 != lstTachesSimulation->end(); it_const2 ++){
            if((*it_const2)->t.getPi() != 0){;
                lstTachesPeriodiques->push_back(*it_const2);
            }
        }
        // On créer une liste auxiliaire pointant uniquement vers les tâches apériodiques
        list<TacheSimulation*> *lstTachesAperiodiques = new list<TacheSimulation*>();
        for(it_const2 = lstTachesSimulation->begin(); it_const2 != lstTachesSimulation->end(); it_const2 ++){
            if((*it_const2)->t.getPi() == 0){;
                lstTachesAperiodiques->push_back(*it_const2);
            }
        }


        /*==========================================*/
        /*== traitements préliminaires pour RM-PS ==*/
        /*==========================================*/

        //on calcul la valeur maximum du ratio cs sur ts
        //selon le critère d'ordonnancabilité de RM-PS
        int nb_tp = lstTaches->nb_taches_periodiques();
        float somme_ci_pi = lstTaches->somme_ci_sur_pi(),
              borne_ratio_cs_ts = ((nb_tp + 1) * (pow(2,1./(nb_tp+1))-1)) - somme_ci_pi;

        int Cs,Ts;

        //on demande à l'utilisateur de proposer les valeur Cs et Ts, en lui signalant toutefois si
        //ses paramètres ne permettent pas à coup sûr l'ordonnancabilité des tâches
        if(typeOrd == 4){
            cout << "** Configuration du polling server **" << endl << endl;
            cout << "Ratio MAX : " << borne_ratio_cs_ts << endl;
            cout << "Donnez Cs : "; cin>>Cs;
            cout << "Donnez Ts : "; cin>>Ts;

            while( ((float)Cs / (float)Ts) >=  borne_ratio_cs_ts){
                cout << "Le ratio Cs/Ts que vous avez fourni est supérieur à " << borne_ratio_cs_ts << " et ne garanti pas l'ordonnancabilité avec RM-PS" << endl << endl;
                cout << "Ratio MAX : " << borne_ratio_cs_ts << endl;
                cout << "Donnez Cs : "; cin>>Cs;
                cout << "Donnez Ts : "; cin>>Ts;
                }
            }

        /* Construction de la tâche périodique associée au polling server */
        TacheSimulation *TP_PS = new TacheSimulation();

        Tache tache_temp("PS",0,Cs,Ts,Ts);
        TP_PS->ci_restant = Cs;
        TP_PS->t = tache_temp;

        //construction de l'ordonnanceur PS
        RMPS ordoPS(TP_PS);

        //on ajoute la tâche périodique associée à PS aux tâches périodiques
        //si l'ordonnancement est de type RM-PS
        if(typeOrd == 4)
            lstTachesPeriodiques->push_back(TP_PS);

        /*============================================*/
        /*== traitements préliminaires pour EDF-EDL ==*/
        /*============================================*/

        /* Construction de la tâche apériodique associée au serveur EDL */
        TacheSimulation *T_EDL = new TacheSimulation();

        Tache tache_temp2("EDL",0,0,0,0);
        T_EDL->ci_restant = 0;
        T_EDL->t = tache_temp2;

        //construction de l'ordonnanceur EDL
        EDFEDL ordoEDL(T_EDL);

        /*==============================================================*/


        /*================*/
        /*== SIMULATION ==*/
        /*================*/

        cout << "Simulation en cours ..." << endl << endl;
        TacheSimulation *tache_precedante = NULL;
        for(int t=0; t < _dureeSim; t++){

            // A chaque instant t, on remet le ci_restant des taches se reveillant à leur valeur de ci
            // (aussi bien les tâches périodiques que apériodiques)
            list<TacheSimulation*>::iterator it;
            for( it = lstTachesSimulation->begin(); it != lstTachesSimulation->end(); it ++ ){
                if((*it)->t.getPi() !=0){
                    if(t%(*it)->t.getPi() == (*it)->t.getRi())
                        (*it)->ci_restant = (*it)->t.getCi();
                }
                else{
                    if(t == (*it)->t.getRi())
                        (*it)->ci_restant = (*it)->t.getCi();
                }
            }

            // On recherche la tache restant à exécuter selon le type d'ordonnancement
            TacheSimulation *tache_a_executer = NULL;
            switch(typeOrd){
                case 1 :    /* Ordonnancement RM */
                {
                    tache_a_executer = RM::next_TP(lstTachesPeriodiques,t);
                }
                case 2 :    /* Ordonnancement EDF */
                {
                    tache_a_executer = EDF::next_TP(lstTachesPeriodiques,t);
                }
                break;
                case 4 :    /* Ordonnancement RM-PS */
                {
                    tache_a_executer = ordoPS.next_tache(lstTachesPeriodiques,lstTachesAperiodiques,t,_gestionnaire_statistiques);
                }
                break;
                case 5 :    /* Ordonnancement EDF-EDL */
                {
                    tache_a_executer = ordoEDL.next_tache(lstTachesPeriodiques,lstTachesAperiodiques,t,_gestionnaire_statistiques);
                }
                break;
                case 6 :   /* Ordonnancement RM-BG */
                {
                    tache_a_executer = BG::next_tache("RM",lstTachesPeriodiques,lstTachesAperiodiques,t,_gestionnaire_statistiques);
                }
                break;
                case 7 :   /* Ordonnancement EDF-BG */
                {
                    tache_a_executer = BG::next_tache("EDF",lstTachesPeriodiques,lstTachesAperiodiques,t,_gestionnaire_statistiques);
                }
                break;
                default :
                {
                    cout << "! erreur dans le choix du type d'ordonnancement !" << endl;
                }
                break;
            }


            // Si on trouve une tache on l'execute durant un slot time
            // Sinon on marque un temps creux
            if (tache_a_executer != NULL){
                _historiqueSimulation[t] = tache_a_executer->t.getId();
                if(tache_a_executer->ci_restant > 0)
                    tache_a_executer->ci_restant--;
            }else{
                _historiqueSimulation[t] = TEMP_CREUX;
                _gestionnaire_statistiques.ajout_temps_creux();
                }


            //on cherche s'il y a une préemption pour le gestionnaire de statistiques
            if((tache_a_executer != NULL) && (tache_precedante != NULL))
                if( (tache_a_executer->t.getId() != tache_precedante->t.getId()) &&  (tache_precedante->ci_restant != 0) )
                    _gestionnaire_statistiques.ajout_preemption();

            //puis la tâche précédante passe à la tâche courante
            tache_precedante = tache_a_executer;

        }
};

void Simulateur::afficher_resultats_simulation(ostream &os){
    os << "Chronogramme résultant de la simulation :" << endl;
    os << "|";

    for(int cpt = 0;cpt < _dureeSim;cpt++)
        os << _historiqueSimulation[cpt] << '|';

    os << endl << endl;

    cout << "** Statistiques *********************" << endl << endl;
    cout << "   Durée de simulation  : " << _dureeSim << endl;
    cout << "   Temps CPU total      : " << _gestionnaire_statistiques.temps_CPU() << endl;
    cout << "   Nombre de péemptions : " << _gestionnaire_statistiques.nb_preemptions() << endl;
    cout << "   Taux de péemption    : " << _gestionnaire_statistiques.taux_preemption() << '%' << endl;
    cout << "   Temps de réponse moyen des tâches apériodiques non critiques : "
         << _gestionnaire_statistiques.temps_reponse_moyen_TAPNC() << endl << endl;
    cout << "*************************************" << endl;
    };
