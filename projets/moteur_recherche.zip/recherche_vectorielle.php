<? include('./ressources/param_bd.php'); ?>
<? include('./ressources/modules_indexation.php'); ?>
<? include('./ressources/modules_recherche.php'); ?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Résultats de votre recherche</title>

<link rel="stylesheet" type="text/css" media="screen" href="./ressources/ecran.css" />

</head>

<body>

<?
   // RÉCUPÉRATION DES MOTS CLÉS
   $mots_cles = $_GET["mots_cles_vect"];
?>

<div class="titre">

<h1 style="text-align:center;">Résultats de votre recherche vectorielle</h1>

<p>"<em><? echo $mots_cles; ?></em>"</p>

</div>

<?
   ini_set("memory_limit",'200M');
   set_time_limit(3600);
   
   // TRAVAIL PRÉLIMINAIRE : remmplir un tableau associatif terme->stem (sans les stopwords)
   //$tableau_stems = remplir_tab_stems("./ressources/stem.txt","./ressources/stopwords.txt");

   // CONNEXION À LA BASE DE DONNÉES
   $id_cx = mysql_connect($hote,$admin,$mot_de_pass) or die ("<p style=\"color:red;\">Erreur de connexion</p>");
   mysql_select_db($bd_moteur,$id_cx);
   
   // AFFICHAGE DES RÉSULTATS EN HTML
   recherche_vectorielle_docs($mots_cles);
   
?>


<p style="text-align:center;"><a href="#" title="">Haut de page</a> - <a href="index.php" title="">Retour accueil</a></p>

</body>

</html>

