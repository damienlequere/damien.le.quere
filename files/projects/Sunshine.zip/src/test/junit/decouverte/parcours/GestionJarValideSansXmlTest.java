package test.junit.decouverte.parcours;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import org.junit.Before;
import org.junit.Test;
import org.testng.annotations.BeforeMethod;

import decouverte.parcours.GestionJarValideSansXml;
import decouverte.parcours.GestionnaireDeFichiers;

/**
 * @author stephane
 *
 */
public class GestionJarValideSansXmlTest {
	/**
	 * Le gestionnaire de fichiers a tester.
	 */
	private GestionnaireDeFichiers gestionnaire;
	
	/**
	 * Initialisation des tests.
	 * @throws MalformedURLException Si l'URL est mal formulee.
	 */
	@BeforeMethod
	@Before
	public void setUp() throws MalformedURLException {
		File fichier = new File(System.getProperty("user.dir")+"/plugins/calcul.jar");
		
		URL u = fichier.toURI().toURL();
		URLClassLoader loader = new URLClassLoader(new URL[] {u});
		this.gestionnaire = new GestionJarValideSansXml(fichier, loader);
	}

	/**
	 * Test de la methode getResultats.
	 * @throws IOException Si le fichier n'est pas trouve.
	 * @throws ClassNotFoundException Si la classe n'est pas trouvee dans le classe loader.
	 */
	@org.testng.annotations.Test(groups="decouverte.parcours")
	@Test
	public void testGetResultats() throws ClassNotFoundException, IOException {
		assertTrue("Le jar n'a pas ete valide", (Boolean) this.gestionnaire.getResultats());
	}

}
