#include "afdet.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/* Modules utilises pour les listes de listes **************/
/***********************************************************/

// Ajout en tete d une liste de listes
void ajout_liste_de_listes(struct Liste_chaine * liste_a_ajouter,
                           struct Liste_de_listes ** liste)
{
   struct Liste_de_listes * precedent;
   precedent = (struct Liste_de_listes*)malloc(sizeof(struct Liste_de_listes));
   precedent->pt_liste_etats = liste_a_ajouter;
   precedent->pt_liste_suivante = *liste;
   *liste = precedent;
}

// Ajout en queue d une liste de listes
void ajout_liste_de_listes_en_queue(struct Liste_chaine * liste_a_ajouter,
                                    struct Liste_de_listes ** liste)
{
   struct Liste_de_listes * suivant;
   suivant = (struct Liste_de_listes*)malloc(sizeof(struct Liste_de_listes));
   suivant->pt_liste_etats = liste_a_ajouter;
   suivant->pt_liste_suivante = NULL;

   struct Liste_de_listes * liste_aux = *liste;

   if(liste_aux == NULL)
   {
      *liste = suivant;
   }else{
      while ((liste_aux)->pt_liste_suivante != NULL)
      {
         liste_aux = liste_aux->pt_liste_suivante;
      }
      liste_aux->pt_liste_suivante = suivant;
   }
}


// Affichage d une liste de listes de chaines
void affiche_liste_de_listes(struct Liste_de_listes * liste)
{
   printf("%s", "******************************\n");
   while (liste != NULL){
      affiche_liste_chaine(liste->pt_liste_etats);
      liste = liste->pt_liste_suivante;
   }
   printf("%s", "******************************\n");
}


// Predicat determinant si la liste de chaines liste apartient (d un point de vue ensembliste) a ll
int est_liste_de_liste(struct Liste_chaine * liste,
                       struct Liste_de_listes * ll)
{
   struct Liste_de_listes * ll_aux = ll;
   int apartient = 0;
   
   while (ll_aux != NULL)
   {
      if (compare_listes_chaines(liste,ll_aux->pt_liste_etats)){apartient = 1;}
      ll_aux = ll_aux->pt_liste_suivante;
   }
   return apartient;
}

// Fonction retournant la liste equivalente recherchee dans la liste de liste
// (Equivalence d un point de vue ensembliste) 
struct Liste_chaine * recherche_liste(struct Liste_chaine * liste,
                                      struct Liste_de_listes * ll)
{
   struct Liste_de_listes * ll_aux = ll;
   struct Liste_chaine * res = NULL;
   int trouve = 0;
   
   while ((ll_aux != NULL) && (trouve == 0))
   {
      if (compare_listes_chaines(liste,ll_aux->pt_liste_etats))
      {
         trouve = 1;
         res = ll_aux->pt_liste_etats;
      }
      ll_aux = ll_aux->pt_liste_suivante;
   }
   return res;
}

// Predicat determinant si deux listes_de_listes sont identiques
int sont_listes_de_listes_identiques(struct Liste_de_listes * listeA,
                                     struct Liste_de_listes * listeB)
{
	if(listeA==NULL && listeB == NULL){
		return 1;
	} else {
		if(listeA==NULL || listeB == NULL){
			return 0;
		} else {
			struct Liste_chaine * l_auxA = listeA->pt_liste_etats;
			struct Liste_chaine * l_auxB = listeA->pt_liste_etats;
			return (sont_listes_de_listes_identiques(listeA->pt_liste_suivante, listeB->pt_liste_suivante) && compare_listes_chaines(l_auxA,l_auxB));
		}
	}
}


/* Modules utilises pour la determinisation **************/
/*********************************************************/


/* EPSILON FERMETURE : 
* Fonction retournant les etats formant l epsilon fermeture d une liste
* d etats. C est a dire les etats eux-memes, ainsi que tous les etats
* accessibles avec une ou plusieurs epsilon-transitions.
***********************************************************************/
struct Liste_chaine * epsilon_fermeture(struct Liste_chaine * etats,
                                        struct Liste_regle * regles)
{
   // On declare une nouvelle liste d etats correspondant aux etats fermetures
   struct Liste_chaine * etats_fermeture = NULL;

   // On commence par ajouter les etats eux memes
   struct Liste_chaine * etats_aux = etats;
   while(etats_aux != NULL){
      ajout_liste_en_queue(etats_aux->chaine,&etats_fermeture);
      etats_aux = etats_aux->chaine_suivante;
   }

   // On ajoute ensuite des etats dans la liste des etats fermetures
   struct Liste_chaine * etats_fermeture_aux = etats_fermeture;
   while(etats_fermeture_aux != NULL){
      struct Liste_regle * regles_aux = regles;
      while(regles_aux != NULL){
         if ( (!strcmp(etats_fermeture_aux->chaine,regles_aux->la_regle.etat_depart) && (!strcmp(regles_aux->la_regle.symbole,"")) ) &&
              (!est_mot_de_la_liste(etats_fermeture,regles_aux->la_regle.etat_arrive)) )
         {
              ajout_liste_en_queue(regles_aux->la_regle.etat_arrive,&etats_fermeture);
         }
         regles_aux = regles_aux->regle_suivante;
      }
      etats_fermeture_aux = etats_fermeture_aux->chaine_suivante;
   }
   return etats_fermeture;
}


/* TRANSITION : 
* Fonction retournant les etats accessibles depuis d'autres etats avec 
* un symbole donne. C est a dire l epsilon-fermeture des etats auquels 
* on peut acceder depuis les etats donnes avec le symbole donne.
***********************************************************************/
struct Liste_chaine * Transition(struct Liste_chaine * etats,
                                 char * symbole,
                                 struct Liste_regle * regles)
{
   struct Liste_chaine * etats_accessibles = NULL;
   struct Liste_chaine * etats_aux = etats;
   
   while(etats_aux != NULL)
   {
      struct Liste_regle * regles_aux = regles;
      while(regles_aux != NULL)
      {
         if( !strcmp(regles_aux->la_regle.etat_depart,etats_aux->chaine) && 
             !strcmp(regles_aux->la_regle.symbole,symbole) && 
             !est_mot_de_la_liste(etats_accessibles,regles_aux->la_regle.etat_arrive) )
         {
            struct Liste_chaine * letat = NULL;
            ajout_liste_en_queue(regles_aux->la_regle.etat_arrive,&letat);
            struct Liste_chaine * ef = epsilon_fermeture(letat,regles);
            struct Liste_chaine * ef_aux = ef;
            while(ef_aux != NULL)
            {
               if( !est_mot_de_la_liste(etats_accessibles, ef_aux->chaine))
               {
                  ajout_liste_en_queue(ef_aux->chaine,&etats_accessibles);
               }
               ef_aux = ef_aux->chaine_suivante;
            }
         }
         regles_aux = regles_aux->regle_suivante;
      }
      etats_aux = etats_aux->chaine_suivante;
   }
   return etats_accessibles;
}


/* DETERMINISATION : 
* Procedure ayant en entree/sortie toutes le informations de la matrice
* Determinise l automate
***********************************************************************/
void determinisation(struct Liste_chaine ** liste_etats_initiaux, 
                     struct Liste_chaine ** liste_etats_finaux, 
                     struct Liste_chaine ** liste_etats,
                     struct Liste_chaine ** alphabet,
                     struct Liste_regle ** liste_des_regles)
{
   /*** ETAPE 1 : Regroupement des etats ***/
   
   struct Liste_de_listes * nouveaux_etats = NULL;   // Ici la liste de listes correspondant aux nouveaux etats

   // On ajoute les etats correspondants a l epsilon fermeture des etats initiaux
   ajout_liste_de_listes(epsilon_fermeture(*liste_etats_initiaux,*liste_des_regles), &nouveaux_etats);

   // On regroupe les etats en listes d etats selon leurs regles
   // Chaque liste d etat correspondra a un nouvel etat
   struct Liste_de_listes * nouveaux_etats_aux = nouveaux_etats;
   while(nouveaux_etats_aux != NULL)
   {
      struct Liste_chaine * symbole_aux = *alphabet;
      while(symbole_aux != NULL)
      {
         if ( !est_liste_de_liste(Transition(nouveaux_etats_aux->pt_liste_etats,symbole_aux->chaine,*liste_des_regles), nouveaux_etats) &&
              !(Transition(nouveaux_etats_aux->pt_liste_etats,symbole_aux->chaine,*liste_des_regles) == NULL))
         {
            ajout_liste_de_listes_en_queue(Transition(nouveaux_etats_aux->pt_liste_etats,symbole_aux->chaine,*liste_des_regles),&nouveaux_etats);
         }
         symbole_aux = symbole_aux->chaine_suivante;
      }
      nouveaux_etats_aux = nouveaux_etats_aux->pt_liste_suivante;
   }
   
   /*** ETAPE 2 : Modifier la liste des etats, la liste des etats finaux et la liste des etats initiaux selon le regroupement d etats ***/
   
   // Les nouvelles listes
   struct Liste_chaine * liste_nouveaux_etats = NULL;
   struct Liste_chaine * liste_nouveaux_etats_initiaux = NULL;
   struct Liste_chaine * liste_nouveaux_etats_finaux = NULL;
   
   struct Liste_de_listes * nouveaux_etats_aux2 = nouveaux_etats;
   while(nouveaux_etats_aux2 != NULL)
   {
      char * nom_nouvel_etat;
      nom_nouvel_etat = (char *)calloc(100,sizeof(char));
      int est_init = 0, est_fin = 0;
      struct Liste_chaine * parcour_liste = nouveaux_etats_aux2->pt_liste_etats;
      while(parcour_liste != NULL)
      {
         strcat(nom_nouvel_etat,parcour_liste->chaine);    // On trouve le nom du nouvel etat par concatenation des etats de la liste
         if (est_mot_de_la_liste(*liste_etats_initiaux,parcour_liste->chaine)){est_init = 1;}   // On memorise aussi s il est initial
         if (est_mot_de_la_liste(*liste_etats_finaux,parcour_liste->chaine)){est_fin = 1;}      // Ou final
         
         parcour_liste = parcour_liste->chaine_suivante;   
      }
      if(!est_mot_de_la_liste(liste_nouveaux_etats,nom_nouvel_etat)){ajout_liste_en_queue(nom_nouvel_etat,&liste_nouveaux_etats);}
      if(!est_mot_de_la_liste(liste_nouveaux_etats_initiaux,nom_nouvel_etat) && (est_init == 1))
         {ajout_liste_en_queue(nom_nouvel_etat,&liste_nouveaux_etats_initiaux);}
      if(!est_mot_de_la_liste(liste_nouveaux_etats_finaux,nom_nouvel_etat) && (est_fin == 1))
         {ajout_liste_en_queue(nom_nouvel_etat,&liste_nouveaux_etats_finaux);}
      nouveaux_etats_aux2 = nouveaux_etats_aux2->pt_liste_suivante;
   }
   // On modifie les listes originales
   *liste_etats = liste_nouveaux_etats;
   *liste_etats_initiaux = liste_nouveaux_etats_initiaux;
   *liste_etats_finaux = liste_nouveaux_etats_finaux;
   
   /*** ETAPE 3 : Modifier la liste des regles selon le regroupement des etats ***/
   
   // On va creer une nouvelle liste de regles correspondants aux nouveaux etats
   struct Liste_regle * nouvelle_liste_des_regles = NULL;
   
   struct Liste_de_listes * nouveaux_etats_aux3 = nouveaux_etats;
   while(nouveaux_etats_aux3 != NULL)
   {
      // On trouve le nom du nouvel etat par concatenation des etats de la liste
      char * nom_nouvel_etat2;
      nom_nouvel_etat2 = (char *)calloc(100,sizeof(char));
      struct Liste_chaine * parcour_liste = nouveaux_etats_aux3->pt_liste_etats;
      while(parcour_liste != NULL)
      {
         strcat(nom_nouvel_etat2,parcour_liste->chaine);
         parcour_liste = parcour_liste->chaine_suivante;
      }
      
      // Pour chaque symbole on trouve les etats accessibles depuis la liste d etat avec ce symbole (avec la fonction Transition)
      // Et on ajoute la regle : (nom_nouvel_etat2,symb) = nom_etat_arrive (ce dernier trouve pas concatenation de la liste d etats d arrivee)
      struct Liste_chaine * symbole_aux2 = *alphabet;
      while(symbole_aux2 != NULL)
      {
         // On recupere la liste d etats accessibles depuis les etats de depart avec la fonction Transition
         struct Liste_chaine * etats_accessibles = Transition(nouveaux_etats_aux3->pt_liste_etats,symbole_aux2->chaine,*liste_des_regles);
         // Ici on cherche la liste equivalente des etats accessibles dans la liste de liste afin
         // que la concatenation se fasse dans le bon ordre et que les etats equivalents s ecrivent pareil
         etats_accessibles = recherche_liste(etats_accessibles,nouveaux_etats);
         
         // On creer le nom de l etat d arrivee par concatenation
         char * nom_etat_arrive;
         nom_etat_arrive = (char *)calloc(100,sizeof(char));
         struct Liste_chaine * parcour_liste2 = etats_accessibles;
         while(parcour_liste2 != NULL)
         {
             strcat(nom_etat_arrive,parcour_liste2->chaine);
             parcour_liste2 = parcour_liste2->chaine_suivante;
         }
         
         // On creer la nouvelle regle et on l ajoute a la nouvelle liste
         struct Regle r;
         r.etat_depart = nom_nouvel_etat2;
         r.symbole = symbole_aux2->chaine;
         r.etat_arrive = nom_etat_arrive;
         ajout_regle_dans_liste(r,&nouvelle_liste_des_regles);
         
         symbole_aux2 = symbole_aux2->chaine_suivante;
      }
      
      nouveaux_etats_aux3 = nouveaux_etats_aux3->pt_liste_suivante;
   }
   // Enfin on modifie la liste des regles originale
   *liste_des_regles = nouvelle_liste_des_regles;
}
