#include"tache.h"

using namespace std;

int Tache::_nbTaches = 1;


Tache::Tache(){
    _ri = 0;
    _Ci = 0;
    _Di = 0;
    _Pi = 0;
    //convertion de int vers string
    ostringstream oss;
    oss << _nbTaches;
    _idTache = oss.str();

    ++ _nbTaches;
    };

Tache::Tache(int r,int c,int d,int p){
    _ri = r;
    _Ci = c;
    _Di = d;
    _Pi = p;
    //convertion de int vers string
    ostringstream oss;
    oss << _nbTaches;
    _idTache = oss.str();
    ++ _nbTaches;
    };

Tache::Tache(string id,int r,int c,int d,int p){
    _ri = r;
    _Ci = c;
    _Di = d;
    _Pi = p;
    _idTache = id;
    ++ _nbTaches;
    };

Tache::Tache(const Tache &t){
    _ri = t.getRi();
    _Ci = t.getCi();
    _Di = t.getDi();
    _Pi = t.getPi();
    _idTache = t.getId();
    };

Tache::~Tache(){};

void Tache::setRi(int v){_ri = v;};
int Tache::getRi()const{return _ri;};
void Tache::setCi(int v){_Ci = v;};
int Tache::getCi()const{return _Ci;};
void Tache::setDi(int v){_Di = v;};
int Tache::getDi()const{return _Di;};
void Tache::setPi(int v){_Pi = v;};
int Tache::getPi()const{return _Pi;};
string Tache::getId()const{return _idTache;};

void Tache::afficher(ostream &os)const{
    os << "Tache [id : " << _idTache << "]";
    cout << " (";
    if(_Pi == 0){
        cout << "Aperiodique ";
        if(_Di == 0)
            cout << "Non Critique";
        else
            cout << "Critique";
    }else cout << "Periodique";

    cout << ")" << endl;
    cout << "ri = " << _ri << endl
         << "Ci = " << _Ci << endl
         << "Di = " << _Di << endl
         << "Pi = " << _Pi << endl;
    };

bool Tache::operator==(const Tache &t){
    if(_idTache == t._idTache)
        return true;
    else
        return false;
    };

ostream& operator<<(ostream &os, const Tache &t){
    t.afficher(os);
    return os;
    };
